<html>
<head>
<title>
Admin1
</title>
</head>
 <body>

 
 <script>
 function validare(){
 var username=document.getElementById("acc_username").value;
 var pass1=document.getElementById("acc_parola").value;
 var pass2=document.getElementById("acc_parola2").value;
 
 if(username==""){
 alert("Introdu username-ul");
 return 0;
 }
 
 if(pass1==""){
 alert("Introdu Parola1");
 return 0;
 }
 
 if(pass2==""){
 alert("Introdu Parola2");
 return 0;
 }
 
 if(pass1!=pass2){
 alert("Parolele nu coincid.");
 return 0;
 }
 document.getElementById("form_create_account").submit();
 
 }
 
 </script>
<?php
session_start();
if(strcmp($_SESSION["GRAD_ACCES"],'c')<0){ 
header("Location: homepage.php");
}

//
if(isset($_POST["elev_id"])){
$acc_elev_id = ($_POST["elev_id"]);
$acc_username=($_POST["acc_username"]);
$acc_acc_parola=($_POST["acc_parola"]);
$acc_grad_acces=($_POST["acc_grad_acces"]);

 $cookie_name="proiectPARC";
     $servernamedb = "localhost";
     $usernamedb   = "root";
     $passworddb   = "";
     $dbnamedb     = "aibd";
	 
//

if($acc_grad_acces != null){

$conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO cont VALUES (null, '$acc_username','$acc_acc_parola','$acc_grad_acces','$acc_elev_id')";

if ($conn->query($sql) === TRUE) {
    echo "Contul a fost creat";
	echo "<br>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	 }
	 
//




echo "Id-ul elevului : ".$acc_elev_id."<br>";
echo "Username : ".$acc_username."<br>";
echo "Parola : ".$acc_acc_parola."<br>";
}
//
?>
<form action="admin1.php" method="POST" id="form_create_account">
<table border="1">
<tr>
	<td>Elev_Nume</td>
	<td>Elev_Prenume</td>
	<td>Elev_Prenume_Mama</td>
	<td>Elev_Prenume_Tata</td>
	<td>Elev_Nr_Telefon</td>
	<td>Clasa</td>
	<td></td>
</tr>
	<?php
	 $cookie_name="proiectPARC";
     $servernamedb = "localhost";
     $usernamedb   = "root";
     $passworddb   = "";
     $dbnamedb     = "aibd";
	 
	 $conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = "select elev.*,clasa.clasa_nume from elev,clasa where elev.elev_clasa_id=clasa.clasa_id;";
	$result = $conn->query($sql);
	
	if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
	?>
	
	
	<tr>
	<td><?php echo $row["elev_nume"]?> </td>
	<td><?php echo $row["elev_prenume"]?> </td>
	<td><?php echo $row["elev_prenume_mama"]?> </td>
	<td><?php echo $row["elev_prenume_tata"]?> </td>
	<td><?php echo $row["elev_nr_telefon"]?> </td>
	<td><?php echo $row["clasa_nume"]?> </td>
	<td><input type="radio" name="elev_id" checked value="<?php echo $row["elev_id"]?>"/>
	</tr>
	
	<?php
	}
	} else {
    echo "0 resultse";
	}
$conn->close();
	
	
?>

 <br>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>

<td  colspan="3" >
 <table>
 <tr>
 <td>Username: </td>
 <td><input type="text" name="acc_username" id="acc_username"/></td>
 </tr>
 <tr>
 <td>Parola: </td>
 <td><input type="password" name="acc_parola" id="acc_parola"/></td>
 </tr>
 <td>Parola2: </td>
 <td><input type="password" name="acc_parola2" id="acc_parola2"/></td>
 </tr>

 <tr>
 
 <td>Grad Acces: </td>
 <td>
 <select name="acc_grad_acces" style="float: right;">
  <option value="a">Parinte</option>
  <option value="b">Profesor</option>
  <option value="c">Administrator</option>
</select>
 
 </td>
 
 
 </tr>

 <tr>
<td>
<input type="button" value="Inapoi" id="inapoi" name="inapoi" onClick="window.location.href='homepage.php'"/>
</td>
 <td><input type="button" value="Creeaza cont" onClick="validare();" style="float: right;"/><td>
 </tr>
 
 </table>

 </td>
 </tr>
 </table>
 </form>

<br>
<br>
<form action="index.php" method="POST" name="form_log_out" id="form_log_out">
<input type="submit" value="Log out" id="logOut" name="logOut" />
</form>

</body>
</html>