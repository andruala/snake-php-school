-- MySQL dump 10.16  Distrib 10.1.19-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.1.19-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `catalog`
--

DROP TABLE IF EXISTS `catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog` (
  `catalog_id` int(2) NOT NULL AUTO_INCREMENT,
  `catalog_semestru` int(1) NOT NULL,
  `catalog_elev_id` int(11) NOT NULL,
  `catalog_data` date NOT NULL,
  `catalog_materie_id` int(11) NOT NULL,
  `catalog_clasa_id` int(11) NOT NULL,
  `catalog_nota` int(2) NOT NULL,
  `catalog_motivat` int(1) NOT NULL,
  PRIMARY KEY (`catalog_id`),
  KEY `catalog_elev_id` (`catalog_elev_id`),
  KEY `catalog_materie_id` (`catalog_materie_id`),
  KEY `catalog_clasa_id` (`catalog_clasa_id`),
  CONSTRAINT `catalog_ibfk_1` FOREIGN KEY (`catalog_elev_id`) REFERENCES `elev` (`elev_id`),
  CONSTRAINT `catalog_ibfk_2` FOREIGN KEY (`catalog_materie_id`) REFERENCES `materie` (`materie_id`),
  CONSTRAINT `catalog_ibfk_3` FOREIGN KEY (`catalog_clasa_id`) REFERENCES `clasa` (`clasa_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog`
--

LOCK TABLES `catalog` WRITE;
/*!40000 ALTER TABLE `catalog` DISABLE KEYS */;
INSERT INTO `catalog` VALUES (1,1,1,'2018-04-10',1,1,4,0),(2,1,2,'2018-04-10',3,1,5,0),(3,1,2,'2018-04-10',3,1,5,0),(4,1,2,'2018-04-10',3,1,5,0),(7,1,3,'2018-04-10',1,1,0,0),(8,1,1,'2018-04-11',2,1,2,0),(9,1,1,'2018-05-02',1,1,0,0);
/*!40000 ALTER TABLE `catalog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clasa`
--

DROP TABLE IF EXISTS `clasa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clasa` (
  `clasa_id` int(3) NOT NULL AUTO_INCREMENT,
  `clasa_nume` varchar(32) NOT NULL,
  `clasa_an` int(1) NOT NULL,
  PRIMARY KEY (`clasa_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clasa`
--

LOCK TABLES `clasa` WRITE;
/*!40000 ALTER TABLE `clasa` DISABLE KEYS */;
INSERT INTO `clasa` VALUES (1,'1 A',1),(2,'1 B',1),(3,'1 C',1),(4,'2 A',2),(5,'2 B',2),(6,'2 C',2),(7,'3 A',3),(8,'3 B',3),(9,'3 C',3),(10,'4 A',4),(11,'4 B',4),(12,'4 C',4);
/*!40000 ALTER TABLE `clasa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cont`
--

DROP TABLE IF EXISTS `cont`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cont` (
  `cont_id` int(2) NOT NULL AUTO_INCREMENT,
  `cont_username` varchar(25) NOT NULL,
  `cont_parola` varchar(25) NOT NULL,
  `cont_acces` varchar(1) NOT NULL,
  `id_elev` int(11) DEFAULT NULL,
  PRIMARY KEY (`cont_id`),
  UNIQUE KEY `cont_username` (`cont_username`),
  UNIQUE KEY `cont_username_2` (`cont_username`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cont`
--

LOCK TABLES `cont` WRITE;
/*!40000 ALTER TABLE `cont` DISABLE KEYS */;
INSERT INTO `cont` VALUES (1,'user1','pass1','a',NULL),(2,'user2','pass2','b',NULL),(3,'user3','pass3','c',NULL),(4,'test1','test1','a',10),(6,'testprof','testprof','b',10),(7,'testparinte','testparinte','a',1),(8,'admin','admin','c',10),(9,'t1','t1','a',1),(11,'t2','t2','a',10);
/*!40000 ALTER TABLE `cont` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elev`
--

DROP TABLE IF EXISTS `elev`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elev` (
  `elev_id` int(3) NOT NULL AUTO_INCREMENT,
  `elev_nume` varchar(32) NOT NULL,
  `elev_prenume` varchar(32) NOT NULL,
  `elev_prenume_mama` varchar(32) NOT NULL,
  `elev_prenume_tata` varchar(32) NOT NULL,
  `elev_nr_telefon` varchar(10) NOT NULL,
  `elev_clasa_id` int(3) NOT NULL,
  PRIMARY KEY (`elev_id`),
  KEY `elev_clasa_id` (`elev_clasa_id`),
  CONSTRAINT `elev_ibfk_1` FOREIGN KEY (`elev_clasa_id`) REFERENCES `clasa` (`clasa_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elev`
--

LOCK TABLES `elev` WRITE;
/*!40000 ALTER TABLE `elev` DISABLE KEYS */;
INSERT INTO `elev` VALUES (1,'elevn1','elevp1','nume mama','nume tata','0740565422',1),(2,'elevn2','elevp2','nume mama','nume tata','0740565422',1),(3,'elevn3','elevp3','nume mama','nume tata','0740565422',1),(4,'elevn4','elevp4','nume mama','nume tata','0740565422',1),(5,'elevn5','elevp5','nume mama','nume tata','0740565422',1),(6,'elevn6','elevp6','nume mama','nume tata','0740565422',1),(7,'elevn7','elevp7','nume mama','nume tata','0740565422',1),(8,'elevn8','elevp8','nume mama','nume tata','0740565422',2),(9,'elevn9','elevp9','nume mama','nume tata','0740565422',2),(10,'elevn10','elevp10','nume mama','nume tata','0740565422',2),(11,'asd','asda','asd','asd','123',1),(12,'asd','asda','asd','asd','123',1),(13,'asd','asda','asd','asd','123',1),(14,'asd','asda','asd','asd','123',1);
/*!40000 ALTER TABLE `elev` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materie`
--

DROP TABLE IF EXISTS `materie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materie` (
  `materie_id` int(11) NOT NULL AUTO_INCREMENT,
  `materie_nume` varchar(100) NOT NULL,
  `materie_clase` varchar(20) NOT NULL,
  PRIMARY KEY (`materie_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materie`
--

LOCK TABLES `materie` WRITE;
/*!40000 ALTER TABLE `materie` DISABLE KEYS */;
INSERT INTO `materie` VALUES (1,'Romana','1,2,3,4'),(2,'Limba moderna','1,2,3,4'),(3,'Matematica','1,2,3,4'),(4,'Stiinte ale naturii','1,2,3,4'),(5,'Istorie','4'),(6,'Geografie','4'),(7,'Educatie civica','4'),(8,'Religie','1,2,3,4'),(9,'Educatie fizica','1,2,3,4'),(10,'Muzica','1,2,3,4'),(11,'asdasd','3,4,5'),(12,'asdasd','3,4,5'),(13,'',''),(14,'',''),(15,'test','2,3'),(16,'test','1,2,3,4,5,6,7,8');
/*!40000 ALTER TABLE `materie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profesor`
--

DROP TABLE IF EXISTS `profesor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profesor` (
  `profesor_id` int(3) NOT NULL AUTO_INCREMENT,
  `profesor_nume` varchar(32) NOT NULL,
  `profesor_prenume` varchar(32) NOT NULL,
  `profesor_data_nasterii` date NOT NULL,
  PRIMARY KEY (`profesor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profesor`
--

LOCK TABLES `profesor` WRITE;
/*!40000 ALTER TABLE `profesor` DISABLE KEYS */;
INSERT INTO `profesor` VALUES (1,'a','a','2017-10-10'),(2,'b','b','2017-10-10'),(3,'c','c','2017-10-10'),(4,'d','d','2017-10-10');
/*!40000 ALTER TABLE `profesor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-18 11:56:23
