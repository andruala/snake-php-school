<html>
 <head>
  <title>PHP Test</title>
 </head>

<body>
<?php
     $servernamedb = "localhost";
     $usernamedb   = "root";
     $passworddb   = "";
     $dbnamedb     = "aibd";
	 

// Create connection
$conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "select (select count(*) from catalog where catalog_nota ='0' ) *100 / count(*)  as p from catalog;";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		$procabs=$row["p"];
    }
} else {
    echo "0 results";
}
$conn->close();
?>

<table>
<tr>
<td>Procentaj prezente: </td>
<td><?php echo (100-$procabs);?></td>
</tr>
<tr>
<td>Procentaj absente: </td>
<td><?php echo $procabs;?>%</td>
</tr>
<tr>
<td>Procentaj note peste 5: </td>
<td>---</td>
</tr>


</table>
<input type="button" value="Inapoi" id="inapoi" name="inapoi" onClick="window.location.href='homepage.php'"/>
</body>
</html>