<html>
<head>
<title>
Admin2
</title>
</head>
<?php
session_start();
if ( $_SESSION["LOGGEDIN"] != "TRUE" ){
header("Location: index.php");
}
error_reporting(0);
?>
<script>
function getSelectedChbox(frm) {
  var selchbox = [];// array that will store the value of selected checkboxes
  // gets all the input tags in frm, and their number
  var inpfields = frm.getElementsByTagName('input');
  var nr_inpfields = inpfields.length;
  // traverse the inpfields elements, and adds the value of selected (checked) checkbox in selchbox
  for(var i=0; i<nr_inpfields; i++) {
    if(inpfields[i].type == 'checkbox' && inpfields[i].checked == true) selchbox.push(inpfields[i].value);
  }
  return selchbox;
}   

function sub(){
var materie=document.getElementById("numeMaterie");
var clase=document.getElementById("clase");
clase.value=getSelectedChbox(formMaterie);
			
			
if(materie.value==""){
alert("Trebuie sa specifici numele materiei");
return false;
}
			
if(clase.value==""){
alert("Selecteaza cel putin o clasa.");
return false;
}
document.getElementById("formMaterie").submit();
}


</script>
<body>
<?php

if(isset($_POST["numeMaterie"])){
     $servernamedb = "localhost";
     $usernamedb   = "root";
     $passworddb   = "";
     $dbnamedb     = "aibd";



$conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO materie  values (null, '".$_POST["numeMaterie"]."','".$_POST["clase"]."');";
//echo $sql;
if ($conn->query($sql) === TRUE) {
    echo "Materia a fost adaugata cu succes";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	 

}

?>

<form action="admin2.php" name="formMaterie" id="formMaterie" method="post">

<input type="hidden" name="clase" value="" id="clase" />


<table border="1">

<tr>
<td>
Nume materie:&nbsp;
</td>
<td>
<input type="text" name="numeMaterie" id="numeMaterie" value="" />
</td>
</tr>
<tr>
<td>
Valabil pentru clasele:&nbsp;
</td>
<td>
<label><input type="checkbox" name="check" id="check"  value="1"/>1</label>
<label><input type="checkbox" name="check" id="check"  value="2"/>2</label>
<label><input type="checkbox" name="check" id="check"  value="3"/>3</label>
<label><input type="checkbox" name="check" id="check"  value="4"/>4</label>
<label><input type="checkbox" name="check" id="check"  value="5"/>5</label>
<label><input type="checkbox" name="check" id="check"  value="6"/>6</label>
<label><input type="checkbox" name="check" id="check"  value="7"/>7</label>
<label><input type="checkbox" name="check" id="check"  value="8"/>8</label>&nbsp;
</td>
</tr>
<tr>

<td>
<input type="button" value="Inapoi" id="inapoi" name="inapoi" onClick="window.location.href='homepage.php'"/>
</td>

<td>
<input type="button" value="Adauga Materie" name="adaugaMaterie" id="adaugaMaterie" style="float:right" onClick="sub()";/>
</td>

</tr>
</table>



</form>


<form action="index.php" method="POST" name="form" id="form">

<input type="submit" value="Log out" id="logOut" name="logOut" />

</form>
</body>
</html>