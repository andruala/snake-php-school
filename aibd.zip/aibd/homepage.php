<html>
<head>
<title>
Welcome

</title>
</head>
<body>
<?php
session_start();
echo $_SESSION["GRAD_ACCES"];
echo "<br>";
echo "id elev este".$_SESSION["ID_ELEV"];
if ( $_SESSION["LOGGEDIN"] != "TRUE" ){
header("Location: index.php");
}else{ /// DE AICI

if(strcmp($_SESSION["GRAD_ACCES"],'a')>=0){ 
?>
<form action="parinte1.php" method="post">
<input type="submit" value="parinte1"/>
</form>
<br>
<form action="parinte2.php" method="post">
<input type="submit" value="parinte2"/>
</form>
<br>

<?php
}
if(strcmp($_SESSION["GRAD_ACCES"],'b')>=0){ 
?>
<form action="prof1.php" method="post">
<input type="submit" value="Adauga Nota"/>
</form>
<br>
<form action="prof2.php" method="post">
<input type="submit" value="prof2"/>
</form>
<br>

<?php
}
if(strcmp($_SESSION["GRAD_ACCES"],'c')>=0){ 
?>
<form action="admin1.php" method="post">
<input type="submit" value="Creare Cont"/>
</form>
<br>
<form action="admin2.php" method="post">
<input type="submit" value="Creare materie"/>
</form>
<br>
<form action="admin3.php" method="post">
<input type="submit" value="Inscriere elev"/>
</form>
<br>

<?php
}
}
?>



<form action="generate.php" method="POST"/>
<input type="submit" value="Raport" id="raport" name="raport"/>
</form>
<form action="index.php" method="POST" name="form" id="form">

<input type="submit" value="Log out" id="logOut" name="logOut" />

</form>
</body>
</html>