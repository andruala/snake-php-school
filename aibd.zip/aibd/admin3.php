<html>
<head>
<title>
Admin3
</title>
</head>

<script>

function sub(){
var nume,prenume,pmama,ptata,nrtel;

nume=document.getElementsByName('nume_elev')[0].value;
prenume=document.getElementsByName('prenume_elev')[0].value;
pmama=document.getElementsByName('prenume_mama')[0].value;
ptata=document.getElementsByName('prenume_tata')[0].value;
nrtel=document.getElementsByName('nrtel')[0].value;

if(nume != "" && prenume != "" && pmama != "" && ptata != "" && nrtel != ""){
document.getElementById("formElev").submit();
}else{
alert("Cmpleteaza toate campurile");
}

}

</script>
<?php
session_start();
if ( $_SESSION["LOGGEDIN"] != "TRUE" ){
header("Location: index.php");

}
	 $servernamedb = "localhost";
     $usernamedb   = "root";
     $passworddb   = "";
     $dbnamedb     = "aibd";
error_reporting(0);
?>
<body>
<?php


if(isset($_POST["nume_elev"])){
     $servernamedb = "localhost";
     $usernamedb   = "root";
     $passworddb   = "";
     $dbnamedb     = "aibd";
	 
	 
	 $conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO elev VALUES (null,'".$_POST["nume_elev"]."','".$_POST["prenume_elev"]."','".$_POST["prenume_mama"]."','".$_POST["prenume_tata"]."','".$_POST["nrtel"]."','".$_POST["clasa_id"]."');";
//echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Elevul ".$_POST["nume_elev"]." ".$_POST["prenume_elev"]." a fost adaugat.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();

}


?>
<form action="admin3.php" name="formElev" id="formElev" method="post">
<table border="1">

<tr>
	<td>Nume elev: </td>
	<td><input type="text" name="nume_elev"/></td>
</tr>
<tr>
	<td>Prenume elev: </td>
	<td><input type="text" name="prenume_elev"/></td>
</tr>
<tr>
	<td>Prenume mama: </td>
	<td><input type="text" name="prenume_mama"/></td>
</tr>
<tr>
	<td>Prenume tata: </td>
	<td><input type="text" name="prenume_tata"/></td>
</tr>
<tr>
	<td>Nr. telefon: </td>
	<td><input type="number" name="nrtel"/></td>
</tr>
<tr>
	<td>Clasa </td>
	<td>
				 <select name="clasa_id" id="clasa_id" style="float: right;">
				<?php
				// Create connection
	try{

				$conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				} 

		$sql = "select * from clasa;";
				$result = $conn->query($sql);
				
			
				if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) { ?>
						<option value="<?php echo $row["clasa_id"]?>"><?php echo $row["clasa_nume"]?></option>
					<?php
					}
				} else {
					echo "0 results";
				}
				$conn->close();
	}catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
}
				?>
				</select>
		</td>
</tr>





<tr>
	<td>
		<input type="button" value="Inapoi" id="inapoi" name="inapoi" onClick="window.location.href='homepage.php'"/>
	</td>
	<td>
		<input type="button" value="Adauga Elev" name="adaugaElev" id="adaugaElev" style="float:right" onClick="sub()";/>
	</td>
</tr>

</table>

</form>

<form action="index.php" method="POST" name="form" id="form">
<input type="submit" value="Log out" id="logOut" name="logOut" />
</form>
</body>
</html>