<html>
<head>
<title>
Profesor1
</title>
</head>
<script>

function helper(){
var anul_clasei=document.getElementById("clasa_id").options[document.getElementById("clasa_id").selectedIndex].text[0];
document.getElementById("anul_clasei").value=anul_clasei;

}
</script>
<?php
session_start();
if ( $_SESSION["LOGGEDIN"] != "TRUE" ){
header("Location: index.php");
}
//
	 $cookie_name="proiectPARC";
     $servernamedb = "localhost";
     $usernamedb   = "root";
     $passworddb   = "";
     $dbnamedb     = "aibd";
//
$clasa_id = ($_POST["clasa_id"]);
?>
<body>
<form action="prof1.php" method="post" id="form_prof">
<table>
<tr>
<td>
Clasa:
</td>
<td>

 <select name="clasa_id" id="clasa_id" style="float: right;">
<?php
// Create connection
$conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "select * from clasa;";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row["clasa_id"];?>" <?php if ($row["clasa_id"] == $clasa_id) echo " selected" ?> ><?php echo $row["clasa_nume"]?></option>
    <?php
	}
} else {
    echo "0 results";
}
$conn->close();

?>
</select>
</td>
<?php

if($clasa_id != ""){
?>


<tr>
<td>
Elev:
</td>
<td>
 <select name="elev_id" style="float: right;">
<?php
$conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "select * from elev where elev_clasa_id='$clasa_id';";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row["elev_id"]?>"><?php echo $row["elev_nume"]." ".$row["elev_prenume"]?></option>
    <?php
	}
} else {
    echo "0 results";
}
$conn->close();
?>
</select>
</td>
</tr>
<tr>
<td>
Materie:
</td>
<td>
<select name="materie_id" style="float:right;">

<?php
//
$anul_clasei=($_POST["anul_clasei"]);
$conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "select * from materie where materie_clase like '%$anul_clasei%';";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row["materie_id"]?>"><?php echo $row["materie_nume"]?></option>
    <?php
	}
} else {
    echo "0 results";
}
$conn->close();
?>
</td>
</tr>
<tr>
<td>
Nota:
</td>
<td>
<select name="nota" style="float:right;">
	<option value="0">Absent</option>
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	<option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
	<option value="9">9</option>
	<option value="10">10</option>
<td>
<tr>
//


<?php
}

$nota = ($_POST["nota"]);
$elev_id = ($_POST["elev_id"]);
$materie_id = ($_POST["materie_id"]);

if($_POST["nota"] !=""){

//
$conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$sql = "INSERT INTO catalog values(null,1,'$elev_id',now(),'$materie_id','$clasa_id','$nota',0);";
if ($conn->query($sql) === TRUE) {
  //  echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
//

}

?>

<td colspan="2">
<input type="submit" value="Next" id="next" name="next" style="float:right;" onClick="return helper();"/> 
<input type="hidden" name="anul_clasei" id="anul_clasei"/>
</td>
</td>
</table>
</form>
<form action="index.php" method="POST" name="form" id="form">
<input type="button" value="Inapoi" id="inapoi" name="inapoi" onClick="window.location.href='homepage.php'"/>
<input type="submit" value="Log out" id="logOut" name="logOut" />
<?php
if($clasa_id!=''){
?>
<script>
document.getElementById("next").value="Adauga";
</script>
<?php
}
?>
</form>
</body>
</html>