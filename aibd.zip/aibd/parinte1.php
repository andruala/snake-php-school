<html>
<head>
<title>
Parinte1
</title>
</head>
<?php
session_start();
//print_r($_SESSION);
if ( $_SESSION["LOGGEDIN"] != "TRUE" ){
header("Location: index.php");
}
//echo "LOGGED";

//echo "test";
?>
<body>


</body>
</html>
<table border="1px">
<tr>
<td>
Data
</td>
<td>
Materie
</td>
<td>
Nota
</tr>
</td>
	<?php
	 $cookie_name="proiectPARC";
     $servernamedb = "localhost";
     $usernamedb   = "root";
     $passworddb   = "";
     $dbnamedb     = "aibd";
	 
	 $conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
//	echo "Test";
//	echo "select c.catalog_data, m.materie_nume,c.catalog_nota from materie m,catalog c where c.catalog_materie_id = m.materie_id and c.catalog_elev_id='".$_SESSION["ID_ELEV"]."';";

	$sql = "select c.catalog_data, m.materie_nume,c.catalog_nota from materie m,catalog c where c.catalog_materie_id = m.materie_id and c.catalog_elev_id='".$_SESSION["ID_ELEV"]."';";
	$result = $conn->query($sql);
	
	if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
	?>
	
	
	<tr>
	<td><?php echo $row["catalog_data"]?> </td>
	<td><?php echo $row["materie_nume"]?> </td>
	<td><?php if($row["catalog_nota"] != "0") 
			echo $row["catalog_nota"];
			else
				echo "Absent";
	?> </td>
	</tr>
	
	<?php
	}
	} else {
    echo "0 resultse";
	}
$conn->close();
	
	
?>
</table>
<br>
<form action="index.php" method="POST" name="form" id="form">
<input type="button" value="Inapoi" id="inapoi" name="inapoi" onClick="window.location.href='homepage.php'"/>
<input type="submit" value="Log out" id="logOut" name="logOut" />

</form>
</body>
</html>