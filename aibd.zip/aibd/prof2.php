<html>
<head>
<title>
Profesor2
</title>
</head>
<?php
session_start();
print_r($_SESSION);
if ( $_SESSION["LOGGEDIN"] != "TRUE" ){
header("Location: index.php");
}
echo "LOGGED";

echo "test";
?>
<body>

<form action="index.php" method="POST" name="form" id="form">

<input type="submit" value="Log out" id="logOut" name="logOut" />

</form>
</body>
</html>