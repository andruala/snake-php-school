<html>
 <head>
  <title>PHP Test</title>
 </head>
 <script>
 function verifica(){
 var username=document.getElementById('username').value;
 var parola=document.getElementById('parola').value;
 if(username!="" && parola!=""){
 console.log("login");
 document.getElementById("form").submit();
 }else{
 alert("Completeaza ambele campuri.");
 }
 }
 
 </script>
 <body>
 <!--
 
 GRADE
 A-ADMINISTRATORI
 B-PROFESORI
 C-PARINTI
 
 -->
<?php

	 $cookie_name="proiectPARC";
     $servernamedb = "localhost";
     $usernamedb   = "root";
     $passworddb   = "";
     $dbnamedb     = "aibd";
	 session_start();
	 
	 
	 if(isset($_POST["logOut"])){
	 $_SESSION["LOGGEDIN"] = "FALSE";
	 }
	 
	 
	 if(isset($_COOKIE[$cookie_name])) {
     list($cuser, $cpass, $cacces) = explode("-", $_COOKIE[$cookie_name]);
	 $conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
	if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
	    $sql    = "select * from cont where cont_username='$cuser' and cont_parola='$cpass';";
    $result = $conn->query($sql);
	if ($result->num_rows == 1) {
		
		$_SESSION["LOGGEDIN"] = "TRUE";
		header("Location: homepage.php");
		//echo " AM CONTUL IN COOKIE";
	}
    	$conn->close();
	
	}	 
	 
	 if(isset($_POST["username"])){
$username = ($_POST["username"]);
$parola   = ($_POST["parola"]);
if ($username != '' && $parola != '') {
  //  echo "AM TRIMIS PARAM";
    echo "<br>";
	//
    
 
    
    // Create connection
    $conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $sql    = "select * from cont where cont_username='$username';";
    $result = $conn->query($sql);
	if ($result->num_rows == 1) {
        // output data of each row
        $row = $result->fetch_assoc();
		if($row["cont_parola"]==$parola) {
		$acces=$row["cont_acces"];
		
		$_SESSION["ID_ELEV"]=$row["id_elev"];
		if(isset($_POST['rememberMe'])){
		$cookie_value=$username."-".$parola."-".$acces;
		echo $cookie_value;
		setcookie($cookie_name, $cookie_value, time() + (30), "/"); 
		}
		
		$_SESSION["LOGGEDIN"] = "TRUE";
		$_SESSION["GRAD_ACCES"] = "$acces";
		header("Location: homepage.php");
			echo "LOGGED";
		
    }else{
	echo "Wrong password<br>";
	
}    
	}else{
	
	
	echo "Wrong account<br>";
	}
    $conn->close();

	}
	}
?>
	 
	 
	 
     <form action="" method="post" id="form">
     <table border="1">
         <tr>
            <td>
                 Utilizator
            </td>
            <td>
                <input name="username" id="username" type="text"/>
            </td> 
         </tr>
         <tr>
             <td>
                 Parola
             </td>
             <td>
                 <input name="parola" id="parola" type="password"/>
                 
             </td>
         </tr>
         <tr>
             <td>
                 &nbsp;
             </td>
             <td>
                 <input name="login" id="login" value="login" type="button" onClick="verifica();" style="float: right;"/>
             </td>
         </tr>
		 <tr>
			<td>
				&nbsp;
			</td>
			<td>
				<div style="float: right;"> Remember me  <input type="checkbox" id="rememberMe" name="rememberMe"/></div>
		</td>
			</td>
         
     </table>
     </form>

 </body>
</html>