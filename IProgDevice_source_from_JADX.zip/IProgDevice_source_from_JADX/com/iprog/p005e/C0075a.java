package com.iprog.p005e;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0030f;
import com.iprog.p003d.C0035k;
import com.iprog.p004f.ab;
import com.iprog.p006g.C0104d;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class C0075a extends SQLiteOpenHelper {
    private static String f661a = "/data/data/com.iprog.device/databases/";
    private static String f662b = "iprog.sqlite";
    private SQLiteDatabase f663c;
    private final Context f664d;
    private SimpleDateFormat f665e = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private SimpleDateFormat f666f = new SimpleDateFormat("yyyy-MM-dd");
    private C0013d f667g = null;

    public C0075a(Context context) {
        super(context, f662b, null, 4);
        this.f664d = context;
        this.f667g = C0013d.m42d();
    }

    public static void m626a(Cursor cursor) {
        if (cursor != null) {
            try {
                cursor.close();
            } catch (Exception e) {
            }
        }
    }

    private boolean m627e() {
        SQLiteDatabase openDatabase;
        try {
            openDatabase = SQLiteDatabase.openDatabase(f661a + f662b, null, 1);
        } catch (Exception e) {
            C0104d.m828a(e);
            openDatabase = null;
        }
        if (openDatabase != null) {
            openDatabase.close();
        }
        return openDatabase != null;
    }

    private void m628f() {
        InputStream open = this.f664d.getAssets().open("data/" + f662b);
        OutputStream fileOutputStream = new FileOutputStream(f661a + f662b);
        byte[] bArr = new byte[1024];
        while (true) {
            int read = open.read(bArr);
            if (read <= 0) {
                fileOutputStream.flush();
                fileOutputStream.close();
                open.close();
                return;
            }
            fileOutputStream.write(bArr, 0, read);
        }
    }

    public int m629a(int i, String str, String str2, String str3, String str4, String str5) {
        return m643e(String.format(" update rp_chip_read \t\n   set company='%s'  \t\n      ,cat_num='%s'  \t\n      ,color='%s'  \t\n      ,tn_dr_name='%s'  \t\n      ,send_time='%s'    \n      ,send_yn='%s'    \n where _id = %d ", new Object[]{str, str2, str3, str4, m642d(), str5, Integer.valueOf(i)}));
    }

    public int m630a(ab abVar) {
        return m639c(String.format("insert into rp_version(reg_dt,type,version, file_name,file_hash,file_len)  VALUES ('%s','%s',%d,'%s','%s',%d )", new Object[]{abVar.f706s, abVar.f701n, Integer.valueOf(abVar.f702o), abVar.f707t, abVar.f703p, Integer.valueOf(abVar.f704q)}));
    }

    public Cursor m631a(String str) {
        C0104d.m832a("select sql:", str);
        Cursor rawQuery = this.f663c.rawQuery(str, null);
        rawQuery.moveToFirst();
        return rawQuery;
    }

    public ArrayList m632a(int i) {
        ArrayList arrayList = new ArrayList();
        Cursor cursor = null;
        try {
            String format = String.format("SELECT case when search_type=0 then 1 else search_type end as search_type       ,mdl_id,mdl_name,nat_cd       ,color,yield,cy_type  FROM rp_resent_work  WHERE job_type in(%d,%d,%d,%d,%d)  ORDER BY _id desc   LIMIT 30 ", new Object[]{Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(6)});
            if (i == 5) {
                format = String.format("SELECT search_type,mdl_id,mdl_name,nat_cd,       color,yield,cy_type  FROM rp_resent_work  WHERE job_type=%d  ORDER BY _id desc   LIMIT 30 ", new Object[]{Integer.valueOf(i)});
            }
            cursor = m631a(format);
            for (int i2 = 0; i2 < cursor.getCount(); i2++) {
                C0030f e = this.f667g.m91e(cursor.getString(1));
                if (e != null) {
                    arrayList.add(new C0035k(e, i2, cursor.getInt(0)));
                }
                cursor.moveToNext();
            }
            C0104d.m831a("recent data cnt:", arrayList.size());
        } catch (Exception e2) {
            C0104d.m828a(e2);
        } finally {
            C0075a.m626a(cursor);
        }
        return arrayList;
    }

    public boolean m633a() {
        if (!m627e()) {
            getReadableDatabase();
            try {
                m628f();
            } catch (Exception e) {
                C0104d.m828a(e);
                return false;
            }
        }
        return true;
    }

    public boolean m634a(int i, int i2, String str, String str2, String str3, String str4, int i3, int i4) {
        SQLiteDatabase sQLiteDatabase = null;
        try {
            this.f663c.beginTransaction();
            String format = String.format("DELETE FROM rp_resent_work  WHERE job_type in(%d,%d,%d,%d,%d)    AND mdl_id ='%s'    AND search_type = %d ", new Object[]{Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(6), str, Integer.valueOf(i)});
            if (i2 == 5) {
                format = String.format("DELETE FROM rp_resent_work  WHERE job_type=%d    AND mdl_id='%s'    AND search_type = %d ", new Object[]{Integer.valueOf(i2), str, Integer.valueOf(i)});
            }
            String format2 = String.format("insert into rp_resent_work(search_type,job_type,mdl_id,mdl_name,nat_cd,color,yield,cy_type,reg_dt)  VALUES (%d,%d,'%s','%s','%s','%s',%d,%d,'%s')", new Object[]{Integer.valueOf(i), Integer.valueOf(i2), str, str2, str3, str4, Integer.valueOf(i3), Integer.valueOf(i4), m642d()});
            C0104d.m832a("query", format2);
            C0104d.m832a("query", format);
            m641d(format);
            m639c(format2);
            this.f663c.setTransactionSuccessful();
        } catch (Exception e) {
            C0104d.m828a(e);
            return sQLiteDatabase;
        } finally {
            sQLiteDatabase = this.f663c;
            sQLiteDatabase.endTransaction();
        }
        return true;
    }

    public boolean m635a(int i, int i2, String str, String str2, String str3, String str4, int i3, int i4, int i5) {
        try {
            String format = String.format("insert into rp_work_his(search_type,job_type,mdl_id,mdl_name,nat_cd,color,yield,cy_type,reg_dt,err_cd,reg_time)  VALUES (%d,%d,'%s','%s','%s','%s',%d,%d,'%s',%d,%s)", new Object[]{Integer.valueOf(i), Integer.valueOf(i2), str, str2, str3, str4, Integer.valueOf(i3), Integer.valueOf(i4), m640c(), Integer.valueOf(i5), m640c()});
            C0104d.m832a("query", format);
            m639c(format);
            return true;
        } catch (Exception e) {
            C0104d.m828a(e);
            return false;
        }
    }

    public boolean m636a(boolean z, String str, String str2, String str3, String str4, int i, String str5, int i2) {
        int i3 = 2;
        String str6 = "insert into rp_chip_read( mdl_id,mdl_name,file_name,reg_dt,reg_time, file_size,chip_type,nat_cd,color,yield ) VALUES (  '%s','%s','%s','%s','%s',%d,%d,'%s','%s',%d )";
        Object[] objArr = new Object[10];
        objArr[0] = str;
        objArr[1] = str2;
        objArr[2] = str5;
        objArr[3] = m640c();
        objArr[4] = m642d();
        objArr[5] = Integer.valueOf(i2);
        if (z) {
            i3 = 1;
        }
        objArr[6] = Integer.valueOf(i3);
        objArr[7] = str3;
        objArr[8] = str4;
        objArr[9] = Integer.valueOf(i);
        m639c(String.format(str6, objArr));
        return true;
    }

    public int m637b(String str) {
        Cursor a = m631a(str);
        int i = a.getInt(0);
        C0104d.m831a("getCountQuery Result", i);
        C0075a.m626a(a);
        return i;
    }

    public void m638b() {
        this.f663c = SQLiteDatabase.openDatabase(f661a + f662b, null, 0);
    }

    public int m639c(String str) {
        try {
            this.f663c.execSQL(str);
            return 1;
        } catch (Exception e) {
            C0104d.m828a(e);
            return 0;
        }
    }

    public String m640c() {
        return this.f666f.format(new Date());
    }

    public synchronized void close() {
        if (this.f663c != null) {
            try {
                this.f663c.close();
            } catch (Exception e) {
            }
        }
        this.f663c = null;
        super.close();
    }

    public int m641d(String str) {
        return m639c(str);
    }

    public String m642d() {
        return this.f665e.format(new Date());
    }

    public int m643e(String str) {
        return m639c(str);
    }

    public ab m644f(String str) {
        ab abVar = new ab();
        Cursor cursor = null;
        try {
            cursor = m631a(String.format("SELECT reg_dt,type,version, file_name        ,file_hash,file_len   FROM rp_version  WHERE type='%s'  ORDER BY version desc , _id desc LIMIT 1 ", new Object[]{str}));
            if (cursor.getCount() > 0) {
                abVar.f706s = cursor.getString(0);
                abVar.f701n = cursor.getString(1);
                abVar.f702o = cursor.getInt(2);
                abVar.f707t = cursor.getString(3);
                abVar.f703p = cursor.getString(4);
                abVar.f704q = cursor.getInt(5);
            }
            C0104d.m831a("getUpgradeData data cnt:", cursor.getCount());
        } catch (Exception e) {
            C0104d.m828a(e);
        } finally {
            C0075a.m626a(cursor);
        }
        return abVar;
    }

    public int m645g(String str) {
        String format = String.format("DELETE FROM rp_version  WHERE type ='%s' ", new Object[]{str});
        C0104d.m830a(format);
        return m639c(format);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        C0104d.m832a("onCreate****", "DatabaseHelper");
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        C0104d.m830a("onUpgrade DatabaseHelper:" + i + "," + i2);
        onCreate(sQLiteDatabase);
    }
}
