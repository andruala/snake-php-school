package com.iprog.p003d;

import com.iprog.p006g.C0108h;
import java.util.ArrayList;
import java.util.Collections;

public class C0026b {
    public String[] f153a = null;
    public ArrayList f154b = new ArrayList();
    final /* synthetic */ C0025a f155c;

    public C0026b(C0025a c0025a) {
        this.f155c = c0025a;
    }

    public C0026b(C0025a c0025a, String[] strArr) {
        this.f155c = c0025a;
        this.f153a = strArr;
        m161a();
    }

    private void m161a() {
        if (this.f153a != null) {
            for (int i = 0; i < this.f153a.length; i++) {
                this.f153a[i] = this.f153a[i].trim();
            }
        }
    }

    public void m162a(String str) {
        this.f153a = str.split(C0025a.f110O);
        m161a();
    }

    public boolean m163a(String str, String str2) {
        this.f154b.add(new C0027c(this.f155c, str, str2));
        return true;
    }

    public int m164b(String str) {
        return C0108h.m846a(this.f153a, str);
    }

    public ArrayList m165b(String str, String str2) {
        ArrayList arrayList = new ArrayList();
        if (m164b(str) >= 0) {
            for (int i = 0; i < this.f154b.size(); i++) {
                int[] a = ((C0027c) this.f154b.get(i)).m167a(str2);
                if (a != null) {
                    return C0108h.m852a(a);
                }
            }
        }
        return arrayList;
    }

    public ArrayList m166c(String str) {
        Object arrayList = new ArrayList();
        if (m164b(str) >= 0) {
            for (int i = 0; i < this.f154b.size(); i++) {
                Collections.addAll(arrayList, ((C0027c) this.f154b.get(i)).f156a);
            }
        }
        return arrayList;
    }
}
