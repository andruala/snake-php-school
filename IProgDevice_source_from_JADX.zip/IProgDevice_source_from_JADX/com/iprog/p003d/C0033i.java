package com.iprog.p003d;

import com.iprog.p006g.C0101a;
import com.iprog.p006g.C0103c;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;

public class C0033i extends C0032h {
    int f184e = 0;

    public int mo1a(byte[] bArr, int i) {
        try {
            byte[] bytes = new String(C0101a.m819a(bArr, 0, bArr.length)).getBytes();
            this.a.write(bytes);
            this.a.write(10);
            this.c = (bytes.length + 1) + this.c;
            this.f184e += bArr.length;
            return bArr.length + 1;
        } catch (Exception e) {
            C0104d.m828a(e);
            return 0;
        }
    }

    public boolean mo2b(String str) {
        this.f184e = 0;
        m184a("/data/data/com.iprog.main/fileshid/");
        String format = String.format("%s%s_%s_%s.dat", new Object[]{"/data/data/com.iprog.main/fileshid/", str, C0103c.m824a("yyyyMMddhhmmss"), C0108h.m865b(3)});
        C0104d.m832a("ReadChipData File", format);
        return m188c(format);
    }
}
