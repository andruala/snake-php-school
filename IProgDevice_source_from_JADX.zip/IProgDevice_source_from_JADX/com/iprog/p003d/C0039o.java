package com.iprog.p003d;

public class C0039o {
    public int f218a;
    public int f219b;
    public String f220c = "";
    public String f221d = "";
    public String f222e = "";
    public String f223f = "";
    public int f224g;
    public String f225h = "";
}
