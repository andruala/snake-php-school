package com.iprog.p003d;

import android.graphics.Bitmap;

public class C0030f {
    public String f167a;
    public int f168b;
    public String f169c = "";
    public String f170d = "";
    public String f171e = "";
    public String f172f = "";
    public C0025a f173g = null;
    public C0025a f174h = null;

    public C0030f(C0025a c0025a) {
        m170a(c0025a);
    }

    private void m168b(C0025a c0025a) {
        this.f167a = c0025a.f127a;
        this.f168b = c0025a.f129c;
        this.f170d = c0025a.f131e;
        this.f171e = c0025a.f132f;
        this.f172f = c0025a.f133g;
        this.f169c = c0025a.f130d;
    }

    public C0025a m169a(boolean z) {
        return z ? this.f173g : this.f174h;
    }

    public void m170a(C0025a c0025a) {
        if (c0025a.f128b == 2) {
            this.f174h = c0025a;
        } else {
            this.f173g = c0025a;
        }
        m168b(c0025a);
    }

    public boolean m171a() {
        return (this.f174h != null && this.f174h.f145s) || (this.f173g != null && this.f173g.f145s);
    }

    public boolean m172a(int i) {
        try {
            return (this.f173g != null ? this.f173g.m153a(i) : false) || (this.f174h != null ? this.f174h.m153a(i) : false);
        } catch (Exception e) {
            return false;
        }
    }

    public int m173b(boolean z) {
        return (!z || this.f173g == null) ? (z || this.f174h == null) ? -1 : this.f174h.f144r : this.f173g.f144r;
    }

    public boolean m174b() {
        return this.f174h != null && this.f174h.f114A;
    }

    public Bitmap m175c(boolean z) {
        if (z) {
            if (this.f173g != null) {
                return this.f173g.f121H;
            }
        } else if (this.f174h != null) {
            return this.f174h.f121H;
        }
        return null;
    }

    public boolean m176c() {
        return this.f173g != null || (this.f174h != null && this.f174h.f152z);
    }

    public boolean m177d() {
        return this.f174h != null && this.f174h.f115B;
    }

    public boolean m178e() {
        return this.f174h != null && this.f174h.f151y;
    }

    public String m179f() {
        try {
            if (this.f173g != null) {
                return this.f173g.f142p;
            }
            if (this.f174h != null) {
                return this.f174h.f142p;
            }
            return "  ";
        } catch (Exception e) {
        }
    }

    public C0025a m180g() {
        return this.f173g != null ? this.f173g : this.f174h;
    }

    public Bitmap m181h() {
        return m175c(false) != null ? m175c(false) : m175c(true);
    }

    public String toString() {
        return String.format("cp_name:%s\nmdl_searries:%s\nmdl_name:%s\n_cp_mdl_name:%s\n", new Object[]{this.f169c, this.f170d, this.f171e, this.f172f});
    }
}
