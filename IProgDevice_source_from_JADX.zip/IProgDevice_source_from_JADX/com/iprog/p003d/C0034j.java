package com.iprog.p003d;

public class C0034j {
    public int f185a = 0;
    public int f186b = 5;
    public boolean f187c = false;
    public int f188d = 0;
    public int f189e = 0;
    public int f190f = 0;
    public String f191g = "";
    public String f192h = "";
    public String f193i = "";
    public int f194j = 0;
    public String f195k = "";
    public String f196l = "";
    public String f197m = "";
    public String f198n = "";
    public int f199o = 0;
    public int f200p = 0;
    public String f201q = "";
    public String f202r = "";
    public String f203s = "";
    public String f204t = "";
    public String f205u = "";
}
