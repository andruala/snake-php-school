package com.iprog.p003d;

public class C0038n {
    public int f215a = 0;
    public int f216b = 0;
    public int f217c = 0;

    public C0038n(int i, int i2, int i3) {
        this.f215a = i;
        this.f216b = i2;
        this.f217c = i3;
    }
}
