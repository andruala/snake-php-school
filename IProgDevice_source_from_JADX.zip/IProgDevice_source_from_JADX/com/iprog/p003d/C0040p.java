package com.iprog.p003d;

public class C0040p {
    public int f226a = 0;
    public int f227b;
    public String f228c = "";
    public String f229d = "";
    public C0039o f230e = new C0039o();
    public C0039o f231f = new C0039o();
    public C0039o f232g = new C0039o();
    public C0039o f233h = new C0039o();
}
