package com.iprog.p003d;

public class C0036l {
    public int f209a;
    public int f210b;
    public String f211c = "";
    public String f212d = "";
}
