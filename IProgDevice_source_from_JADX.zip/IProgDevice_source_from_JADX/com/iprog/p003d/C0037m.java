package com.iprog.p003d;

import com.iprog.p001b.C0013d;
import com.iprog.p002c.C0023a;
import com.iprog.p004f.ab;
import com.iprog.p005e.C0075a;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map.Entry;

public class C0037m {
    public HashMap f213a = new HashMap();
    ab f214b = null;

    private void m191d(ab abVar) {
        try {
            new File("/data/iprog/" + abVar.f707t).delete();
        } catch (Exception e) {
            C0104d.m830a("deleteFile");
        }
    }

    private boolean m192e(ab abVar) {
        try {
            if (abVar.f702o > 0 && abVar.f707t.length() > 3) {
                abVar.f705r = C0108h.m871f("/data/iprog/" + abVar.f707t);
                if (abVar.f704q != abVar.f705r.length) {
                    C0104d.m830a("**upgrade Data Load Error:");
                }
                if (!abVar.f703p.equals(C0023a.m139a(abVar.f705r))) {
                    C0104d.m830a("**upgrade Data Hash Error:");
                }
            }
            return true;
        } catch (Exception e) {
            C0104d.m828a(e);
            return false;
        }
    }

    private void m193j() {
        try {
            File file = new File("/data/iprog/");
            if (!file.exists()) {
                file.mkdirs();
            }
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }

    private String m194k() {
        return "/data/iprog/up_info.env";
    }

    public int m195a(String str, int i) {
        try {
            File file = new File(str);
            return ((Integer) Class.forName("android.os.FileUtils").getMethod("setPermissions", new Class[]{String.class, Integer.TYPE, Integer.TYPE, Integer.TYPE}).invoke(null, new Object[]{file.getAbsolutePath(), Integer.valueOf(i), Integer.valueOf(-1), Integer.valueOf(-1)})).intValue();
        } catch (Exception e) {
            C0104d.m829a(e, "changePermissions");
            return 0;
        }
    }

    public String m196a(int i) {
        switch (i) {
            case 113:
            case 114:
            case 115:
                return "FW";
            case 129:
            case 130:
            case 131:
                return "FD";
            case 133:
            case 134:
            case 135:
                return "XC";
            case 138:
            case 139:
            case 140:
                return "XR";
            default:
                return "";
        }
    }

    public void m197a(ab abVar) {
        this.f214b = abVar;
    }

    public void m198a(String str) {
        this.f213a.remove(str);
    }

    public boolean m199a() {
        return this.f213a.size() > 0;
    }

    public boolean m200a(C0038n c0038n) {
        BufferedWriter bufferedWriter;
        Exception e;
        Throwable th;
        try {
            String k = m194k();
            C0104d.m832a("saveUpgradeMsg:", k);
            bufferedWriter = new BufferedWriter(new FileWriter(k));
            try {
                bufferedWriter.write(String.format("%d,%d,%d", new Object[]{Integer.valueOf(c0038n.f215a), Integer.valueOf(c0038n.f216b), Integer.valueOf(c0038n.f217c)}));
                bufferedWriter.flush();
                if (bufferedWriter == null) {
                    return true;
                }
                try {
                    bufferedWriter.close();
                    return true;
                } catch (Exception e2) {
                    return true;
                }
            } catch (IOException e3) {
                e = e3;
                try {
                    C0104d.m828a(e);
                    if (bufferedWriter != null) {
                        try {
                            bufferedWriter.close();
                        } catch (Exception e4) {
                        }
                    }
                    return false;
                } catch (Throwable th2) {
                    th = th2;
                    if (bufferedWriter != null) {
                        try {
                            bufferedWriter.close();
                        } catch (Exception e5) {
                        }
                    }
                    throw th;
                }
            }
        } catch (IOException e6) {
            e = e6;
            bufferedWriter = null;
            C0104d.m828a(e);
            if (bufferedWriter != null) {
                bufferedWriter.close();
            }
            return false;
        } catch (Throwable th3) {
            th = th3;
            bufferedWriter = null;
            if (bufferedWriter != null) {
                bufferedWriter.close();
            }
            throw th;
        }
    }

    public ab m201b() {
        int i = 0;
        String[] strArr = new String[]{"SW", "FW", "FD", "XC", "XR"};
        while (i < strArr.length) {
            if (this.f213a.containsKey(strArr[i])) {
                return (ab) this.f213a.get(strArr[i]);
            }
            i++;
        }
        return null;
    }

    public void m202b(int i) {
        m198a(m196a(i));
    }

    public void m203b(ab abVar) {
        C0104d.m830a(String.format("Upgrade Add:%s,Length:%d", new Object[]{abVar.f701n, Integer.valueOf(abVar.f704q)}));
        if (abVar.f701n.equals("SW")) {
            abVar.f707t = String.format("%s_%s.apk", new Object[]{abVar.f701n, Integer.valueOf(abVar.f702o)});
        } else {
            abVar.f707t = String.format("%s_%s.dat", new Object[]{abVar.f701n, Integer.valueOf(abVar.f702o)});
        }
        this.f213a.put(abVar.f701n, abVar);
    }

    public boolean m204b(String str) {
        return this.f213a.containsKey(str);
    }

    public int m205c() {
        String[] strArr = new String[]{"FW", "FD", "XC", "XR"};
        int i = 0;
        for (int i2 = 0; i2 < strArr.length; i2++) {
            if (this.f213a.containsKey(strArr[i2])) {
                i += ((ab) this.f213a.get(strArr[i2])).f704q;
            }
        }
        return i;
    }

    public ab m206c(int i) {
        return m207c(m196a(i));
    }

    public ab m207c(String str) {
        C0104d.m830a(String.format("Upgrade get:%s", new Object[]{str}));
        return (ab) this.f213a.get(str);
    }

    public boolean m208c(ab abVar) {
        Exception e;
        Throwable th;
        OutputStream outputStream = null;
        String str = "/data/iprog/" + abVar.f707t;
        OutputStream fileOutputStream;
        try {
            C0104d.m832a("Upgrade Data dataSave:", str);
            m193j();
            fileOutputStream = new FileOutputStream(str);
            try {
                fileOutputStream.write(abVar.f705r);
                C0108h.m856a(fileOutputStream);
                m195a(str, 438);
                return true;
            } catch (IOException e2) {
                e = e2;
                try {
                    C0104d.m829a(e, "dataSave");
                    C0108h.m856a(fileOutputStream);
                    return false;
                } catch (Throwable th2) {
                    th = th2;
                    outputStream = fileOutputStream;
                    C0108h.m856a(outputStream);
                    throw th;
                }
            }
        } catch (IOException e3) {
            e = e3;
            fileOutputStream = null;
            C0104d.m829a(e, "dataSave");
            C0108h.m856a(fileOutputStream);
            return false;
        } catch (Throwable th3) {
            th = th3;
            C0108h.m856a(outputStream);
            throw th;
        }
    }

    public String m209d(String str) {
        return "/data/iprog/" + ((ab) this.f213a.get(str)).f707t;
    }

    public boolean m210d() {
        try {
            new File(m194k()).delete();
            return true;
        } catch (Exception e) {
            C0104d.m830a("detefileUpgradeMsg Error");
            return false;
        }
    }

    public void m211e(String str) {
        C0075a b = C0013d.m42d().m77b();
        ab f = b.m644f(str);
        b.m645g(str);
        m191d(f);
    }

    public boolean m212e() {
        C0104d.m830a("saveUpgradeData Start");
        C0075a b = C0013d.m42d().m77b();
        m193j();
        for (Entry entry : this.f213a.entrySet()) {
            if (!m208c((ab) entry.getValue())) {
                return false;
            }
            b.m630a((ab) entry.getValue());
        }
        return true;
    }

    public void m213f() {
        this.f213a.clear();
    }

    public C0038n m214g() {
        BufferedReader bufferedReader;
        Throwable th;
        BufferedReader bufferedReader2 = null;
        C0038n c0038n = new C0038n();
        try {
            bufferedReader = new BufferedReader(new FileReader(m194k()));
            try {
                String[] split = bufferedReader.readLine().trim().split(",");
                c0038n.f215a = C0108h.m844a(split[0]);
                c0038n.f216b = C0108h.m844a(split[1]);
                c0038n.f217c = C0108h.m844a(split[2]);
                if (bufferedReader != null) {
                    try {
                        bufferedReader.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e2) {
                if (bufferedReader != null) {
                    try {
                        bufferedReader.close();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                }
                return c0038n;
            } catch (Throwable th2) {
                Throwable th3 = th2;
                bufferedReader2 = bufferedReader;
                th = th3;
                if (bufferedReader2 != null) {
                    try {
                        bufferedReader2.close();
                    } catch (Exception e4) {
                        e4.printStackTrace();
                    }
                }
                throw th;
            }
        } catch (Exception e5) {
            bufferedReader = null;
            if (bufferedReader != null) {
                bufferedReader.close();
            }
            return c0038n;
        } catch (Throwable th4) {
            th = th4;
            if (bufferedReader2 != null) {
                bufferedReader2.close();
            }
            throw th;
        }
        return c0038n;
    }

    public void m215h() {
        int i = 0;
        C0075a b = C0013d.m42d().m77b();
        String[] strArr = new String[]{"SW", "FW", "FD", "XC", "XR"};
        while (i < strArr.length) {
            try {
                ab f = b.m644f(strArr[i]);
                if (!f.f701n.isEmpty()) {
                    b.m645g(f.f701n);
                }
            } catch (Exception e) {
                C0104d.m829a(e, "deleteUpgradeDataAll");
            }
            i++;
        }
    }

    public boolean m216i() {
        int i = 0;
        C0075a b = C0013d.m42d().m77b();
        String[] strArr = new String[]{"FW", "FD", "XC", "XR"};
        while (i < strArr.length) {
            ab f = b.m644f(strArr[i]);
            if (!f.f701n.isEmpty()) {
                m192e(f);
                m203b(f);
            }
            i++;
        }
        return true;
    }
}
