package com.iprog.p003d;

import com.iprog.p006g.C0101a;
import com.iprog.p006g.C0103c;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class C0032h {
    OutputStream f180a = null;
    final String f181b = "/data/data/com.iprog.main/files/";
    int f182c = 0;
    String f183d = "";

    public int mo1a(byte[] bArr, int i) {
        try {
            byte[] bytes = new String(C0101a.m819a(bArr, 0, bArr.length)).getBytes();
            this.f180a.write(bytes);
            this.f180a.write(10);
            this.f182c = (bytes.length + 1) + this.f182c;
            return bArr.length + 1;
        } catch (Exception e) {
            C0104d.m828a(e);
            return 0;
        }
    }

    public void m183a() {
        try {
            this.f180a.close();
        } catch (IOException e) {
        }
    }

    public void m184a(String str) {
        try {
            File file = new File(str);
            if (!file.exists()) {
                file.mkdirs();
            }
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }

    public int m185b() {
        return this.f182c;
    }

    public boolean mo2b(String str) {
        m184a("/data/data/com.iprog.main/files/");
        String format = String.format("%s%s_%s_%s.dat", new Object[]{"/data/data/com.iprog.main/files/", str, C0103c.m824a("yyyyMMddhhmmss"), C0108h.m865b(3)});
        C0104d.m832a("ReadChipData File", format);
        return m188c(format);
    }

    public String m187c() {
        return this.f183d;
    }

    public boolean m188c(String str) {
        this.f183d = str;
        try {
            this.f180a = new FileOutputStream(this.f183d);
            return true;
        } catch (Exception e) {
            C0104d.m828a(e);
            return false;
        }
    }
}
