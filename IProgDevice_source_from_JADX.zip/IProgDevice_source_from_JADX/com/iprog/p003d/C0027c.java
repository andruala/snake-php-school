package com.iprog.p003d;

import com.iprog.p006g.C0108h;

public class C0027c {
    public String[] f156a = null;
    public int[] f157b = null;
    final /* synthetic */ C0025a f158c;

    public C0027c(C0025a c0025a, String str, String str2) {
        int i = 0;
        this.f158c = c0025a;
        this.f156a = str.split(C0025a.f110O);
        String[] split = str2.split(C0025a.f110O);
        this.f157b = new int[split.length];
        for (int i2 = 0; i2 < split.length; i2++) {
            this.f157b[i2] = (int) (C0108h.m863b(split[i2]) * 1000.0d);
        }
        if (this.f156a != null) {
            while (i < this.f156a.length) {
                this.f156a[i] = this.f156a[i].trim();
                i++;
            }
        }
    }

    public int[] m167a(String str) {
        return C0108h.m846a(this.f156a, str) >= 0 ? this.f157b : null;
    }
}
