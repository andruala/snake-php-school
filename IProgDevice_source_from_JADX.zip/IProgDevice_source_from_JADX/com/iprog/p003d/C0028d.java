package com.iprog.p003d;

public class C0028d {
    public C0025a f159a = null;
    public int f160b = 0;
    public int f161c = 0;
    public int f162d = 0;

    public C0028d(C0025a c0025a, int i, int i2, int i3) {
        this.f159a = c0025a;
        this.f162d = i2;
        this.f161c = i3;
        this.f160b = i;
    }
}
