package com.iprog.p003d;

import java.util.HashMap;

public class C0041q {
    HashMap f234a;
    int f235b;

    public C0041q() {
        this.f234a = new HashMap();
        this.f235b = 0;
        this.f235b = 0;
    }

    public C0041q(int i) {
        this.f234a = new HashMap();
        this.f235b = 0;
        this.f235b = i;
    }

    public int m217a() {
        return this.f235b;
    }

    public String m218a(String str) {
        try {
            return (String) this.f234a.get(str);
        } catch (Exception e) {
            return "";
        }
    }

    public void m219a(int i) {
        this.f235b = i;
    }

    public void m220a(String str, Object obj) {
        this.f234a.put(str, obj);
    }

    public int m221b(String str) {
        try {
            return ((Integer) this.f234a.get(str)).intValue();
        } catch (Exception e) {
            return 0;
        }
    }

    public Object m222c(String str) {
        try {
            return this.f234a.get(str);
        } catch (Exception e) {
            return null;
        }
    }
}
