package com.iprog.p003d;

public class C0035k {
    public C0030f f206a = null;
    public int f207b = 0;
    public int f208c = 0;

    public C0035k(C0030f c0030f, int i, int i2) {
        this.f206a = c0030f;
        this.f208c = i;
        this.f207b = i2;
    }

    public String toString() {
        return this.f206a == null ? "null" : this.f206a.toString();
    }
}
