package com.iprog.p003d;

import android.graphics.Bitmap;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class C0025a {
    private static String f109N = "\\^";
    private static String f110O = ",";
    private static String f111P = ",";
    private static String f112Q = "#";
    private static String f113R = "@";
    public boolean f114A = false;
    public boolean f115B = false;
    public boolean f116C = false;
    public boolean f117D = false;
    public boolean f118E = false;
    public boolean f119F = false;
    public int f120G = 0;
    public Bitmap f121H = null;
    public int f122I = 0;
    public boolean f123J = false;
    String[] f124K = null;
    HashMap f125L = new HashMap();
    ArrayList f126M = new ArrayList();
    public String f127a = "";
    public int f128b = 0;
    public int f129c = 0;
    public String f130d = "";
    public String f131e = "";
    public String f132f = "";
    public String f133g = "";
    public String f134h = "";
    public String f135i = "";
    public int f136j = 0;
    public String f137k = "";
    public int f138l = 0;
    public int f139m = 0;
    public int f140n = 0;
    public List f141o = new ArrayList();
    public String f142p = "";
    public int f143q = 0;
    public int f144r = 0;
    public boolean f145s = false;
    public boolean f146t = false;
    public boolean f147u = false;
    public boolean f148v = false;
    public boolean f149w = false;
    public boolean f150x = false;
    public boolean f151y = false;
    public boolean f152z = false;

    public C0025a(String str) {
        m155a(str.split(f109N));
    }

    public String m150a() {
        return this.f137k.length() > 0 ? this.f137k : "";
    }

    public ArrayList m151a(String str) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.f126M.size(); i++) {
            arrayList.addAll(((C0026b) this.f126M.get(i)).m166c(str));
        }
        return arrayList;
    }

    public ArrayList m152a(String str, String str2) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.f126M.size(); i++) {
            arrayList.addAll(((C0026b) this.f126M.get(i)).m165b(str, str2));
        }
        return arrayList;
    }

    public boolean m153a(int i) {
        return i == 0 ? true : this.f141o.contains(Integer.valueOf(i));
    }

    public boolean m154a(String str, int i) {
        String[] split = str.split(f113R);
        C0026b c0026b;
        String[] split2;
        String[] split3;
        if (i == 2 || i == 3) {
            for (String split4 : split) {
                c0026b = new C0026b(this);
                split2 = split4.split(f112Q);
                split3 = split2[0].split("\\|");
                c0026b.m162a(split3[1]);
                c0026b.m163a(split3[0], split2[1]);
                this.f126M.add(c0026b);
            }
        } else if (i == 4) {
            for (String split5 : split) {
                String[] split6 = split5.split(f112Q);
                split2 = split6[1].split(f111P);
                split3 = split6[0].split(f111P);
                for (int i2 = 0; i2 < split3.length; i2++) {
                    C0026b c0026b2 = new C0026b(this);
                    String[] split7 = split3[i2].split("\\|");
                    c0026b2.m162a(split7[1]);
                    c0026b2.m163a(split7[0], split2[i2]);
                    this.f126M.add(c0026b2);
                }
            }
        } else {
            c0026b = new C0026b(this, this.f124K);
            for (String split42 : split) {
                split2 = split42.split(f112Q);
                c0026b.m163a(split2[0], split2[1]);
            }
            this.f126M.add(c0026b);
        }
        return true;
    }

    public boolean m155a(String[] strArr) {
        int i;
        int i2 = 0;
        this.f127a = strArr[0];
        this.f128b = C0108h.m844a(strArr[1]);
        this.f129c = C0108h.m844a(strArr[2]);
        this.f131e = C0108h.m848a(strArr[3], "ETC");
        this.f132f = strArr[4].trim();
        this.f134h = strArr[5];
        this.f135i = strArr[6];
        this.f124K = strArr[7].split(f110O);
        for (i = 0; i < this.f124K.length; i++) {
            this.f124K[i] = this.f124K[i].trim();
        }
        this.f136j = C0108h.m844a(strArr[9]);
        m154a(strArr[8], this.f136j);
        this.f137k = strArr[10].trim();
        this.f138l = C0108h.m844a(strArr[11]);
        String[] split = strArr[12].split(f110O);
        if (split.length >= 1) {
            this.f139m = C0108h.m844a(split[0]);
        }
        if (split.length >= 2) {
            this.f140n = C0108h.m844a(split[1]);
        }
        String[] split2 = strArr[13].split(f110O);
        i = 0;
        while (i < split2.length) {
            try {
                this.f141o.add(Integer.valueOf(C0108h.m844a(split2[i])));
                i++;
            } catch (Exception e) {
            }
        }
        this.f142p = strArr[14];
        this.f143q = C0108h.m844a(strArr[15]);
        this.f144r = C0108h.m844a(strArr[16]);
        if (this.f128b != 1 || this.f143q == 10) {
            this.f146t = C0108h.m866c(strArr[17]);
        } else {
            this.f146t = false;
        }
        this.f145s = C0108h.m866c(strArr[18]);
        this.f148v = C0108h.m866c(strArr[19]);
        this.f149w = C0108h.m866c(strArr[20]);
        this.f150x = C0108h.m866c(strArr[21]);
        this.f151y = C0108h.m866c(strArr[22]);
        this.f152z = C0108h.m866c(strArr[23]);
        this.f114A = C0108h.m866c(strArr[24]);
        this.f115B = C0108h.m866c(strArr[25]);
        this.f116C = C0108h.m866c(strArr[26]);
        this.f117D = C0108h.m866c(strArr[27]);
        this.f118E = C0108h.m866c(strArr[28]);
        this.f119F = C0108h.m866c(strArr[29]);
        this.f133g = strArr[30];
        split = strArr[31].split("\\|");
        while (i2 < split.length) {
            try {
                this.f125L.put(this.f124K[i2], split[i2].trim());
                i2++;
            } catch (Exception e2) {
                C0104d.m829a(e2, "*** Warning Nat View Error *******");
            }
        }
        this.f123J = C0108h.m866c(strArr[32]);
        if (this.f123J) {
            C0104d.m830a(" RSL: " + this.f132f);
        }
        return true;
    }

    public String m156b(String str) {
        try {
            if (this.f125L.containsKey(str)) {
                return (String) this.f125L.get(str);
            }
        } catch (Exception e) {
        }
        return "";
    }

    public ArrayList m157b() {
        Object arrayList = new ArrayList();
        Collections.addAll(arrayList, this.f124K);
        return arrayList;
    }

    public boolean m158c() {
        return this.f128b == 1;
    }

    public boolean m159d() {
        return this.f143q == 10;
    }

    public boolean m160e() {
        return this.f143q == 19 || this.f143q == 20;
    }
}
