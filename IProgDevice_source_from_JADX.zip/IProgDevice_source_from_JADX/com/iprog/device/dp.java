package com.iprog.device;

import com.iprog.p006g.C0104d;
import com.iprog.view.C0050m;

class dp implements C0050m {
    final /* synthetic */ C0051do f632a;

    dp(C0051do c0051do) {
        this.f632a = c0051do;
    }

    public void mo31a(int i, String str) {
        C0104d.m830a("view _cb_sum_type onclick:" + str + "," + this.f632a.f631t.m977c());
        this.f632a.f622k = i;
        try {
            this.f632a.m597j(0);
        } catch (Exception e) {
        }
    }
}
