package com.iprog.device;

import android.content.Context;
import android.os.Handler;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0029e;
import com.iprog.p003d.C0036l;
import com.iprog.p003d.C0041q;
import com.iprog.p004f.C0082d;
import com.iprog.p004f.C0099y;
import com.iprog.p004f.ac;
import com.iprog.p006g.C0101a;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0105e;
import com.iprog.view.aa;
import com.iprog.view.ar;
import com.iprog.view.ax;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.message.BasicNameValuePair;

public class aj extends cg {
    EditText[] f378a = new EditText[3];
    EditText[] f379b = new EditText[2];
    Button f380c = null;
    TextView f381d = null;
    TextView f382e = null;
    aa f383f = null;
    ar f384g = null;
    C0013d f385h = null;
    String f386i = "";
    ax f387j = new ak(this);
    OnClickListener f388k = new al(this);
    boolean f389l = false;
    OnTouchListener f390m = new am(this);
    final int f391n = 1;
    final int f392o = 2;
    final int f393p = 9;
    C0029e f394q = new C0029e();
    Handler f395r = new an(this);

    public aj(Context context) {
        super(context);
        m418b();
    }

    private void m411a(int i, int i2, String str) {
        new Thread(new ar(this, i, str, i2)).start();
    }

    private void m415a(String str) {
        mo9c();
        this.f385h.m64a(false);
        m240b(m248d(R.string.dlt_title_credit_err), str);
    }

    private C0036l m417b(int i, String str) {
        C0036l c0036l = new C0036l();
        if (!new ac().m712a(m428a(i, str), c0036l)) {
            c0036l.f210b = -1;
        }
        return c0036l;
    }

    private void m418b() {
        int i;
        m246c((int) R.layout.activity_credit_add, (int) R.string.str_pos_env_setting);
        this.f378a[0] = (EditText) findViewById(R.id.ed_credit1);
        this.f378a[1] = (EditText) findViewById(R.id.ed_credit2);
        this.f378a[2] = (EditText) findViewById(R.id.ed_credit3);
        this.f379b[0] = (EditText) findViewById(R.id.ed_pwd1);
        this.f379b[1] = (EditText) findViewById(R.id.ed_pwd2);
        this.f380c = (Button) findViewById(R.id.btn_save);
        this.f383f = new aa(getApplication());
        this.f383f.m904a(m248d(R.string.setting_nm_credit));
        this.f383f.m902a(1);
        this.f384g = new ar(getApplication());
        this.f385h = C0013d.m42d();
        InputMethodManager inputMethodManager = (InputMethodManager) getApplication().getSystemService("input_method");
        for (i = 0; i < this.f378a.length; i++) {
            this.f378a[i].setInputType(0);
            this.f378a[i].setOnTouchListener(this.f390m);
        }
        for (i = 0; i < this.f379b.length; i++) {
            this.f379b[i].setInputType(0);
            this.f379b[i].setOnTouchListener(this.f390m);
        }
        this.f380c.setOnClickListener(new ao(this));
        this.f383f.m903a(new aq(this));
    }

    private void m422c(int i, String str) {
        C0104d.m830a("processCreditAdd : " + str);
        C0099y c0099y = new C0099y();
        c0099y.m781d(i);
        c0099y.m783d(C0101a.m814a(str));
        C0082d.m729c().m732a(c0099y);
    }

    private void m423i(int i) {
        m415a(m426k(i));
    }

    private void m424j(int i) {
        mo9c();
        this.f385h.m64a(false);
        m254f(R.string.dlt_title_credit_err, i);
    }

    private boolean m425j() {
        int i = this.f394q.f166d;
        if (i >= 110) {
            i -= 110;
        }
        return ((this.f394q.f166d >= 110 && this.x.m110l()) || (this.f394q.f166d < 110 && !this.x.m110l())) && i == this.x.f58G;
    }

    private String m426k(int i) {
        int i2 = R.string.e_credit_send_unknown;
        if (i == 25205) {
            i2 = R.string.e_credit_already_reg;
        } else if (i == 25209) {
            i2 = R.string.e_credit_buy_cancel;
        } else if (i == 25201 || i == 25201 || i == 25202 || i == 25210) {
            i2 = R.string.e_credit_id_pwd;
        }
        return String.format("%s(%d)", new Object[]{m248d(i2), Integer.valueOf(i)});
    }

    private void m427k() {
        this.f385h.m64a(false);
        m254f(R.string.setting_nm_credit, R.string.credit_add_success);
    }

    public String m428a(int i, String str) {
        List arrayList = new ArrayList();
        arrayList.add(new BasicNameValuePair("msg_id", String.valueOf(i)));
        arrayList.add(new BasicNameValuePair("data", str));
        return C0105e.m836a(this.x.m111m(), arrayList);
    }

    public void mo3a() {
        this.f385h.m64a(false);
        this.f378a[0].setText("");
        this.f378a[1].setText("");
        this.f378a[2].setText("");
        this.f379b[0].setText("");
        this.f379b[1].setText("");
    }

    public void mo5a(C0041q c0041q) {
        try {
            C0104d.m830a("onStart DeviceInfoView:" + c0041q.m217a());
            c0041q.m217a();
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }

    public boolean mo8b(C0099y c0099y) {
        C0104d.m830a(String.format("onPacketReceive:%02x,%d,%d", new Object[]{Integer.valueOf(c0099y.m808w()), Integer.valueOf(c0099y.f807W), Integer.valueOf(c0099y.m763A())}));
        if (mo28a(c0099y.m763A()) && c0099y.m808w() != 241) {
            switch (c0099y.m808w()) {
                case 97:
                case 98:
                    m411a(c0099y.m808w(), c0099y.m808w() + 1, new String(C0101a.m818a(c0099y.m811z(), c0099y.m811z().length)));
                    break;
                default:
                    break;
            }
        }
        this.f385h.m64a(false);
        mo9c();
        m423i(c0099y.m763A());
        return true;
    }
}
