package com.iprog.device;

import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0040p;
import com.iprog.p004f.ac;
import com.iprog.p006g.C0105e;
import com.iprog.p006g.C0108h;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.message.BasicNameValuePair;

class be implements Runnable {
    final /* synthetic */ ay f448a;

    be(ay ayVar) {
        this.f448a = ayVar;
    }

    public void run() {
        Object valueOf = String.valueOf(this.f448a.f434g.f53B);
        if (C0013d.m42d().m110l()) {
            valueOf = String.valueOf(this.f448a.f434g.f53B + 16);
        }
        Object c0040p = new C0040p();
        List arrayList = new ArrayList();
        arrayList.add(new BasicNameValuePair("mtype", "LIST"));
        arrayList.add(new BasicNameValuePair("req", "IPROG"));
        arrayList.add(new BasicNameValuePair("device", this.f448a.f434g.m117q()));
        arrayList.add(new BasicNameValuePair("dev_id", this.f448a.f434g.m119r().replace("-", "")));
        arrayList.add(new BasicNameValuePair("xver", this.f448a.f434g.m131x(this.f448a.f434g.f94z)));
        arrayList.add(new BasicNameValuePair("appver", this.f448a.f434g.m115p()));
        arrayList.add(new BasicNameValuePair("os_ver", C0013d.m48x()));
        arrayList.add(new BasicNameValuePair("hw_ver", String.valueOf(valueOf)));
        arrayList.add(new BasicNameValuePair("xe_ver", String.valueOf(this.f448a.f434g.f53B)));
        arrayList.add(new BasicNameValuePair("hw_ver2", String.valueOf(this.f448a.f434g.f54C)));
        arrayList.add(new BasicNameValuePair("ver2", "X2"));
        if (new ac().m713a(C0105e.m836a(this.f448a.f434g.m114o(), arrayList), (C0040p) c0040p)) {
            C0108h.m853a(1000);
        }
        this.f448a.f434g.m70a(this.f448a.f441n, 1, c0040p);
    }
}
