package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.p006g.C0104d;

class ds implements OnClickListener {
    final /* synthetic */ C0051do f635a;

    ds(C0051do c0051do) {
        this.f635a = c0051do;
    }

    public void onClick(View view) {
        try {
            this.f635a.setMonthText(-1);
            this.f635a.m597j(0);
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }
}
