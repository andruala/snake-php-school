package com.iprog.device;

import com.iprog.view.C0058e;

class C0073y implements C0058e {
    final /* synthetic */ ChipInfoView f659a;

    C0073y(ChipInfoView chipInfoView) {
        this.f659a = chipInfoView;
    }

    public void mo34a(int i, boolean z) {
        this.f659a.m290n();
    }
}
