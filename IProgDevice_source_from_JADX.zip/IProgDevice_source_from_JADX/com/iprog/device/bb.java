package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class bb implements OnClickListener {
    final /* synthetic */ ay f445a;

    bb(ay ayVar) {
        this.f445a = ayVar;
    }

    public void onClick(View view) {
        this.f445a.m226a(0, (int) R.string.dlg_title_upgrade, (int) R.string.new_ver_find, true);
        this.f445a.m464k();
    }
}
