package com.iprog.device;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

class dl implements OnItemClickListener {
    final /* synthetic */ dk f609a;

    dl(dk dkVar) {
        this.f609a = dkVar;
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        if (i >= 0 && i < this.f609a.f605g.length) {
            this.f609a.m587i(i);
        }
    }
}
