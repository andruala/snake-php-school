package com.iprog.device;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.widget.TextView;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;

public class ax extends cg {
    TextView f423a = null;
    TextView f424b = null;
    TextView f425c = null;
    TextView f426d = null;
    TextView f427e = null;

    public ax(Context context) {
        super(context);
        m452b();
    }

    private void m452b() {
        m246c((int) R.layout.activity_device_info, (int) R.string.str_pos_env_setting);
        this.f423a = (TextView) findViewById(R.id.tv_version);
        this.f424b = (TextView) findViewById(R.id.tv_model);
        this.f425c = (TextView) findViewById(R.id.tv_bluetooth);
        this.f426d = (TextView) findViewById(R.id.tv_network);
        this.f427e = (TextView) findViewById(R.id.tv_connect);
        m453j();
    }

    private String getModelString() {
        String str = " ";
        if (this.x.f54C >= 18 && this.x.f54C <= 47) {
            str = String.format(":%02X", new Object[]{Integer.valueOf(this.x.f54C & 255)});
        } else if (this.x.f53B != 1) {
            str = String.format(":%02X", new Object[]{Integer.valueOf(this.x.f53B & 255)});
        }
        return String.format("%s ( %s%s)", new Object[]{this.x.m119r(), C0013d.m48x(), str});
    }

    private void m453j() {
        this.f423a.setText(C0013d.m42d().m115p());
        this.f424b.setText(getModelString());
        Object a = C0108h.m847a();
        TextView textView = this.f426d;
        if (a.isEmpty()) {
            a = m248d(R.string.net_disconnect);
        }
        textView.setText(new StringBuilder(String.valueOf(a)).append("\n(").append(C0108h.m872g("eth0")).append(")").toString());
        try {
            BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
            this.f425c.setText(defaultAdapter.getName() + "\n(" + defaultAdapter.getAddress() + ")");
        } catch (Exception e) {
        }
    }

    public void mo3a() {
    }

    public void mo5a(C0041q c0041q) {
        try {
            C0104d.m830a("onStart DeviceInfoView:" + c0041q.m217a());
            if (c0041q.m217a() == 0) {
                m453j();
            }
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }
}
