package com.iprog.device;

import android.os.Handler;
import android.os.Message;

class cl extends Handler {
    final /* synthetic */ IntroActivity f497a;

    cl(IntroActivity introActivity) {
        this.f497a = introActivity;
    }

    public void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                this.f497a.finish();
                return;
            default:
                return;
        }
    }
}
