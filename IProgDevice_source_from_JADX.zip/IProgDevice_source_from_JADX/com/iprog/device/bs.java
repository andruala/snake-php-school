package com.iprog.device;

import android.os.Handler;
import android.os.Message;
import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;

class bs extends Handler {
    final /* synthetic */ IProgActivity f467a;

    bs(IProgActivity iProgActivity) {
        this.f467a = iProgActivity;
    }

    public void handleMessage(Message message) {
        for (int i = 0; i < this.f467a.f314b.size(); i++) {
            if (((cg) this.f467a.f314b.get(i)).getResourceId() == message.what) {
                this.f467a.m386b((cg) this.f467a.f314b.get(i));
                ((cg) this.f467a.f314b.get(i)).mo5a(message.obj == null ? new C0041q() : (C0041q) message.obj);
                return;
            }
        }
        C0104d.m830a("View Handler Not Found");
    }
}
