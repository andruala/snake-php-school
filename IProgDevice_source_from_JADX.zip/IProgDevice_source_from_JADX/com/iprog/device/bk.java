package com.iprog.device;

import com.iprog.view.an;

class bk implements an {
    final /* synthetic */ IProgActivity f457a;

    bk(IProgActivity iProgActivity) {
        this.f457a = iProgActivity;
    }

    public void mo19a(int i) {
        this.f457a.m378a();
    }
}
