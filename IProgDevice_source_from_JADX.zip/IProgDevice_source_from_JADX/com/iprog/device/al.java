package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

class al implements OnClickListener {
    final /* synthetic */ aj f397a;

    al(aj ajVar) {
        this.f397a = ajVar;
    }

    public void onClick(View view) {
        this.f397a.f384g.m923a(this.f397a.f387j, view);
        this.f397a.f384g.m924a(((EditText) view).getText().toString());
    }
}
