package com.iprog.device;

import com.iprog.p001b.C0013d;
import com.iprog.p004f.C0099y;
import com.iprog.p006g.C0104d;

class cf extends Thread {
    long f483a;
    long f484b;
    int f485c;
    boolean f486d;
    final /* synthetic */ IProgActivity f487e;

    private cf(IProgActivity iProgActivity) {
        this.f487e = iProgActivity;
        this.f483a = System.currentTimeMillis();
        this.f484b = System.currentTimeMillis();
        this.f485c = 10000;
        this.f486d = false;
    }

    public void m480a() {
        this.f483a = System.currentTimeMillis();
        this.f484b = System.currentTimeMillis();
    }

    public void m481a(int i) {
        this.f483a = System.currentTimeMillis();
        this.f484b = System.currentTimeMillis();
        this.f485c = i;
    }

    public void m482b() {
        this.f486d = true;
        interrupt();
    }

    public void run() {
        C0104d.m830a("Upgrade TimeOutThread Start");
        while (!this.f486d) {
            try {
                sleep(1000);
                this.f484b = System.currentTimeMillis();
                if (((long) this.f485c) < this.f484b - this.f483a) {
                    C0104d.m830a("Upgrade Timeout :" + this.f485c);
                    C0099y c0099y = new C0099y();
                    c0099y.m781d(242);
                    c0099y.m794i(23205);
                    C0013d.m42d().m79b(c0099y, 3);
                    break;
                }
            } catch (InterruptedException e) {
                this.f486d = true;
            } catch (Exception e2) {
                C0104d.m829a(e2, "Upgrade TimeOutThread");
            }
        }
        C0104d.m830a("Upgrade TimeOutThread Stop");
    }
}
