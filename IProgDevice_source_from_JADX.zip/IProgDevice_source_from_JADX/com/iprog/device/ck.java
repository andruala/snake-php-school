package com.iprog.device;

class ck implements Runnable {
    final /* synthetic */ cg f494a;
    private final /* synthetic */ String f495b;
    private final /* synthetic */ String f496c;

    ck(cg cgVar, String str, String str2) {
        this.f494a = cgVar;
        this.f495b = str;
        this.f496c = str2;
    }

    public void run() {
        this.f494a.m232a(this.f495b, this.f496c);
    }
}
