package com.iprog.device;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.EditText;

class am implements OnTouchListener {
    final /* synthetic */ aj f398a;

    am(aj ajVar) {
        this.f398a = ajVar;
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f398a.f384g.m923a(this.f398a.f387j, view);
            this.f398a.f384g.m924a(((EditText) view).getText().toString());
        }
        return false;
    }
}
