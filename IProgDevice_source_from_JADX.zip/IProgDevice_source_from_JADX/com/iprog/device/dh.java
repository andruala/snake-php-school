package com.iprog.device;

import com.iprog.view.bw;

class dh implements bw {
    final /* synthetic */ df f596a;

    dh(df dfVar) {
        this.f596a = dfVar;
    }

    public void mo27a(int i) {
        if (i == 0) {
            this.f596a.m238b((int) R.layout.activity_search_recent);
        } else if (i == 1) {
            this.f596a.m238b((int) R.layout.activity_search_model);
        } else if (i == 2) {
            this.f596a.m238b((int) R.layout.activity_search_cp);
        }
    }
}
