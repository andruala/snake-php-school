package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class C0063o implements OnClickListener {
    final /* synthetic */ ChipInfoView f649a;

    C0063o(ChipInfoView chipInfoView) {
        this.f649a = chipInfoView;
    }

    public void onClick(View view) {
        this.f649a.m291o();
    }
}
