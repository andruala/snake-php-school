package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class di implements OnClickListener {
    final /* synthetic */ df f597a;

    di(df dfVar) {
        this.f597a = dfVar;
    }

    public void onClick(View view) {
        this.f597a.m576i(0);
    }
}
