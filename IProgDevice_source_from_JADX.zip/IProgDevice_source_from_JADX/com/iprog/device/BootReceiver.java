package com.iprog.device;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.iprog.p006g.C0104d;

public class BootReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        C0104d.m830a("BootReceiver:" + intent.getAction());
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
            Intent intent2 = new Intent(context, IProgActivity.class);
            intent2.addFlags(268435456);
            context.startActivity(intent2);
        } else if (!intent.getAction().equals("android.intent.action.SCREEN_OFF")) {
            intent.getAction().equals("android.intent.action.SCREEN_OFF");
        }
    }
}
