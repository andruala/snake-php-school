package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class C0046c implements OnClickListener {
    final /* synthetic */ C0042a f475a;

    C0046c(C0042a c0042a) {
        this.f475a = c0042a;
    }

    public void onClick(View view) {
        this.f475a.x.m112m(20);
    }
}
