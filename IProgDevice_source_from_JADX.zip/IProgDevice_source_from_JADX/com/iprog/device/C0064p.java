package com.iprog.device;

import com.iprog.p006g.C0108h;
import com.iprog.view.C0050m;

class C0064p implements C0050m {
    final /* synthetic */ ChipInfoView f650a;

    C0064p(ChipInfoView chipInfoView) {
        this.f650a = chipInfoView;
    }

    public void mo31a(int i, String str) {
        this.f650a.m290n();
        this.f650a.setTitle(this.f650a.f246F.m973b());
        int a = C0108h.m844a(this.f650a.f246F.m977c());
        if (a == 6 || a == 4 || a == 3) {
            this.f650a.f250J.setText("0");
            try {
                this.f650a.f247G.setEnabled(this.f650a.f267c.m71a(this.f650a.f280p.f174h, a));
                return;
            } catch (Exception e) {
                this.f650a.f247G.setEnabled(false);
                return;
            }
        }
        if (this.f650a.f267c.f58G == 0) {
            this.f650a.m302z();
        } else {
            this.f650a.f250J.setText("");
        }
        this.f650a.m298v();
    }
}
