package com.iprog.device;

public final class cv {
    public static final int[] CalcView = new int[]{R.attr.text_style};
    public static final int CalcView_text_style = 0;
    public static final int[] CheckBoxEx = new int[]{R.attr.checkbox_icon, R.attr.checkbox_text};
    public static final int CheckBoxEx_checkbox_icon = 0;
    public static final int CheckBoxEx_checkbox_text = 1;
    public static final int[] CheckableLinearLayout = new int[]{R.attr.checkable};
    public static final int CheckableLinearLayout_checkable = 0;
    public static final int[] ChipSearchView = new int[]{R.attr.page_area, R.attr.col_size};
    public static final int ChipSearchView_col_size = 1;
    public static final int ChipSearchView_page_area = 0;
    public static final int[] IProgItem = new int[]{R.attr.item_image, R.attr.item_name};
    public static final int IProgItem_item_image = 0;
    public static final int IProgItem_item_name = 1;
    public static final int[] SearchTextView = new int[]{R.attr.layout_view};
    public static final int SearchTextView_layout_view = 0;
}
