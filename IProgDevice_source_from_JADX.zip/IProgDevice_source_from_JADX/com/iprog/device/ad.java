package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.p006g.C0104d;

class ad implements OnClickListener {
    final /* synthetic */ ab f372a;

    ad(ab abVar) {
        this.f372a = abVar;
    }

    public void onClick(View view) {
        try {
            this.f372a.setMonthText(-1);
            this.f372a.m400i(0);
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }
}
