package com.iprog.device;

import com.iprog.view.C0048b;

class dc implements C0048b {
    final /* synthetic */ db f585a;

    dc(db dbVar) {
        this.f585a = dbVar;
    }

    public void mo29a(int i) {
        if (i == 10) {
            this.f585a.f580d.m891a();
        } else if (i == 11) {
            this.f585a.f580d.m894b();
        } else {
            this.f585a.f580d.m893a(Integer.toString(i));
        }
        this.f585a.m566a(this.f585a.f580d.getData());
    }
}
