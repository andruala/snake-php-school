package com.iprog.device;

class cj implements Runnable {
    final /* synthetic */ cg f491a;
    private final /* synthetic */ int f492b;
    private final /* synthetic */ int f493c;

    cj(cg cgVar, int i, int i2) {
        this.f491a = cgVar;
        this.f492b = i;
        this.f493c = i2;
    }

    public void run() {
        this.f491a.m249d(this.f492b, this.f493c);
    }
}
