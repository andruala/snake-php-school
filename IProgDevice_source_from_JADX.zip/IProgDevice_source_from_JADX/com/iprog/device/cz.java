package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class cz implements OnClickListener {
    final /* synthetic */ cw f537a;

    cz(cw cwVar) {
        this.f537a = cwVar;
    }

    public void onClick(View view) {
        this.f537a.m514i(0);
    }
}
