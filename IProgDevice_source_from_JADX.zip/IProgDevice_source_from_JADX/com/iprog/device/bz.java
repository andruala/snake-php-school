package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class bz implements OnClickListener {
    final /* synthetic */ IProgActivity f474a;

    bz(IProgActivity iProgActivity) {
        this.f474a = iProgActivity;
    }

    public void onClick(View view) {
        this.f474a.f310X.m69a(this.f474a.f310X.f77i, 1);
    }
}
