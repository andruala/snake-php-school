package com.iprog.device;

import com.iprog.view.C0058e;

class C0072x implements C0058e {
    final /* synthetic */ ChipInfoView f658a;

    C0072x(ChipInfoView chipInfoView) {
        this.f658a = chipInfoView;
    }

    public void mo34a(int i, boolean z) {
        this.f658a.m290n();
    }
}
