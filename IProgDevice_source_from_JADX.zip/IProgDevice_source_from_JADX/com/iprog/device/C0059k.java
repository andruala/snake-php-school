package com.iprog.device;

import com.iprog.view.C0058e;

class C0059k implements C0058e {
    final /* synthetic */ C0047d f642a;

    C0059k(C0047d c0047d) {
        this.f642a = c0047d;
    }

    public void mo34a(int i, boolean z) {
        this.f642a.m542o();
    }
}
