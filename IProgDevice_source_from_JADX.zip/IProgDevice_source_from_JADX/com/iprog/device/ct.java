package com.iprog.device;

import com.iprog.p006g.C0104d;

class ct implements Runnable {
    final /* synthetic */ cs f523a;

    ct(cs csVar) {
        this.f523a = csVar;
    }

    public void run() {
        try {
            this.f523a.f522a.f503f.setText(this.f523a.f522a.f514q[this.f523a.f522a.f515r % this.f523a.f522a.f514q.length]);
            cm a = this.f523a.f522a;
            a.f515r++;
        } catch (Exception e) {
            C0104d.m829a(e, "Help Message");
        }
    }
}
