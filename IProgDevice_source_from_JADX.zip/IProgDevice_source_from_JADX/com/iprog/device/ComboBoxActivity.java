package com.iprog.device;

import android.app.Activity;
import android.content.res.Resources.Theme;
import android.os.Bundle;

public class ComboBoxActivity extends Activity {
    protected void onApplyThemeResource(Theme theme, int i, boolean z) {
        super.onApplyThemeResource(theme, i, z);
        theme.applyStyle(16973913, true);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dlg_popup_list);
    }
}
