package com.iprog.device;

import com.iprog.view.bw;

class cx implements bw {
    final /* synthetic */ cw f535a;

    cx(cw cwVar) {
        this.f535a = cwVar;
    }

    public void mo27a(int i) {
        if (i == 0) {
            this.f535a.m238b((int) R.layout.activity_search_recent);
        } else if (i == 1) {
            this.f535a.m238b((int) R.layout.activity_search_model);
        } else if (i == 2) {
            this.f535a.m238b((int) R.layout.activity_search_cp);
        }
    }
}
