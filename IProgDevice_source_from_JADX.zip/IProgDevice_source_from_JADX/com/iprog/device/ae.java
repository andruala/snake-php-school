package com.iprog.device;

import com.iprog.p000a.C0002c;

class ae implements C0002c {
    final /* synthetic */ ab f373a;

    ae(ab abVar) {
        this.f373a = abVar;
    }

    public void mo14a(int i) {
        if (i >= 0 && i < this.f373a.f369q.size()) {
            this.f373a.f362j = i;
            this.f373a.f361i.m918b(this.f373a.m248d(R.string.dlg_data_send_body));
            this.f373a.f361i.show();
        }
    }
}
