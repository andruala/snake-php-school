package com.iprog.device;

class bq implements Runnable {
    final /* synthetic */ IProgActivity f463a;
    private final /* synthetic */ int f464b;

    bq(IProgActivity iProgActivity, int i) {
        this.f463a = iProgActivity;
        this.f464b = i;
    }

    public void run() {
        this.f463a.f323k.m941b(this.f464b);
    }
}
