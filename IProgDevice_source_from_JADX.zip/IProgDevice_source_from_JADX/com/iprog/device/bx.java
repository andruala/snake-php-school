package com.iprog.device;

import android.os.Handler;
import android.os.Message;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;

class bx extends Handler {
    final /* synthetic */ IProgActivity f472a;

    bx(IProgActivity iProgActivity) {
        this.f472a = iProgActivity;
    }

    public void handleMessage(Message message) {
        C0104d.m830a("_timeout_handler Message:" + message.what);
        if (message.what == 1) {
            this.f472a.f302P = true;
            this.f472a.m350f();
        } else if (message.what == 2) {
            this.f472a.f319g.m918b(new StringBuilder(String.valueOf(this.f472a.getString(R.string.system_error_stop_reboot))).append("(").append(24994).append(")").toString());
            this.f472a.m367m();
            C0108h.m853a(100);
            this.f472a.m368n();
            this.f472a.f319g.show();
        } else if (message.what == 3) {
            IProgActivity iProgActivity = this.f472a;
            iProgActivity.f336x++;
        }
    }
}
