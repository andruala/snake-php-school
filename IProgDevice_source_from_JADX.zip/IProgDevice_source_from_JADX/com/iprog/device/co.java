package com.iprog.device;

import android.graphics.Color;
import android.view.View;
import android.widget.TextView;
import android.widget.ViewSwitcher.ViewFactory;

class co implements ViewFactory {
    final /* synthetic */ cm f518a;

    co(cm cmVar) {
        this.f518a = cmVar;
    }

    public View makeView() {
        View textView = new TextView(this.f518a.getContext());
        textView.setGravity(17);
        textView.setTextColor(Color.rgb(0, 0, 0));
        textView.setShadowLayer(0.5f, 1.0f, 1.0f, Color.rgb(255, 255, 255));
        textView.setTextSize(16.0f);
        textView.setHeight(70);
        return textView;
    }
}
