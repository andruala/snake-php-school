package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.p006g.C0104d;

class ac implements OnClickListener {
    final /* synthetic */ ab f371a;

    ac(ab abVar) {
        this.f371a = abVar;
    }

    public void onClick(View view) {
        try {
            this.f371a.setMonthText(1);
            this.f371a.m400i(0);
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }
}
