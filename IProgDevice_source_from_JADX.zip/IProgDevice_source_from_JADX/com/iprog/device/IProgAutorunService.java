package com.iprog.device;

import android.app.Service;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.IBinder;
import com.iprog.p006g.C0104d;

public class IProgAutorunService extends Service {
    public IBinder onBind(Intent intent) {
        C0104d.m830a("IProgAutorunService onBind");
        return null;
    }

    public void onConfigurationChanged(Configuration configuration) {
        getPackageManager();
        super.onConfigurationChanged(configuration);
    }

    public void onCreate() {
        C0104d.m830a("IProgAutorunService onCreate");
        super.onCreate();
    }

    public void onDestroy() {
        C0104d.m830a("IProgAutorunService onDestroy");
        super.onDestroy();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        boolean z = true;
        if (intent != null && intent.getBooleanExtra("START", false)) {
            z = false;
        }
        if (z) {
            Intent intent2 = new Intent(getApplication(), IProgActivity.class);
            intent2.addFlags(268435456);
            getApplication().startActivity(intent2);
        }
        return super.onStartCommand(intent, i, i2);
    }

    public boolean onUnbind(Intent intent) {
        C0104d.m830a("IProgAutorunService onUnbind");
        return super.onUnbind(intent);
    }
}
