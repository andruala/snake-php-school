package com.iprog.device;

import android.os.Handler;
import android.os.Message;
import com.iprog.p003d.C0040p;
import com.iprog.p006g.C0104d;

class az extends Handler {
    final /* synthetic */ ay f442a;

    az(ay ayVar) {
        this.f442a = ayVar;
    }

    public void handleMessage(Message message) {
        C0104d.m830a(" _handler:" + message.what);
        switch (message.what) {
            case 1:
                this.f442a.mo9c();
                C0040p c0040p = (C0040p) message.obj;
                if (c0040p.f226a == 1) {
                    if (this.f442a.f434g.m72a(c0040p.f230e.f221d, c0040p.f231f.f221d)) {
                        this.f442a.f431d.setText(R.string.ver_msg_new);
                        this.f442a.f439l = true;
                    } else {
                        this.f442a.f431d.setText(R.string.ver_msg_equal);
                        this.f442a.f439l = false;
                    }
                    this.f442a.f429b.setText(c0040p.f228c);
                    this.f442a.f430c.setText(c0040p.f229d);
                    this.f442a.f435h = c0040p;
                    this.f442a.f440m = true;
                    return;
                }
                this.f442a.f431d.setText(R.string.ver_msg_info_fail);
                this.f442a.f429b.setText("");
                this.f442a.f430c.setText("");
                this.f442a.f440m = false;
                return;
            default:
                return;
        }
    }
}
