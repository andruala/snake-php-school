package com.iprog.device;

class ag implements Runnable {
    final /* synthetic */ af f375a;

    ag(af afVar) {
        this.f375a = afVar;
    }

    public void run() {
        this.f375a.f374a.m401j();
    }
}
