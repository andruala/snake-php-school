package com.iprog.device;

import com.iprog.p006g.C0104d;
import com.iprog.view.C0050m;

class C0070v implements C0050m {
    final /* synthetic */ ChipInfoView f656a;

    C0070v(ChipInfoView chipInfoView) {
        this.f656a = chipInfoView;
    }

    public void mo31a(int i, String str) {
        C0104d.m830a("view _cb_color_ctrl onclick:" + str);
        this.f656a.m290n();
        this.f656a.m270c(this.f656a.f243C.m973b(), str);
    }
}
