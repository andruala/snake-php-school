package com.iprog.device;

import com.iprog.p004f.C0099y;
import com.iprog.view.ba;

class C0065q implements ba {
    final /* synthetic */ ChipInfoView f651a;

    C0065q(ChipInfoView chipInfoView) {
        this.f651a = chipInfoView;
    }

    public void mo26a(C0099y c0099y) {
        this.f651a.m303a(c0099y);
        this.f651a.f273i.m926a();
    }
}
