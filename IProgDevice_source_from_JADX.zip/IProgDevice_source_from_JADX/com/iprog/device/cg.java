package com.iprog.device;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0041q;
import com.iprog.p004f.C0082d;
import com.iprog.p004f.C0099y;
import com.iprog.p005e.C0075a;
import com.iprog.p006g.C0104d;
import com.iprog.view.ai;
import com.iprog.view.ak;
import com.iprog.view.bs;

public abstract class cg extends LinearLayout {
    ai f236A = null;
    private int f237a = 0;
    public Context f238w = null;
    C0013d f239x = C0013d.m42d();
    String f240y = "";
    bs f241z = null;

    public cg(Context context) {
        super(context);
        this.f238w = context;
    }

    public cg(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f238w = context;
    }

    private void mo6a(bs bsVar) {
        if (bsVar != null) {
            try {
                if (bsVar.isShowing()) {
                    bsVar.dismiss();
                }
            } catch (Exception e) {
            }
        }
    }

    public int m224a(C0099y c0099y, boolean z) {
        new Thread(new ch(this, c0099y)).start();
        return 1;
    }

    public void mo3a() {
        C0104d.m830a("ResetViewView onStop()");
    }

    protected void m226a(int i, int i2, int i3, boolean z) {
        mo4a(i, m248d(i2), m248d(i3), z);
    }

    public void m227a(int i, C0041q c0041q) {
        this.f239x.m82b(this.f239x.f76h, i, (Object) c0041q);
    }

    public void m228a(int i, C0041q c0041q, int i2) {
        if (i2 == 5) {
            m227a((int) R.layout.activity_chip_check, c0041q);
        } else {
            m227a((int) R.layout.activity_chip_info, c0041q);
        }
    }

    protected void mo4a(int i, String str, String str2, boolean z) {
        mo9c();
        try {
            this.f241z = new bs(getContext());
            this.f241z.m948a(i);
            this.f241z.m950a(str);
            this.f241z.m952b(str2);
            this.f241z.m951a(z);
            this.f241z.m949a(new ci(this));
            this.f241z.show();
        } catch (Exception e) {
            C0104d.m829a(e, "showProgress");
        }
    }

    public void mo5a(C0041q c0041q) {
        C0104d.m830a("ResetViewView onStart()");
    }

    protected void m231a(ai aiVar) {
        if (aiVar != null) {
            try {
                if (aiVar.isShowing()) {
                    aiVar.dismiss();
                }
            } catch (Exception e) {
            }
        }
    }

    protected void m232a(String str, String str2) {
        m233a(str, str2, 2);
    }

    protected void m233a(String str, String str2, int i) {
        m234a(str, str2, i, null);
    }

    protected void m234a(String str, String str2, int i, ak akVar) {
        try {
            mo9c();
            m231a(this.f236A);
            this.f236A = new ai(getApplication());
            this.f236A.m916a(str);
            this.f236A.m918b(str2);
            this.f236A.m917b(i);
            this.f236A.m915a(akVar);
            this.f236A.show();
        } catch (Exception e) {
            C0104d.m829a(e, "AlertDialog");
        }
    }

    public void mo12a(boolean z) {
    }

    public boolean mo28a(int i) {
        return (i == 0 || i == 1) ? true : i >= 17000 && i <= 17999;
    }

    public boolean mo7a(int i, int i2) {
        return true;
    }

    public void m238b(int i) {
        this.f239x.m82b(this.f239x.f76h, i, new C0041q());
    }

    public void m239b(int i, C0041q c0041q) {
        this.f239x.m60a(i, (Object) c0041q);
    }

    protected void m240b(String str, String str2) {
        ((Activity) getApplication()).runOnUiThread(new ck(this, str, str2));
    }

    public boolean mo8b(C0099y c0099y) {
        return false;
    }

    public int m242c(C0099y c0099y) {
        return m224a(c0099y, false);
    }

    public Object m243c(int i) {
        return m244c(i, null);
    }

    public Object m244c(int i, C0041q c0041q) {
        C0041q c0041q2 = new C0041q(1);
        if (c0041q == null) {
            c0041q = new C0041q(1);
        }
        c0041q.m219a(1);
        c0041q2.m220a("view", Integer.valueOf(i));
        c0041q2.m220a("arg", c0041q);
        return c0041q2;
    }

    protected void mo9c() {
        mo6a(this.f241z);
    }

    public void m246c(int i, int i2) {
        this.f237a = i;
        ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(i, this, true);
        if (i2 != 0) {
            this.f240y = getContext().getString(i2);
        }
    }

    public Object mo13d() {
        return null;
    }

    public String m248d(int i) {
        return getContext().getString(i);
    }

    protected void m249d(int i, int i2) {
        m232a(m248d(i), m248d(i2));
    }

    public void mo22e() {
    }

    protected boolean m251e(int i, int i2) {
        this.f239x.ag = i2;
        this.f239x.ah = i;
        m260i();
        return true;
    }

    public String[] m252e(int i) {
        return getContext().getResources().getStringArray(i);
    }

    public String m253f(int i) {
        return this.f239x.m118q(i);
    }

    protected void m254f(int i, int i2) {
        ((Activity) getApplication()).runOnUiThread(new cj(this, i, i2));
    }

    public boolean m255f() {
        return true;
    }

    public String m256g(int i) {
        return this.f239x.m116p(i);
    }

    public void mo23g() {
    }

    public Context getApplication() {
        return this.f238w;
    }

    public C0075a getDatabase() {
        return this.f239x.m77b();
    }

    public int getResourceId() {
        return this.f237a;
    }

    public String getTitleName() {
        int i = R.string.str_pos_reset;
        if (this.f240y.length() >= 1) {
            return this.f240y;
        }
        switch (this.f239x.f88t) {
            case 1:
            case 2:
                break;
            case 3:
                i = R.string.str_pos_com_change;
                break;
            case 4:
                i = R.string.str_pos_com_upgrade;
                break;
            case 5:
                i = R.string.str_pos_com_check;
                break;
            case 6:
                i = R.string.str_pos_data_read;
                break;
            default:
                return "";
        }
        return getContext().getString(i);
    }

    public Object getViewData() {
        return null;
    }

    public int getWorkType() {
        return this.f239x.f88t;
    }

    public String mo33h() {
        return getTitleName();
    }

    public boolean m259h(int i) {
        return i >= 17000 && i <= 17999;
    }

    protected boolean m260i() {
        String d = m248d(R.string.dlg_title_application);
        if (this.f239x.ag == 1) {
            return false;
        }
        if (this.f239x.ah == 1) {
            this.f239x.ah = R.string.system_error_stop_reboot;
        }
        m232a(d, m248d(this.f239x.ah) + "(" + this.f239x.ag + ":1)");
        return true;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    protected void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
    }

    public void setCredit(int i) {
        Object c0041q = new C0041q();
        c0041q.m220a("credit", Integer.valueOf(i));
        this.f239x.m60a(2, c0041q);
    }

    public void setSessionTime(boolean z) {
        C0082d c = C0082d.m729c();
        if (z) {
            c.m734b(1);
        } else {
            c.m734b(2);
        }
    }

    public void setTitle(String str) {
        C0041q c0041q = new C0041q();
        c0041q.m220a("title", str);
        m239b(16, c0041q);
    }

    public void setView(int i) {
        m246c(i, 0);
    }
}
