package com.iprog.device;

class br implements Runnable {
    final /* synthetic */ IProgActivity f465a;
    private final /* synthetic */ String f466b;

    br(IProgActivity iProgActivity, String str) {
        this.f465a = iProgActivity;
        this.f466b = str;
    }

    public void run() {
        this.f465a.f323k.m942b(this.f466b);
    }
}
