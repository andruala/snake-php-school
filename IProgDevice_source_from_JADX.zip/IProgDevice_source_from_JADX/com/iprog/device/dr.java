package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.p006g.C0104d;

class dr implements OnClickListener {
    final /* synthetic */ C0051do f634a;

    dr(C0051do c0051do) {
        this.f634a = c0051do;
    }

    public void onClick(View view) {
        try {
            this.f634a.setMonthText(1);
            this.f634a.m597j(0);
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }
}
