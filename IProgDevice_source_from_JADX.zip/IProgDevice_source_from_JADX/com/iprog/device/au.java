package com.iprog.device;

import android.app.TimePickerDialog.OnTimeSetListener;
import android.widget.TimePicker;

class au implements OnTimeSetListener {
    final /* synthetic */ as f420a;

    au(as asVar) {
        this.f420a = asVar;
    }

    public void onTimeSet(TimePicker timePicker, int i, int i2) {
        this.f420a.f415h = i;
        this.f420a.f416i = i2;
        this.f420a.m451b(i, i2);
    }
}
