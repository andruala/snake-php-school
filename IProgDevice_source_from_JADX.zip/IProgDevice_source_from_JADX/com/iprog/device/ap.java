package com.iprog.device;

import com.iprog.p003d.C0029e;
import com.iprog.p004f.ac;

class ap implements Runnable {
    final /* synthetic */ ao f401a;
    private final /* synthetic */ String f402b;

    ap(ao aoVar, String str) {
        this.f401a = aoVar;
        this.f402b = str;
    }

    public void run() {
        Object c0029e = new C0029e();
        if (!new ac().m711a(this.f401a.f400a.m428a(105, this.f402b), (C0029e) c0029e)) {
            this.f401a.f400a.m424j(R.string.e_credit_send_error);
        } else if (c0029e.f163a.f210b == 1) {
            this.f401a.f400a.x.m70a(this.f401a.f400a.f395r, 1, c0029e);
        } else {
            this.f401a.f400a.m423i(c0029e.f163a.f210b);
        }
    }
}
