package com.iprog.device;

import com.iprog.view.bu;

class ci implements bu {
    final /* synthetic */ cg f490a;

    ci(cg cgVar) {
        this.f490a = cgVar;
    }

    public void mo21a(int i, int i2) {
    }
}
