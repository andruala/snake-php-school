package com.iprog.device;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.iprog.p006g.C0104d;

class bt extends Handler {
    final /* synthetic */ IProgActivity f468a;

    bt(IProgActivity iProgActivity) {
        this.f468a = iProgActivity;
    }

    public void handleMessage(Message message) {
        C0104d.m830a("_manager_handler:" + message.what);
        switch (message.what) {
            case 10:
                Bundle bundle = (Bundle) message.obj;
                this.f468a.m327a(true, (String) bundle.get("name"), (String) bundle.get("address"));
                return;
            case 11:
                this.f468a.m327a(false, "", "");
                return;
            default:
                return;
        }
    }
}
