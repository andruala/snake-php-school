package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.p006g.C0104d;

class ba implements OnClickListener {
    final /* synthetic */ ay f444a;

    ba(ay ayVar) {
        this.f444a = ayVar;
    }

    public void onClick(View view) {
        C0104d.m830a("btn setonclick....");
        if (this.f444a.f440m) {
            if (this.f444a.f439l) {
                this.f444a.f436i.m914a((int) R.string.dlg_msg_upgrade_new);
            } else {
                this.f444a.f436i.m914a((int) R.string.dlg_msg_upgrade_old);
            }
            this.f444a.f436i.show();
            return;
        }
        this.f444a.m249d(R.string.dlg_title_upgrade, R.string.version_not_confirm);
    }
}
