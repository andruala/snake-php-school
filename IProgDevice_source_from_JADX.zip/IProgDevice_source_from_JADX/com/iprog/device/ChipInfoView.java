package com.iprog.device;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import com.iprog.p001b.C0011b;
import com.iprog.p001b.C0012c;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0025a;
import com.iprog.p003d.C0030f;
import com.iprog.p003d.C0032h;
import com.iprog.p003d.C0033i;
import com.iprog.p003d.C0035k;
import com.iprog.p003d.C0041q;
import com.iprog.p004f.C0099y;
import com.iprog.p005e.C0075a;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0107g;
import com.iprog.p006g.C0108h;
import com.iprog.view.C0116j;
import com.iprog.view.CheckBoxEx;
import com.iprog.view.ay;
import com.iprog.view.bs;
import java.util.ArrayList;
import java.util.Collections;

public class ChipInfoView extends cg {
    private C0116j f242B = null;
    private C0116j f243C = null;
    private C0116j f244D = null;
    private C0116j f245E = null;
    private C0116j f246F = null;
    private CheckBoxEx f247G = null;
    private CheckBoxEx f248H = null;
    private CheckBoxEx f249I = null;
    private TextView f250J = null;
    private TextView f251K = null;
    private TextView f252L = null;
    private TextView f253M = null;
    private TextView f254N = null;
    private TextView f255O = null;
    private TextView f256P = null;
    private TextView f257Q = null;
    private TextView f258R = null;
    private TextView f259S = null;
    private TextView f260T = null;
    private TextView f261U = null;
    private boolean f262V = false;
    private Object f263W = new Object();
    private boolean f264Z = false;
    C0035k f265a = new C0035k();
    private boolean aa = false;
    private TextView ab = null;
    C0025a f266b = null;
    C0013d f267c = C0013d.m42d();
    ImageView f268d = null;
    ArrayList f269e = new ArrayList();
    ImageButton f270f = null;
    ImageButton f271g = null;
    bs f272h = null;
    ay f273i = null;
    C0011b f274j;
    boolean f275k = false;
    int f276l = 0;
    aa f277m = null;
    boolean f278n = false;
    boolean f279o = false;
    C0030f f280p = null;
    boolean f281q = false;
    C0107g f282r = C0107g.m839a();
    C0032h f283s = null;
    int f284t = 0;
    boolean f285u = false;
    C0033i f286v;

    public ChipInfoView(Context context) {
        super(context);
        m312b();
    }

    public ChipInfoView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m312b();
    }

    private void m261A() {
        m300x();
        if (getWorkType() == 1 || getWorkType() == 2) {
            m302z();
        } else {
            this.f250J.setText("0");
        }
        C0104d.m831a("_cur_chip_data._rp_series_typ:", this.f266b.f143q);
        if (this.f266b.f143q == 19 || this.f266b.f143q == 20) {
            this.f254N.setText(m248d(R.string.chipinfo_reset_count));
        } else {
            this.f254N.setText(m248d(R.string.str_chipinfo_lockcode));
        }
        m299w();
        m298v();
        m262B();
    }

    private void m262B() {
        try {
            this.f251K.setText(C0013d.m41c(this.f266b.f139m, this.f266b.f140n));
            this.f252L.setText(" ");
            this.f253M.setText(" ");
            this.f255O.setText(" ");
            this.f256P.setText(" ");
            this.f257Q.setText(" ");
            this.f259S.setText(" ");
        } catch (Exception e) {
            C0104d.m829a(e, "clearViewData");
        }
    }

    private void m263a(int i, int i2, int i3) {
        if (this.f284t != i) {
            this.f284t = i;
            if (C0013d.m34B(i)) {
                m232a(m248d(R.string.dlg_title_notice), m248d(R.string.dlg_notic_a400));
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m267b(boolean r6) {
        /*
        r5 = this;
        r4 = 1;
        r3 = 0;
        r0 = r5.m260i();
        if (r0 == 0) goto L_0x0009;
    L_0x0008:
        return;
    L_0x0009:
        r0 = r5.f278n;
        if (r0 == 0) goto L_0x001a;
    L_0x000d:
        r0 = r5.f267c;
        r1 = 2131230915; // 0x7f0800c3 float:1.8077896E38 double:1.0529679785E-314;
        r1 = r5.m248d(r1);
        r0.m61a(r3, r1, r3);
        goto L_0x0008;
    L_0x001a:
        r0 = r5.f266b;
        r0 = r0.f127a;
        r0 = com.iprog.p006g.C0108h.m844a(r0);
        r0 = com.iprog.p001b.C0013d.m35C(r0);
        if (r0 == 0) goto L_0x0035;
    L_0x0028:
        r0 = r5.f267c;
        r1 = 2131230968; // 0x7f0800f8 float:1.8078004E38 double:1.0529680046E-314;
        r1 = r5.m248d(r1);
        r0.m61a(r3, r1, r3);
        goto L_0x0008;
    L_0x0035:
        r0 = r5.f266b;
        r0 = r0.m159d();
        if (r0 == 0) goto L_0x0060;
    L_0x003d:
        r0 = r5.f267c;
        r1 = r5.f243C;
        r1 = r1.m973b();
        r0 = r0.m54a(r1);
        r1 = r5.f267c;
        r2 = "-";
        r1 = r1.m54a(r2);
        if (r0 != r1) goto L_0x0060;
    L_0x0053:
        r0 = r5.f267c;
        r1 = 2131230969; // 0x7f0800f9 float:1.8078006E38 double:1.052968005E-314;
        r1 = r5.m248d(r1);
        r0.m61a(r3, r1, r3);
        goto L_0x0008;
    L_0x0060:
        r0 = r5.f266b;
        r0 = r0.m159d();
        if (r0 == 0) goto L_0x008c;
    L_0x0068:
        r0 = r5.f267c;
        r1 = r5.f244D;
        r1 = r1.m973b();
        r0 = r0.m76b(r1);
        r1 = r5.f267c;
        r2 = "-";
        r1 = r1.m76b(r2);
        if (r0 != r1) goto L_0x008c;
    L_0x007e:
        r0 = r5.f267c;
        r1 = 2131230970; // 0x7f0800fa float:1.8078008E38 double:1.0529680056E-314;
        r1 = r5.m248d(r1);
        r0.m61a(r3, r1, r3);
        goto L_0x0008;
    L_0x008c:
        r0 = r5.f266b;
        r0 = r0.m159d();
        if (r0 == 0) goto L_0x00ae;
    L_0x0094:
        r0 = r5.f245E;
        r0 = r0.m977c();
        r0 = com.iprog.p006g.C0108h.m844a(r0);
        if (r0 != 0) goto L_0x00ae;
    L_0x00a0:
        r0 = r5.f267c;
        r1 = 2131230971; // 0x7f0800fb float:1.807801E38 double:1.052968006E-314;
        r1 = r5.m248d(r1);
        r0.m61a(r3, r1, r3);
        goto L_0x0008;
    L_0x00ae:
        r1 = r5.f263W;
        monitor-enter(r1);
        r0 = r5.f262V;	 Catch:{ all -> 0x00c1 }
        if (r0 != 0) goto L_0x00b9;
    L_0x00b5:
        r0 = r5.f264Z;	 Catch:{ all -> 0x00c1 }
        if (r0 == 0) goto L_0x00c4;
    L_0x00b9:
        r0 = "시작이 이미 실행중입니다.";
        com.iprog.p006g.C0104d.m830a(r0);	 Catch:{ all -> 0x00c1 }
        monitor-exit(r1);	 Catch:{ all -> 0x00c1 }
        goto L_0x0008;
    L_0x00c1:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x00c1 }
        throw r0;
    L_0x00c4:
        r0 = 1;
        r5.f262V = r0;	 Catch:{ all -> 0x00c1 }
        r0 = 1;
        r5.f264Z = r0;	 Catch:{ all -> 0x00c1 }
        monitor-exit(r1);	 Catch:{ all -> 0x00c1 }
        r5.f275k = r6;
        r0 = r5.getTitleName();
        r1 = r5.getProgressMessage();
        r5.mo4a(r3, r0, r1, r4);
        r5.m290n();
        r5.m262B();
        r0 = r5.m284k();
        r1 = r5.getWorkType();
        r2 = 6;
        if (r1 != r2) goto L_0x00f5;
    L_0x00e9:
        r5.aa = r4;
    L_0x00eb:
        r1 = "";
        r5.m309a(r1, r3);
        r5.m242c(r0);
        goto L_0x0008;
    L_0x00f5:
        r5.aa = r3;
        r5.m283j();
        r5.m281i(r4);
        goto L_0x00eb;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.iprog.device.ChipInfoView.b(boolean):void");
    }

    private void m270c(String str, String str2) {
        if (this.f266b.m159d() && this.f266b.m160e() && (str.equals("-") || str2.equals("-"))) {
            this.f245E.m970a(new String[]{"-"}, new String[]{String.valueOf(0)});
            this.f245E.m974b(0);
            return;
        }
        String c = this.f245E.m977c();
        ArrayList a = this.f266b.m152a(str, str2);
        this.f245E.m965a(C0013d.m39b(a), a);
        if (!c.equals(String.valueOf(0))) {
            int d = this.f245E.m979d(c);
            if (d >= 0) {
                this.f245E.m974b(d);
                return;
            }
        }
        this.f245E.m974b(0);
    }

    private void m272d(C0099y c0099y) {
        C0104d.m830a("yield:" + c0099y.m809x());
        if (c0099y.f812c == 163000013 && c0099y.f815f == 30 && c0099y.m809x() == 20000) {
            m232a(m248d(R.string.chip_info), "1.MP-C3000 ASIA/EUR K 20K\n2.MP-C3500 ASIA/EUR K 23K\n" + String.format(m248d(R.string.search_equal_model), new Object[]{"MP-C3000"}));
            return;
        }
        m263a(c0099y.f812c, c0099y.f815f, c0099y.m809x());
    }

    private boolean m274e(C0099y c0099y) {
        int i;
        if (c0099y.f807W != 1) {
            if (c0099y.f807W != 2) {
                if (c0099y.f807W == 4) {
                    this.f285u = true;
                    this.f273i.m928a(c0099y);
                    i = 0;
                } else if (c0099y.f807W == 3) {
                    C0104d.m830a(c0099y.m764B());
                    int A = c0099y.m763A();
                    this.f278n = false;
                    if (this.f273i.m933b() || !this.f285u) {
                        i = m303a(c0099y);
                        this.f273i.m926a();
                        this.f285u = false;
                    } else {
                        this.f273i.m928a(c0099y);
                        if (this.f273i.m934c() == 1) {
                            i = m303a(this.f273i.m931b(0));
                            this.f273i.m926a();
                            this.f285u = false;
                        } else {
                            this.f273i.show();
                            i = 0;
                        }
                    }
                    if (i == 0) {
                        if (A == 12001 || A == 12002 || A == 12003 || A == 12004) {
                            m309a(m253f(A), true);
                        } else {
                            C0104d.m830a("remain:" + c0099y.f817h);
                            if (this.f266b.f143q != 21 || c0099y.f817h + 1 >= 100 || c0099y.f817h <= 0) {
                                m309a(m256g(23004), false);
                            } else {
                                Object[] objArr = new Object[2];
                                objArr[0] = m256g(23004);
                                objArr[1] = String.format(m248d(R.string.warn_ms_remain), new Object[]{C0099y.m759k(c0099y.f817h)});
                                m309a(String.format("%s\n%s", objArr), false);
                            }
                        }
                        if (!this.f285u) {
                            m272d(c0099y);
                        }
                    } else {
                        m309a(m256g(i), false);
                    }
                }
                if (i == 0) {
                }
            } else if (c0099y.f818i) {
                C0104d.m830a(c0099y.m764B());
                m303a(c0099y);
                i = 0;
                return i == 0;
            }
        }
        i = 0;
        if (i == 0) {
        }
    }

    private boolean m276f(C0099y c0099y) {
        int a;
        C0104d.m830a(c0099y.m764B());
        if (c0099y.f807W != 1) {
            if (c0099y.f807W == 2) {
                if (c0099y.f818i) {
                    a = m303a(c0099y);
                    C0104d.m830a("receiveProcessData:" + a);
                    return true;
                }
            } else if (c0099y.f807W == 3) {
                a = (c0099y.f818i || c0099y.f812c != 0) ? m303a(c0099y) : 1;
                if (this.f281q) {
                    m309a(String.format("%s[%s]", new Object[]{m256g(23007), m256g(23006)}), false);
                } else if (m259h(c0099y.m763A())) {
                    m309a(m256g(c0099y.m763A()), false);
                } else if (!c0099y.f818i || c0099y.f810Z <= 0) {
                    m309a(m256g(23007), false);
                } else {
                    m309a(m256g(23007), false);
                    m309a(String.format(m253f(23010), new Object[]{Integer.valueOf(c0099y.f810Z)}), true);
                }
                setCredit(c0099y.f786B);
                this.f281q = false;
                mo9c();
                C0104d.m830a("receiveProcessData:" + a);
                return true;
            }
        }
        a = 1;
        C0104d.m830a("receiveProcessData:" + a);
        return true;
    }

    private boolean m278g(com.iprog.p004f.C0099y r12) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.ssa.SSATransform.placePhi(SSATransform.java:82)
	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:50)
	at jadx.core.dex.visitors.ssa.SSATransform.visit(SSATransform.java:42)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r11 = this;
        r3 = 3;
        r2 = 2;
        r9 = 1;
        r10 = 0;
        r0 = r12.m808w();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r1 = 81;
        if (r0 != r1) goto L_0x007d;
    L_0x000c:
        r0 = r12.f807W;	 Catch:{ Exception -> 0x0069 }
        if (r0 == r9) goto L_0x0014;	 Catch:{ Exception -> 0x0069 }
    L_0x0010:
        r0 = r12.f807W;	 Catch:{ Exception -> 0x0069 }
        if (r0 != r2) goto L_0x0044;	 Catch:{ Exception -> 0x0069 }
    L_0x0014:
        r0 = r12.f807W;	 Catch:{ Exception -> 0x0069 }
        if (r0 != r9) goto L_0x0033;	 Catch:{ Exception -> 0x0069 }
    L_0x0018:
        r0 = r11.f286v;	 Catch:{ Exception -> 0x0069 }
        if (r0 == 0) goto L_0x0021;	 Catch:{ Exception -> 0x0069 }
    L_0x001c:
        r0 = r11.f286v;	 Catch:{ Exception -> 0x0069 }
        r0.m183a();	 Catch:{ Exception -> 0x0069 }
    L_0x0021:
        r0 = new com.iprog.d.i;	 Catch:{ Exception -> 0x0069 }
        r0.<init>();	 Catch:{ Exception -> 0x0069 }
        r11.f286v = r0;	 Catch:{ Exception -> 0x0069 }
        r0 = r11.f286v;	 Catch:{ Exception -> 0x0069 }
        r1 = r12.f813d;	 Catch:{ Exception -> 0x0069 }
        r1 = java.lang.String.valueOf(r1);	 Catch:{ Exception -> 0x0069 }
        r0.mo2b(r1);	 Catch:{ Exception -> 0x0069 }
    L_0x0033:
        r0 = r12.ad;	 Catch:{ Exception -> 0x0069 }
        if (r0 <= 0) goto L_0x0040;	 Catch:{ Exception -> 0x0069 }
    L_0x0037:
        r0 = r11.f286v;	 Catch:{ Exception -> 0x0069 }
        r1 = r12.ac;	 Catch:{ Exception -> 0x0069 }
        r2 = r12.ad;	 Catch:{ Exception -> 0x0069 }
        r0.mo1a(r1, r2);	 Catch:{ Exception -> 0x0069 }
    L_0x0040:
        r11.aa = r10;
        r0 = r9;
    L_0x0043:
        return r0;
    L_0x0044:
        r0 = r12.f807W;	 Catch:{ Exception -> 0x0069 }
        if (r0 != r3) goto L_0x0040;	 Catch:{ Exception -> 0x0069 }
    L_0x0048:
        r0 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0069 }
        r1 = "chip data create:";	 Catch:{ Exception -> 0x0069 }
        r0.<init>(r1);	 Catch:{ Exception -> 0x0069 }
        r1 = r11.f286v;	 Catch:{ Exception -> 0x0069 }
        r1 = r1.m187c();	 Catch:{ Exception -> 0x0069 }
        r0 = r0.append(r1);	 Catch:{ Exception -> 0x0069 }
        r0 = r0.toString();	 Catch:{ Exception -> 0x0069 }
        com.iprog.p006g.C0104d.m830a(r0);	 Catch:{ Exception -> 0x0069 }
        r0 = r11.f286v;	 Catch:{ Exception -> 0x0069 }
        r0.m183a();	 Catch:{ Exception -> 0x0069 }
        r0 = 0;	 Catch:{ Exception -> 0x0069 }
        r11.f286v = r0;	 Catch:{ Exception -> 0x0069 }
        goto L_0x0040;
    L_0x0069:
        r0 = move-exception;
        r1 = "readChipDataHid";	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        com.iprog.p006g.C0104d.m829a(r0, r1);	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        goto L_0x0040;
    L_0x0070:
        r0 = move-exception;
        r1 = "readChipData";	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        com.iprog.p006g.C0104d.m829a(r0, r1);	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r11.mo9c();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r11.aa = r10;
        r0 = r10;
        goto L_0x0043;
    L_0x007d:
        r0 = r12.f807W;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        if (r0 == r9) goto L_0x0085;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
    L_0x0081:
        r0 = r12.f807W;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        if (r0 != r2) goto L_0x00b4;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
    L_0x0085:
        r0 = r11.aa;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        if (r0 == 0) goto L_0x00a2;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
    L_0x0089:
        r0 = r11.f283s;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        if (r0 == 0) goto L_0x0092;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
    L_0x008d:
        r0 = r11.f283s;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r0.m183a();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
    L_0x0092:
        r0 = new com.iprog.d.h;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r0.<init>();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r11.f283s = r0;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r0 = r11.f283s;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r1 = r11.f266b;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r1 = r1.f127a;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r0.mo2b(r1);	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
    L_0x00a2:
        r0 = r12.ad;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        if (r0 <= 0) goto L_0x0040;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
    L_0x00a6:
        r0 = r11.f283s;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r1 = r12.ac;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r2 = r12.ad;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r0.mo1a(r1, r2);	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        goto L_0x0040;
    L_0x00b0:
        r0 = move-exception;
        r11.aa = r10;
        throw r0;
    L_0x00b4:
        r0 = r12.f807W;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        if (r0 != r3) goto L_0x0040;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
    L_0x00b8:
        r0 = r12.m808w();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r1 = 80;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        if (r0 != r1) goto L_0x0040;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
    L_0x00c0:
        r0 = r12.f818i;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        if (r0 == 0) goto L_0x00c7;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
    L_0x00c4:
        r11.m303a(r12);	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
    L_0x00c7:
        r0 = r11.getDatabase();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r1 = r12.f824o;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r2 = r11.f266b;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r2 = r2.f127a;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r3 = r11.f266b;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r3 = r3.f132f;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r4 = r11.f243C;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r4 = r4.m973b();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r5 = r11.f244D;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r5 = r5.m973b();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r6 = r11.f245E;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r6 = r6.m977c();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r6 = com.iprog.p006g.C0108h.m844a(r6);	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r7 = r11.f283s;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r7 = r7.m187c();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r8 = r11.f283s;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r8 = r8.m185b();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r0.m636a(r1, r2, r3, r4, r5, r6, r7, r8);	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r0 = r11.f283s;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r0.m183a();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r0 = 0;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r11.f283s = r0;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r0 = 23007; // 0x59df float:3.224E-41 double:1.1367E-319;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r0 = r11.m256g(r0);	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r1 = 0;	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r11.m309a(r0, r1);	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        r11.mo9c();	 Catch:{ Exception -> 0x0070, all -> 0x00b0 }
        goto L_0x0040;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.iprog.device.ChipInfoView.g(com.iprog.f.y):boolean");
    }

    private String getProgressMessage() {
        String str = "";
        switch (getWorkType()) {
            case 1:
            case 2:
            case 7:
                return m248d(R.string.str_pbdlg_reset);
            case 3:
                return m248d(R.string.str_pbdlg_change);
            case 4:
                return m248d(R.string.str_pbdlg_upgrade);
            case 5:
                return m248d(R.string.str_pbdlg_check);
            case 6:
                return m248d(R.string.str_pbdlg_read);
            default:
                return str;
        }
    }

    private void m281i(int i) {
        C0075a database = getDatabase();
        int workType = getWorkType();
        if (workType == 7) {
            workType = 1;
        }
        database.m634a(i, workType, this.f266b.f127a, this.f266b.f132f, "", "", 0, 0);
    }

    private void m283j() {
        C0075a database = getDatabase();
        int workType = getWorkType();
        if (workType == 7) {
            workType = 1;
        }
        database.m635a(0, workType, this.f266b.f127a, this.f266b.f132f, this.f243C.m973b(), this.f244D.m973b(), C0108h.m844a(this.f245E.m977c()), 0, 1);
    }

    private C0099y m284k() {
        C0099y c0099y = new C0099y();
        C0104d.m830a("JOB Type:" + this.f246F.m977c());
        c0099y.m785e(this.f266b.f143q);
        c0099y.m781d(this.f267c.m75b(getWorkType()));
        c0099y.m777c(this.f267c.m53a(getWorkType()));
        c0099y.m766a(this.f266b.f127a);
        c0099y.m788f(this.f267c.m54a(this.f243C.m973b()));
        c0099y.m792h(this.f267c.m76b(this.f244D.m973b()));
        c0099y.m790g(C0108h.m844a(this.f245E.m977c()));
        c0099y.m767a(this.f247G.isChecked());
        if (this.f266b.f143q == 21) {
            c0099y.m768a(true, this.f249I.isChecked());
        } else {
            c0099y.m768a(this.f266b.f146t, this.f249I.isChecked());
        }
        c0099y.m772b(false);
        c0099y.m767a(this.f275k);
        if (this.f266b.f123J) {
            c0099y.m778c(false);
            c0099y.m782d(this.f248H.isChecked());
        } else {
            c0099y.m778c(this.f248H.isChecked());
            c0099y.m782d(false);
        }
        this.f276l = getWorkType();
        C0104d.m830a(c0099y.m764B());
        return c0099y;
    }

    private boolean m287l() {
        if (!this.f247G.isChecked()) {
            return false;
        }
        C0104d.m833a("isAutoJob:", true);
        return true;
    }

    private synchronized void m288m() {
        if (m287l()) {
            setAutoJobProgress(true);
            if (this.f277m == null || !this.f277m.m396b()) {
                this.f277m = new aa();
                C0099y k = m284k();
                k.m781d(33);
                k.ae = false;
                if (this.f276l == 4) {
                    k.ae = true;
                }
                this.f277m.m395a(k);
                this.f277m.start();
            } else {
                C0104d.m830a("AutoJobThread already running..");
            }
        }
    }

    private synchronized void m290n() {
        setAutoJobProgress(false);
        if (this.f277m != null) {
            this.f277m.m394a();
        }
        this.f277m = null;
    }

    private void m291o() {
        m267b(false);
    }

    private void m292p() {
        if (!m260i()) {
            synchronized (this.f263W) {
                if (this.f262V || this.f264Z) {
                    C0104d.m830a("검색이 이미 실행중입니다.");
                    return;
                }
                this.f262V = true;
                this.f264Z = true;
                this.f276l = getWorkType();
                mo4a(0, m248d(R.string.search_chip_title), m248d(R.string.str_pbdlg_search), true);
                m290n();
                m262B();
                C0099y c0099y = new C0099y();
                c0099y.m785e(this.f267c.m132y(this.f266b.f143q));
                c0099y.m781d(32);
                c0099y.m777c(this.f267c.m53a(getWorkType()));
                c0099y.m766a(this.f266b.f127a);
                c0099y.m778c(this.f248H.isChecked());
                m309a("", false);
                m242c(c0099y);
            }
        }
    }

    private void m293q() {
        this.f269e = this.f267c.m57a(this.f266b, this.f266b.m158c());
        Collections.sort(this.f269e, C0013d.f46Z);
        this.f242B.m964a(this.f267c.m59a(this.f269e), this.f266b.f132f, this.f269e);
        m261A();
        m294r();
    }

    private void m294r() {
        ArrayList b = this.f266b.m157b();
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        String str = "";
        for (int i = 0; i < b.size(); i++) {
            arrayList2.add(String.valueOf(this.f267c.m54a((String) b.get(i))));
            if (this.f266b.f136j == 4 || this.f266b.f136j == 2) {
                String str2 = (String) this.f266b.m152a((String) b.get(i), (String) this.f266b.m151a((String) b.get(i)).get(0)).get(0);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(String.format("%s\n[%s/%s]", new Object[]{b.get(i), str, C0013d.m44g(str2)}));
                if (!this.f266b.m156b((String) b.get(i)).isEmpty()) {
                    stringBuilder.append(String.format(" [%s]", new Object[]{this.f266b.m156b((String) b.get(i))}));
                }
                arrayList.add(stringBuilder.toString());
            }
        }
        if (this.f266b.f136j == 4 || this.f266b.f136j == 2) {
            this.f243C.m966a(b, arrayList2, arrayList);
        } else {
            this.f243C.m965a(b, arrayList2);
        }
        this.f243C.m974b(0);
        setColorList((String) b.get(0));
    }

    private void m295s() {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (this.f280p.m176c()) {
            arrayList.add(m248d(R.string.str_job_reset));
            arrayList2.add(String.valueOf(1));
        }
        if (this.f280p.m178e()) {
            arrayList.add(m248d(R.string.str_job_change));
            arrayList2.add(String.valueOf(3));
        }
        if (this.f280p.m177d()) {
            arrayList.add(m248d(R.string.str_job_upgrade));
            arrayList2.add(String.valueOf(4));
        }
        if (this.f280p.m171a()) {
            arrayList.add(m248d(R.string.str_job_read));
            arrayList2.add(String.valueOf(6));
        }
        this.f246F.m965a(arrayList, arrayList2);
        this.f246F.m974b(0);
        if (this.f276l != 0) {
            this.f246F.m976c(String.valueOf(this.f276l));
        }
        super.setTitle(this.f246F.m973b());
    }

    private void setAutoJobProgress(boolean z) {
        if (!z) {
            this.f247G.m878b();
        } else if (m287l()) {
            this.f247G.m876a();
        }
    }

    private void setColorList(String str) {
        if (this.f266b.m159d() && str.equals("-")) {
            this.f244D.m962a("-");
            this.f244D.m974b(0);
            m270c(str, "-");
            return;
        }
        int e;
        String b = this.f244D.m973b();
        ArrayList a = this.f266b.m151a(str);
        this.f244D.m963a(a);
        if (!b.equals("-")) {
            e = this.f244D.m982e(b);
            if (e >= 0) {
                this.f244D.m974b(e);
                m270c(str, (String) a.get(e));
            }
        }
        this.f244D.m974b(0);
        e = 0;
        m270c(str, (String) a.get(e));
    }

    private void m296t() {
        this.f242B.m962a(new StringBuilder(String.valueOf(this.f266b.f142p)).append(" Series").toString());
        this.f242B.m974b(0);
        this.f271g.setVisibility(0);
        this.f243C.m959a();
        this.f244D.m959a();
        this.f245E.m959a();
        this.f246F.m959a();
        this.f243C.m967a(false);
        this.f244D.m967a(false);
        this.f245E.m967a(false);
        this.f246F.m967a(false);
        this.f270f.setVisibility(0);
        this.f271g.setVisibility(0);
        this.ab.setText(m256g(23002));
    }

    private void m297u() {
        this.f243C.m967a(true);
        this.f244D.m967a(true);
        this.f245E.m967a(true);
        this.f246F.m967a(true);
        this.f270f.setVisibility(0);
        this.f271g.setVisibility(0);
        this.ab.setText(" ");
    }

    private void m298v() {
        if (this.f267c.m71a(this.f266b, getWorkType())) {
            this.f247G.setEnabled(true);
        } else {
            this.f247G.setEnabled(false);
        }
    }

    private void m299w() {
        if (this.f266b.f140n > 0 || this.f266b.f123J) {
            this.f248H.setEnabled(true);
        } else {
            this.f248H.setEnabled(false);
        }
        if (this.f266b.f123J) {
            this.f248H.setChecked(false);
        } else if (this.f266b.f139m == 0) {
            this.f248H.setChecked(true);
        } else {
            this.f248H.setChecked(false);
        }
        if (this.f266b.f123J) {
            this.f248H.setText((int) R.string.str_chipinfo_rsl);
            this.f248H.setICon(0);
            this.f261U.setText(R.string.str_chipinfo_rsl);
            return;
        }
        this.f248H.setICon(R.drawable.img_checkbox_upgrade);
        this.f248H.setText((int) R.string.str_chipinfo_ext_chip);
        this.f261U.setText(R.string.str_chipinfo_ver);
    }

    private void m300x() {
        if (this.f266b.f143q == 10) {
            this.f249I.setText((int) R.string.chipinfo_nonhp_cb);
            this.f260T.setText(R.string.chipinfo_hp_title);
        } else if (C0013d.m34B(C0108h.m844a(this.f266b.f127a))) {
            this.f260T.setText(R.string.chipinfo_yield);
            this.f249I.setText((int) R.string.str_chipinfo_autoregion);
        } else if (this.f266b.f143q == 21) {
            this.f249I.setText((int) R.string.chipinfo_mx410_cb);
            this.f260T.setText(R.string.str_chipinfo_autoregion);
        } else {
            this.f249I.setText((int) R.string.str_chipinfo_autoregion);
            this.f260T.setText(R.string.str_chipinfo_autoregion);
        }
        if ((this.f266b.f143q == 21 || this.f266b.f146t) && getWorkType() != 6) {
            this.f249I.setEnabled(true);
        } else {
            this.f249I.setEnabled(false);
        }
    }

    private void m301y() {
        this.f243C.m967a(false);
        this.f244D.m967a(false);
        this.f245E.m967a(false);
        this.f247G.setEnabled(false);
        this.f248H.setEnabled(false);
        this.f249I.setEnabled(false);
        this.f271g.setVisibility(0);
        this.f270f.setVisibility(0);
    }

    private void m302z() {
        if (this.f267c.f58G == 0) {
            this.f250J.setText(Integer.toString(this.f266b.f138l));
        } else {
            this.f250J.setText("");
        }
    }

    public int m303a(C0099y c0099y) {
        this.f280p = this.f267c.m109l(c0099y.f812c);
        if (this.f280p == null || !this.f280p.m172a(this.f267c.f58G) || this.f280p.m169a(c0099y.f824o) == null) {
            return 23102;
        }
        this.f266b = this.f280p.m169a(c0099y.f824o);
        m313b(this.f266b, true);
        m295s();
        m297u();
        m293q();
        String f = this.f267c.m94f(c0099y.f815f);
        String g = this.f267c.m96g(c0099y.f816g);
        String num = Integer.toString(c0099y.m809x());
        if ((this.f266b.m159d() || this.f266b.m160e() || this.f266b.f127a.equals(String.valueOf(999999511))) && f.equals("-")) {
            this.f243C.m957a(c0099y.f815f, f);
        }
        if (this.f243C.m972b(f) < 0) {
            return 23103;
        }
        if ((this.f266b.m159d() || this.f266b.m160e() || this.f266b.f127a.equals(String.valueOf(999999511))) && f.equals("-")) {
            this.f244D.m962a(g);
            this.f244D.m974b(0);
        } else {
            setColorList(f);
            if (g.equals("-")) {
                this.f244D.m957a(c0099y.f816g, g);
            }
        }
        if (this.f244D.m972b(g) < 0) {
            return 23104;
        }
        m270c(f, g);
        this.f245E.m958a(num, C0013d.m44g(num));
        setChipAttributes(c0099y);
        C0104d.m830a("changeModel end");
        return 0;
    }

    public void mo3a() {
        C0104d.m832a("onStop", "chipinfoview");
        this.f276l = 0;
        this.f284t = 0;
        m290n();
        this.f242B.m983e();
        this.f242B.m983e();
        this.f243C.m983e();
        this.f244D.m983e();
        this.f245E.m983e();
        this.f246F.m983e();
        this.f273i.m926a();
    }

    protected void mo4a(int i, String str, String str2, boolean z) {
        mo9c();
        try {
            this.f272h = new bs(getContext());
            this.f272h.m948a(i);
            this.f272h.m950a(str);
            this.f272h.m952b(str2);
            this.f272h.m949a(new C0066r(this));
            this.f272h.show();
        } catch (Exception e) {
            C0104d.m829a(e, "showProgress");
        }
    }

    public void m306a(int i, boolean z) {
        if (z) {
            m309a(m253f(i), z);
        } else {
            m309a(m256g(i), z);
        }
    }

    public void mo5a(C0041q c0041q) {
        try {
            this.f242B.m975b(true);
            this.f265a = (C0035k) c0041q.m222c("chip_data");
            C0099y c0099y = (C0099y) c0041q.m222c("chip_search");
            if (c0099y != null) {
                int A = c0099y.m763A();
                if (A == 12001 || A == 12002 || A == 12003 || A == 12004) {
                    m274e(c0099y);
                    mo9c();
                    setSessionTime(false);
                    this.f282r.m840a(0);
                    this.f264Z = false;
                    this.aa = false;
                } else {
                    mo8b(c0099y);
                }
                this.f278n = false;
                return;
            }
            this.f280p = this.f265a.f206a;
            this.f266b = this.f265a.f206a.m180g();
            m313b(this.f266b, false);
            m295s();
            m261A();
            if (this.f265a.f207b == 2) {
                this.f278n = true;
                m296t();
            } else {
                this.f278n = false;
                m297u();
                m293q();
            }
            if (getWorkType() == 6) {
                m301y();
            }
            m281i(this.f265a.f207b);
            m263a(C0108h.m844a(this.f266b.f127a), 0, 0);
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }

    public void mo6a(bs bsVar) {
        if (bsVar != null) {
            try {
                if (bsVar.isShowing()) {
                    bsVar.dismiss();
                }
            } catch (Exception e) {
            }
        }
    }

    public void m309a(String str, boolean z) {
        this.ab.setText(str);
    }

    public boolean mo7a(int i, int i2) {
        C0104d.m831a("chipinfoview onkey event", i2);
        switch (i2) {
            case 1:
                if (this.f270f.getVisibility() == 0) {
                    m291o();
                    break;
                }
                break;
            case 2:
                if (this.f271g.getVisibility() == 0) {
                    m292p();
                    break;
                }
                break;
            case 4:
            case 8:
                if (this.f262V) {
                    return false;
                }
                break;
        }
        return super.mo7a(i, i2);
    }

    public boolean m311a(C0025a c0025a, boolean z) {
        try {
            this.f268d.setImageBitmap(c0025a.f121H);
        } catch (Exception e) {
            this.f268d.setImageBitmap(null);
        }
        return true;
    }

    public void m312b() {
        setView(R.layout.activity_chip_info);
        this.f268d = (ImageView) findViewById(R.id.img_chip);
        this.f242B = new C0116j(getContext(), (Button) findViewById(R.id.sp_model), R.layout.dlg_popup_list);
        this.f242B.m960a((int) R.string.str_cb_title_model);
        this.f243C = new C0116j(getContext(), (Button) findViewById(R.id.sp_nat), R.layout.dlg_popup_list);
        this.f243C.m960a((int) R.string.str_cb_title_nat);
        this.f244D = new C0116j(getContext(), (Button) findViewById(R.id.sp_color), R.layout.dlg_popup_list);
        this.f244D.m960a((int) R.string.str_cb_title_color);
        this.f245E = new C0116j(getContext(), (Button) findViewById(R.id.sp_yield), R.layout.dlg_popup_list);
        this.f245E.m960a((int) R.string.str_cb_title_yield);
        this.f246F = new C0116j(getContext(), (Button) findViewById(R.id.sp_job), R.layout.dlg_popup_list);
        this.f246F.m960a((int) R.string.str_cb_title_job);
        this.ab = (TextView) findViewById(R.id.tv_msg);
        this.f270f = (ImageButton) findViewById(R.id.btn_start);
        this.f271g = (ImageButton) findViewById(R.id.btn_search);
        this.f250J = (TextView) findViewById(R.id.tv_credit);
        this.f251K = (TextView) findViewById(R.id.tv_zig);
        this.f252L = (TextView) findViewById(R.id.tv_status);
        this.f253M = (TextView) findViewById(R.id.tv_chip_mark);
        this.f254N = (TextView) findViewById(R.id.tv_chip_mark_title);
        this.f255O = (TextView) findViewById(R.id.tv_remain);
        this.f256P = (TextView) findViewById(R.id.tv_oem);
        this.f257Q = (TextView) findViewById(R.id.tv_ident);
        this.f247G = (CheckBoxEx) findViewById(R.id.cb_auto_job);
        this.f248H = (CheckBoxEx) findViewById(R.id.cb_ext_chip);
        this.f249I = (CheckBoxEx) findViewById(R.id.cb_auto_region);
        this.f258R = (TextView) findViewById(R.id.tv_version);
        this.f261U = (TextView) findViewById(R.id.tv_version_title);
        this.f259S = (TextView) findViewById(R.id.tv_autoregion);
        this.f260T = (TextView) findViewById(R.id.tv_auto_region_title);
        this.f273i = new ay(getApplication());
        this.f273i.setTitle(R.string.str_cb_title_model);
        this.f273i.m927a((int) R.string.multi_model_msg);
        this.f270f.setOnClickListener(new C0063o(this));
        this.f271g.setOnClickListener(new C0067s(this));
        this.f242B.m961a(new C0068t(this));
        this.f243C.m961a(new C0069u(this));
        this.f244D.m961a(new C0070v(this));
        this.f245E.m961a(new C0071w(this));
        this.f247G.setOnClickListener(new C0072x(this));
        this.f249I.setOnClickListener(new C0073y(this));
        this.f248H.setOnClickListener(new C0074z(this));
        this.f246F.m961a(new C0064p(this));
        this.f273i.m929a(new C0065q(this));
        this.f274j = C0011b.m14a(getApplication());
    }

    public boolean m313b(C0025a c0025a, boolean z) {
        if (z) {
            try {
                this.f268d.setImageBitmap(c0025a.f121H);
            } catch (Exception e) {
                this.f268d.setImageBitmap(null);
            }
        } else {
            this.f268d.setImageBitmap(this.f280p.m181h());
        }
        return true;
    }

    public boolean mo8b(C0099y c0099y) {
        boolean e;
        C0104d.m830a(String.format("onPacketReceive:%02x,%d,%d", new Object[]{Integer.valueOf(c0099y.m808w()), Integer.valueOf(c0099y.f807W), Integer.valueOf(c0099y.m763A())}));
        this.f262V = false;
        int A = c0099y.m763A();
        if (!mo28a(A)) {
            if (((c0099y.m808w() != 33 ? 1 : 0) & (c0099y.m808w() != 81 ? 1 : 0)) != 0) {
                if (A == 11008) {
                    C0104d.m830a("msg:" + m253f(A));
                    m309a(String.format(m253f(A), new Object[]{C0099y.m759k(c0099y.f817h)}), true);
                } else {
                    m306a(A, true);
                }
                mo9c();
                setSessionTime(false);
                this.f282r.m840a(0);
                this.f264Z = false;
                if (A == 18004 || A == 18005) {
                    if (A == 18004) {
                        this.f274j.m25c();
                    } else {
                        this.f274j.m28f();
                    }
                    if (this.f274j.m29g() || this.f274j.m27e()) {
                        m251e(R.string.dlg_notice_device_lock, A);
                    } else {
                        m251e(R.string.dlg_notice_reset_fault, A);
                    }
                    this.aa = false;
                    return true;
                }
                if ((c0099y.m808w() == 48 || c0099y.m808w() == 49 || c0099y.m808w() == 50 || c0099y.m808w() == 51) && c0099y.f807W == 3) {
                    m288m();
                }
                this.aa = false;
                return true;
            }
        }
        C0012c.m33a(c0099y);
        switch (c0099y.m808w()) {
            case 32:
                e = m274e(c0099y);
                break;
            case 33:
                if (!c0099y.f829t) {
                    e = true;
                    break;
                }
                m267b(true);
                e = true;
                break;
            case 48:
            case 49:
            case 50:
            case 51:
                m276f(c0099y);
                e = true;
                break;
            case 80:
            case 81:
                m278g(c0099y);
                e = true;
                break;
            default:
                break;
        }
        if (c0099y.f807W != 3 || c0099y.m808w() == 81) {
            setSessionTime(true);
        } else {
            mo9c();
            setSessionTime(false);
            this.f264Z = false;
            if (!e) {
                this.f282r.m840a(0);
            } else if (this.f279o) {
                this.f267c.m61a(0, m248d(R.string.hp_lock_not_available), 0);
                this.f282r.m840a(2);
            } else if (m259h(A)) {
                this.f282r.m840a(3);
            } else {
                this.f282r.m840a(1);
            }
        }
        if ((c0099y.m808w() == 48 || c0099y.m808w() == 49 || c0099y.m808w() == 50) && c0099y.f807W == 3) {
            m288m();
        }
        return true;
    }

    public void mo9c() {
        mo6a(this.f272h);
    }

    public boolean getAutoJob() {
        return this.f275k;
    }

    public String getTitleName() {
        return this.f246F.m973b().trim().isEmpty() ? super.getTitleName() : this.f246F.m973b();
    }

    public int getWorkType() {
        return C0108h.m844a(this.f246F.m977c());
    }

    public void setChipAttributes(C0099y c0099y) {
        if (c0099y.f822m == 2) {
            this.f252L.setText(m248d(R.string.str_new_chip));
        } else if (c0099y.f822m == 1) {
            this.f252L.setText(m248d(R.string.str_used_chip));
        } else {
            this.f252L.setText(" ");
        }
        this.f253M.setTextColor(-16777216);
        this.f279o = false;
        if (this.f266b.f143q == 10 || this.f266b.f143q == 21 || this.f266b.f143q == 25 || this.f266b.f143q == 26) {
            switch (c0099y.f819j) {
                case 1:
                    this.f253M.setText("N");
                    break;
                case 2:
                    this.f253M.setText("Y");
                    break;
                case 3:
                    this.f253M.setText("Y");
                    this.f253M.setTextColor(-65536);
                    if (this.f266b.f143q == 10) {
                        this.f279o = true;
                        break;
                    }
                    break;
                default:
                    this.f253M.setText("");
                    break;
            }
            if (this.f266b.f127a.equals(String.valueOf(999999511)) && c0099y.f819j != 1) {
                this.f253M.setText("");
            }
        } else {
            this.f253M.setText(C0099y.m758j(c0099y.f819j));
        }
        if (this.f266b.f143q == 19 || this.f266b.f143q == 20) {
            this.f254N.setText(m248d(R.string.chipinfo_reset_count));
        } else {
            this.f254N.setText(m248d(R.string.str_chipinfo_lockcode));
        }
        if (c0099y.m808w() == 48 && this.f266b.f143q == 21) {
            this.f255O.setText(C0099y.m759k(c0099y.f817h));
        } else if (c0099y.m808w() == 48 || this.f266b.f143q != 21) {
            this.f255O.setText(C0099y.m759k(c0099y.f817h));
        } else {
            this.f255O.setText("");
        }
        this.f256P.setText(c0099y.f824o ? "Y" : "N");
        this.f257Q.setText(c0099y.f820k);
        if (!C0013d.m34B(C0108h.m844a(this.f266b.f127a))) {
            this.f259S.setGravity(17);
            if (!this.f266b.f146t) {
                this.f259S.setText(" ");
            } else if (this.f266b.f143q == 10) {
                this.f259S.setText(C0099y.m762n(c0099y.f827r));
            } else {
                this.f259S.setText(C0099y.m761m(c0099y.f827r));
            }
        } else if (c0099y.m810y() == c0099y.m809x() || c0099y.m810y() < 1) {
            this.f259S.setGravity(17);
            this.f259S.setText(C0013d.m46n(c0099y.m809x()));
        } else {
            this.f259S.setGravity(19);
            this.f259S.setText(String.format("  %s\n ▶%s", new Object[]{C0013d.m46n(c0099y.m810y()), C0013d.m46n(c0099y.m809x())}));
        }
        if (!(getWorkType() == 6 || this.f266b.f143q == 21)) {
            this.f249I.setChecked(C0099y.m756b(c0099y.f827r));
        }
        if (this.f266b.f123J) {
            this.f248H.setChecked(c0099y.f831v);
            this.f258R.setText(c0099y.f831v ? "Y" : "N");
            return;
        }
        this.f248H.setChecked(c0099y.f830u);
        this.f258R.setText(C0099y.m760l(c0099y.f823n));
    }

    public void setTextMessage(int i) {
        m306a(i, true);
    }
}
