package com.iprog.device;

class bd implements Runnable {
    final /* synthetic */ bc f447a;

    bd(bc bcVar) {
        this.f447a = bcVar;
    }

    public void run() {
        this.f447a.f446a.m462j();
    }
}
