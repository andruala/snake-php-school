package com.iprog.device;

import android.os.Handler;
import android.os.Message;
import com.iprog.p003d.C0037m;
import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;

class bu extends Handler {
    final /* synthetic */ IProgActivity f469a;

    bu(IProgActivity iProgActivity) {
        this.f469a = iProgActivity;
    }

    public void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                Object obj = message.obj;
                C0041q c0041q = (C0041q) this.f469a.f311Y.mo13d();
                if (c0041q != null) {
                    this.f469a.f310X.m82b(this.f469a.f310X.f76h, c0041q.m221b("view"), c0041q.m222c("arg"));
                    return;
                } else if (this.f469a.f312Z != 0) {
                    this.f469a.f310X.m82b(this.f469a.f310X.f76h, this.f469a.f312Z, new C0041q(1));
                    return;
                } else {
                    return;
                }
            case 2:
                try {
                    this.f469a.m379a(((C0041q) message.obj).m221b("credit"));
                    return;
                } catch (Exception e) {
                    C0104d.m829a(e, "_action_handler");
                    return;
                }
            case 3:
                C0104d.m830a("##Action HandlerMessage Init Call");
                this.f469a.m331b();
                return;
            case 4:
                new Thread(new bv(this)).start();
                return;
            case 5:
                this.f469a.m346e();
                return;
            case 6:
                this.f469a.m363j(230);
                return;
            case 16:
                try {
                    this.f469a.m385a(((C0041q) message.obj).m218a("title"));
                    return;
                } catch (Exception e2) {
                    C0104d.m829a(e2, "_action_handler");
                    return;
                }
            case 17:
                C0104d.m830a("Action Handler ACT_APP_UPGRADE");
                try {
                    C0037m c0037m = (C0037m) message.obj;
                    if (c0037m != null) {
                        this.f469a.m381a(c0037m);
                        return;
                    } else {
                        C0104d.m830a("############## ACT_APP_UPGRADE Data Error ########");
                        return;
                    }
                } catch (Exception e22) {
                    C0104d.m829a(e22, "_action_handler");
                    return;
                }
            case 18:
                C0104d.m830a("Action Handler ACT_BT_STATUS");
                if (((String) message.obj).equals("ON")) {
                    this.f469a.m326a(true);
                    return;
                } else {
                    this.f469a.m326a(false);
                    return;
                }
            case 19:
                try {
                    String str = (String) message.obj;
                    C0104d.m830a("ACT_BT_SET_NAME :" + str);
                    this.f469a.f328p.setName(str);
                    C0108h.m853a(100);
                    return;
                } catch (Exception e222) {
                    C0104d.m829a(e222, "BT Set Name");
                    return;
                }
            case 20:
                try {
                    this.f469a.f321i.m688d();
                    return;
                } catch (Exception e2222) {
                    C0104d.m829a(e2222, "BT ACT_BT_DISCONNECT");
                    return;
                }
            default:
                return;
        }
    }
}
