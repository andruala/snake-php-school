package com.iprog.device;

import java.util.TimerTask;

class cd extends TimerTask {
    final /* synthetic */ IProgActivity f481a;

    cd(IProgActivity iProgActivity) {
        this.f481a = iProgActivity;
    }

    public void run() {
        this.f481a.f310X.m69a(this.f481a.f301O, 2);
    }
}
