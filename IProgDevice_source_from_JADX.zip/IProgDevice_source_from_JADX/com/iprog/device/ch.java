package com.iprog.device;

import com.iprog.p004f.C0082d;
import com.iprog.p004f.C0099y;

class ch implements Runnable {
    final /* synthetic */ cg f488a;
    private final /* synthetic */ C0099y f489b;

    ch(cg cgVar, C0099y c0099y) {
        this.f488a = cgVar;
        this.f489b = c0099y;
    }

    public void run() {
        C0082d.m729c().m732a(this.f489b);
    }
}
