package com.iprog.device;

class bh implements Runnable {
    final /* synthetic */ ay f453a;
    private final /* synthetic */ boolean f454b;

    bh(ay ayVar, boolean z) {
        this.f453a = ayVar;
        this.f454b = z;
    }

    public void run() {
        if (this.f454b) {
            this.f453a.f437j.show();
        } else {
            this.f453a.f437j.hide();
        }
    }
}
