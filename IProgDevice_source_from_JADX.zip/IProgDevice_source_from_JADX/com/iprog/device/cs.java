package com.iprog.device;

import android.app.Activity;
import java.util.TimerTask;

class cs extends TimerTask {
    final /* synthetic */ cm f522a;

    cs(cm cmVar) {
        this.f522a = cmVar;
    }

    public void run() {
        ((Activity) this.f522a.getContext()).runOnUiThread(new ct(this));
    }
}
