package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;
import java.util.Calendar;

class av implements OnClickListener {
    final /* synthetic */ as f421a;

    av(as asVar) {
        this.f421a = asVar;
    }

    public void onClick(View view) {
        Calendar instance = Calendar.getInstance();
        this.f421a.f412e = instance.get(1);
        this.f421a.f413f = instance.get(2);
        this.f421a.f414g = instance.get(5);
        this.f421a.f415h = instance.get(11);
        this.f421a.f416i = instance.get(12);
        this.f421a.f410c.updateDate(this.f421a.f412e, this.f421a.f413f, this.f421a.f414g);
        this.f421a.f410c.show();
    }
}
