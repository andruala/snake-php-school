package com.iprog.device;

import com.iprog.p006g.C0104d;
import com.iprog.view.C0050m;

class dq implements C0050m {
    final /* synthetic */ C0051do f633a;

    dq(C0051do c0051do) {
        this.f633a = c0051do;
    }

    public void mo31a(int i, String str) {
        C0104d.m830a("view _cb_job onclick:" + str + "," + this.f633a.f630s.m977c());
        try {
            this.f633a.m597j(0);
        } catch (Exception e) {
        }
    }
}
