package com.iprog.device;

import android.view.View;
import android.widget.EditText;
import com.iprog.view.ax;

class ak implements ax {
    final /* synthetic */ aj f396a;

    ak(aj ajVar) {
        this.f396a = ajVar;
    }

    public void mo16a(String str, View view) {
        ((EditText) view).setText(str);
    }
}
