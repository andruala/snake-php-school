package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class dj implements OnClickListener {
    final /* synthetic */ df f598a;

    dj(df dfVar) {
        this.f598a = dfVar;
    }

    public void onClick(View view) {
        this.f598a.m576i(-10);
    }
}
