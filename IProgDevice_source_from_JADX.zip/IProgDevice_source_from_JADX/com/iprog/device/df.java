package com.iprog.device;

import android.content.Context;
import android.widget.Button;
import android.widget.ListView;
import com.iprog.p000a.C0007h;
import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;
import com.iprog.view.TabView;

public class df extends cg {
    C0007h f588a = null;
    final int f589b = 0;
    final int f590c = -10;
    private TabView f591d = null;
    private ListView f592e = null;
    private Button f593f = null;
    private Button f594g = null;

    public df(Context context) {
        super(context);
        m578b();
    }

    private void m576i(int i) {
        int lastVisiblePosition = this.f592e.getLastVisiblePosition();
        C0104d.m831a("list pos", lastVisiblePosition);
        this.f592e.setSelectionFromTop(Math.max(lastVisiblePosition + i, 0), 0);
    }

    public void mo5a(C0041q c0041q) {
        this.f591d.setTabIndex(0);
        C0104d.m830a("onStart SearchModelView:" + c0041q.m217a());
        if (c0041q.m217a() == 0) {
            m580j();
        }
    }

    public void m578b() {
        setView(R.layout.activity_search_recent);
        this.f591d = (TabView) findViewById(R.id.tab_view);
        this.f592e = (ListView) findViewById(R.id.lv_data);
        this.f593f = (Button) findViewById(R.id.btn_prev);
        this.f594g = (Button) findViewById(R.id.btn_next);
        this.f588a = new C0007h(getContext(), R.layout.view_chip_item);
        this.f591d.setTitle(new int[]{R.string.str_tab_search1, R.string.str_tab_search2, R.string.str_tab_search3});
        this.f592e.setOnItemClickListener(new dg(this));
        this.f591d.setOnClickListener(new dh(this));
        this.f594g.setOnClickListener(new di(this));
        this.f593f.setOnClickListener(new dj(this));
    }

    public Object mo13d() {
        return m243c((int) R.layout.activity_main);
    }

    public void m580j() {
        this.f588a.m9a(getDatabase().m632a(getWorkType()));
        this.f592e.setAdapter(this.f588a);
    }
}
