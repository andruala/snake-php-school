package com.iprog.device;

import android.content.Context;
import android.graphics.Canvas;
import android.view.animation.AnimationUtils;
import android.widget.ListView;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewSwitcher;
import com.iprog.p001b.C0012c;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0030f;
import com.iprog.p003d.C0033i;
import com.iprog.p003d.C0041q;
import com.iprog.p004f.C0099y;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0107g;
import com.iprog.view.IProgItem;
import com.iprog.view.ao;
import com.iprog.view.ay;
import com.iprog.view.br;
import com.iprog.view.bs;
import java.util.Timer;

public class cm extends cg {
    C0013d f498a = C0013d.m42d();
    ListView f499b = null;
    IProgItem[] f500c = new IProgItem[9];
    ao f501d;
    TextView f502e = null;
    TextSwitcher f503f = null;
    bs f504g = null;
    ViewSwitcher f505h = null;
    ay f506i = null;
    br f507j = new cn(this);
    int f508k = 0;
    int f509l = 0;
    boolean f510m = false;
    Object f511n = new Object();
    boolean f512o = false;
    C0033i f513p;
    String[] f514q = m252e(R.array.array_main_msg);
    int f515r = 0;
    Timer f516s = null;

    public cm(Context context) {
        super(context);
        m489j();
    }

    private void m485a(bs bsVar) {
        if (bsVar != null) {
            try {
                if (bsVar.isShowing()) {
                    bsVar.dismiss();
                }
            } catch (Exception e) {
            }
        }
    }

    private boolean m487a(C0099y c0099y) {
        if (c0099y.f807W == 4) {
            if (this.f506i.m933b()) {
                this.f498a.f87s = this.f498a.m99h(this.f498a.f58G);
            }
            c0099y.f807W = 3;
            this.f506i.m928a(c0099y);
            this.f512o = true;
        } else if (c0099y.f807W == 3) {
            C0104d.m830a(c0099y.m764B());
            this.f498a.f87s = this.f498a.m99h(this.f498a.f58G);
            C0030f e = this.f498a.m91e(String.valueOf(c0099y.f812c));
            mo9c();
            this.f510m = false;
            if ((e == null || e.m169a(c0099y.f824o) == null) && (this.f506i.m933b() || !this.f512o)) {
                m495a(m256g(23102), false);
                C0107g.m839a().m840a(0);
                this.f512o = false;
                this.f506i.m926a();
            } else {
                if (!this.f506i.m933b() && this.f512o) {
                    this.f506i.m928a(c0099y);
                }
                if (this.f506i.m934c() <= 1 || !this.f512o) {
                    C0041q c0041q = new C0041q();
                    c0041q.m220a("menu", Integer.valueOf(R.id.menu_reset));
                    if (this.f506i.m934c() == 1 && this.f512o) {
                        c0041q.m220a("chip_search", this.f506i.m931b(0));
                    } else {
                        c0041q.m220a("chip_search", c0099y);
                    }
                    this.f498a.f88t = 1;
                    this.f512o = false;
                    this.f506i.m926a();
                    m227a((int) R.layout.activity_chip_info, c0041q);
                } else {
                    this.f506i.show();
                }
            }
        }
        return true;
    }

    private boolean m488d(C0099y c0099y) {
        try {
            if (c0099y.f807W == 1 || c0099y.f807W == 2) {
                if (c0099y.f807W == 1) {
                    if (this.f513p != null) {
                        this.f513p.m183a();
                    }
                    this.f513p = new C0033i();
                    this.f513p.mo2b(String.valueOf(c0099y.f813d));
                }
                if (c0099y.ad > 0) {
                    this.f513p.mo1a(c0099y.ac, c0099y.ad);
                }
                return true;
            }
            if (c0099y.f807W == 3) {
                this.f513p.m183a();
                this.f513p = null;
            }
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "readChipDataHid");
        }
    }

    private void m489j() {
        m246c((int) R.layout.activity_main, (int) R.string.str_pos_home);
        this.f499b = (ListView) findViewById(R.id.lv_search_item);
        this.f500c[0] = (IProgItem) findViewById(R.id.menu_reset);
        this.f500c[1] = (IProgItem) findViewById(R.id.menu_etc);
        this.f500c[2] = (IProgItem) findViewById(R.id.menu_env);
        this.f502e = (TextView) findViewById(R.id.tv_version);
        this.f503f = (TextSwitcher) findViewById(R.id.tv_msg);
        this.f505h = new ViewSwitcher(getContext());
        this.f503f.setFactory(new co(this));
        this.f503f.setInAnimation(AnimationUtils.loadAnimation(getApplication(), 17432578));
        this.f503f.setOutAnimation(AnimationUtils.loadAnimation(getApplication(), 17432579));
        for (int i = 0; i < this.f500c.length; i++) {
            if (this.f500c[i] != null) {
                this.f500c[i].setOnClickListener(this.f507j);
            }
        }
        this.f501d = new ao(getApplication());
        this.f501d.m921a(new cp(this));
        this.f506i = new ay(getApplication());
        this.f506i.setTitle(R.string.str_cb_title_model);
        this.f506i.m927a((int) R.string.multi_model_msg);
        this.f506i.m929a(new cq(this));
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m490k() {
        /*
        r4 = this;
        r3 = 0;
        r2 = 1;
        r1 = r4.f511n;
        monitor-enter(r1);
        r0 = r4.f510m;	 Catch:{ all -> 0x0045 }
        if (r0 == 0) goto L_0x0010;
    L_0x0009:
        r0 = "검색 중입니다.";
        com.iprog.p006g.C0104d.m830a(r0);	 Catch:{ all -> 0x0045 }
        monitor-exit(r1);	 Catch:{ all -> 0x0045 }
    L_0x000f:
        return;
    L_0x0010:
        r0 = 1;
        r4.f510m = r0;	 Catch:{ all -> 0x0045 }
        monitor-exit(r1);	 Catch:{ all -> 0x0045 }
        r0 = r4.getTitleName();
        r1 = 2131230803; // 0x7f080053 float:1.807767E38 double:1.052967923E-314;
        r1 = r4.m248d(r1);
        r4.mo4a(r3, r0, r1, r2);
        r0 = new com.iprog.f.y;
        r0.<init>();
        r1 = r4.f498a;
        r1 = r1.f58G;
        if (r1 <= 0) goto L_0x0048;
    L_0x002d:
        r1 = r4.f498a;
        r1 = r1.f58G;
        r0.m785e(r1);
    L_0x0034:
        r1 = 32;
        r0.m781d(r1);
        r0.m777c(r2);
        r1 = "0";
        r0.m766a(r1);
        r4.m242c(r0);
        goto L_0x000f;
    L_0x0045:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0045 }
        throw r0;
    L_0x0048:
        r0.m785e(r3);
        goto L_0x0034;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.iprog.device.cm.k():void");
    }

    public void mo3a() {
        C0104d.m830a("MainView onStop");
        try {
            if (this.f516s != null) {
                this.f516s.cancel();
                this.f516s = null;
            }
        } catch (Exception e) {
        }
    }

    protected void mo4a(int i, String str, String str2, boolean z) {
        mo9c();
        try {
            this.f504g = new bs(getContext());
            this.f504g.m948a(i);
            this.f504g.m950a(str);
            this.f504g.m952b(str2);
            this.f504g.m949a(new cr(this));
            this.f504g.show();
        } catch (Exception e) {
            C0104d.m829a(e, "showProgress");
        }
    }

    public void m493a(int i, boolean z) {
        if (z) {
            m495a(m253f(i), z);
        } else {
            m495a(m256g(i), z);
        }
    }

    public void mo5a(C0041q c0041q) {
        C0104d.m830a("MainView onStart ");
        if (c0041q == null) {
            C0104d.m830a("onStart Object Null");
        }
        m497b();
        if (this.f516s != null) {
            this.f516s.cancel();
            this.f516s = null;
        }
        this.f516s = new Timer();
        this.f516s.schedule(new cs(this), 1000, 7000);
        this.f508k = 0;
        this.f509l = 0;
    }

    public void m495a(String str, boolean z) {
        C0104d.m830a("Text Message:" + str);
        this.f498a.m61a(0, str, 0);
    }

    public boolean mo7a(int i, int i2) {
        switch (i2) {
            case 2:
                if (!m260i()) {
                    m490k();
                    break;
                }
                break;
            case 4:
                return false;
        }
        return super.mo7a(i, i2);
    }

    void m497b() {
        String str = "X2";
        if (C0013d.m42d().m110l()) {
            str = "C&M";
        }
        this.f502e.setText("i-PROG " + str + " " + C0013d.m42d().m115p());
    }

    public boolean mo8b(C0099y c0099y) {
        C0104d.m830a(String.format("onPacketReceive:%02x,%d,%d", new Object[]{Integer.valueOf(c0099y.m808w()), Integer.valueOf(c0099y.f807W), Integer.valueOf(c0099y.m763A())}));
        C0012c.m33a(c0099y);
        int A = c0099y.m763A();
        if (!mo28a(A) && A != 12001 && A != 12002 && A != 12003 && A != 12004) {
            m493a(c0099y.m763A(), true);
            mo9c();
            C0107g.m839a().m840a(0);
            this.f510m = false;
        } else if (c0099y.m808w() == 32) {
            m487a(c0099y);
        } else if (c0099y.m808w() == 81) {
            m488d(c0099y);
        }
        return true;
    }

    public void mo9c() {
        m485a(this.f504g);
    }

    public Object mo13d() {
        return null;
    }

    public void mo22e() {
        m497b();
    }

    public void mo23g() {
        C0104d.m830a("onDestory onStop");
        try {
            if (this.f516s != null) {
                this.f516s.cancel();
                this.f516s = null;
            }
        } catch (Exception e) {
        }
    }

    protected void onDraw(Canvas canvas) {
        if (!isInEditMode()) {
            super.onDraw(canvas);
        }
    }
}
