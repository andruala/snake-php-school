package com.iprog.device;

import java.util.TimerTask;

class cc extends TimerTask {
    final /* synthetic */ IProgActivity f480a;

    cc(IProgActivity iProgActivity) {
        this.f480a = iProgActivity;
    }

    public void run() {
        this.f480a.f310X.m69a(this.f480a.f301O, 3);
    }
}
