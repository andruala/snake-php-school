package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class C0053f implements OnClickListener {
    final /* synthetic */ C0047d f637a;

    C0053f(C0047d c0047d) {
        this.f637a = c0047d;
    }

    public void onClick(View view) {
        this.f637a.m544q();
    }
}
