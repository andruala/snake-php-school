package com.iprog.device;

import android.app.ActivityManagerNative;
import android.app.IActivityManager;
import android.app.backup.BackupManager;
import android.content.Context;
import android.content.res.Configuration;
import android.widget.ListView;
import com.iprog.p000a.C0008i;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;
import com.iprog.view.C0116j;
import com.iprog.view.ad;
import com.iprog.view.bb;
import com.iprog.view.bg;
import java.util.Locale;

public class dk extends cg {
    C0008i f599a = null;
    C0116j f600b = null;
    bb f601c = null;
    bg f602d = null;
    ad f603e = null;
    Context f604f = null;
    int[] f605g = new int[]{R.string.setting_nm_lang, R.string.setting_nm_sound, R.string.setting_nm_date, R.string.setting_nm_credit, R.string.setting_nm_upgrade, R.string.setting_nm_bluetooth, R.string.setting_nm_info};
    int[] f606h = new int[]{R.drawable.img_set_language, R.drawable.img_set_sound, R.drawable.img_set_date, R.drawable.img_set_credit, R.drawable.img_set_upgrade, R.drawable.img_set_blue_ico, R.drawable.img_set_info};
    int f607i = 0;
    private ListView f608j = null;

    public dk(Context context) {
        super(context);
        this.f604f = context;
        m585b();
    }

    public static void m582a(Locale locale) {
        try {
            IActivityManager iActivityManager = ActivityManagerNative.getDefault();
            Configuration configuration = iActivityManager.getConfiguration();
            configuration.locale = locale;
            configuration.getClass().getField("userSetLocale").setBoolean(configuration, true);
            iActivityManager.updateConfiguration(configuration);
            BackupManager.dataChanged("com.android.providers.settings");
        } catch (Exception e) {
            C0104d.m829a(e, "updateLocaleEx");
        }
    }

    public void mo3a() {
    }

    public void mo5a(C0041q c0041q) {
        try {
            C0104d.m830a("onStart SettingView:" + c0041q.m217a());
            c0041q.m217a();
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }

    public void m585b() {
        m246c((int) R.layout.activity_setting, (int) R.string.str_pos_env_setting);
        this.f599a = new C0008i(getApplication(), R.layout.setting_list_item);
        this.f608j = (ListView) findViewById(R.id.lv_data);
        this.f600b = new C0116j(getContext(), null, R.layout.dlg_popup_list);
        String locale = Locale.getDefault().toString();
        C0104d.m830a("current local:" + locale);
        if (locale.indexOf("ko") >= 0) {
            this.f607i = 1;
        } else if (locale.indexOf("zh") >= 0) {
            this.f607i = 2;
        } else if (locale.indexOf("ja") >= 0) {
            this.f607i = 3;
        } else if (locale.indexOf("ru") >= 0) {
            this.f607i = 4;
        } else if (locale.indexOf("es") >= 0) {
            this.f607i = 5;
        }
        C0104d.m830a("Setting View init:" + locale);
        this.f600b.m960a((int) R.string.setting_lang_title);
        if (C0013d.m49y() <= 12) {
            this.f600b.m971a(m252e(R.array.setting_lang), m252e(R.array.setting_lang_value), this.f607i);
        } else if (C0013d.m49y() == 13) {
            this.f600b.m971a(m252e(R.array.setting_lang2), m252e(R.array.setting_lang_value2), this.f607i);
        } else {
            this.f600b.m971a(m252e(R.array.setting_lang3), m252e(R.array.setting_lang_value3), this.f607i);
        }
        this.f601c = new bb(getApplication());
        this.f602d = new bg(getApplication());
        this.f603e = new ad(getApplication());
        if (this.f599a == null) {
            C0104d.m830a("adapter null");
        }
        this.f599a.m10a(this.f606h, this.f605g);
        this.f608j.setAdapter(this.f599a);
        this.f608j.setOnItemClickListener(new dl(this));
        this.f600b.m961a(new dm(this));
        this.f601c.m935a(new dn(this));
    }

    public Object mo13d() {
        return m243c((int) R.layout.activity_main);
    }

    public void m587i(int i) {
        C0104d.m831a("setting menu click index", i);
        switch (i) {
            case 0:
                if (!this.f600b.m984f()) {
                    this.f600b.m981d();
                    return;
                }
                return;
            case 1:
                this.f601c.show();
                return;
            case 2:
                m238b((int) R.layout.activity_datetime);
                return;
            case 3:
                m238b((int) R.layout.activity_credit_add);
                return;
            case 4:
                m238b((int) R.layout.activity_device_upgrade);
                return;
            case 5:
                m238b((int) R.layout.activity_bluetooth);
                return;
            case 6:
                m238b((int) R.layout.activity_device_info);
                return;
            default:
                return;
        }
    }
}
