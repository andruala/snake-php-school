package com.iprog.device;

import com.iprog.p003d.C0041q;
import com.iprog.view.aq;

class cp implements aq {
    final /* synthetic */ cm f519a;

    cp(cm cmVar) {
        this.f519a = cmVar;
    }

    public void mo25a(int i) {
        C0041q c0041q = new C0041q();
        c0041q.m220a("menu", Integer.valueOf(i));
        switch (i) {
            case R.id.menu_chip_check:
                this.f519a.f498a.f87s = this.f519a.f498a.m52D(this.f519a.f498a.f58G);
                this.f519a.f498a.f88t = 5;
                this.f519a.m227a((int) R.layout.activity_search_recent, c0041q);
                return;
            case R.id.menu_job_log:
                this.f519a.m227a((int) R.layout.activity_work_history1, c0041q);
                return;
            case R.id.menu_chip_read_list:
                this.f519a.m227a((int) R.layout.activity_chip_read_list, c0041q);
                return;
            default:
                return;
        }
    }
}
