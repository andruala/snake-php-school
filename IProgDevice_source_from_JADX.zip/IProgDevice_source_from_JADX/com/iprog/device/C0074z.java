package com.iprog.device;

import com.iprog.view.C0058e;

class C0074z implements C0058e {
    final /* synthetic */ ChipInfoView f660a;

    C0074z(ChipInfoView chipInfoView) {
        this.f660a = chipInfoView;
    }

    public void mo34a(int i, boolean z) {
        this.f660a.m290n();
    }
}
