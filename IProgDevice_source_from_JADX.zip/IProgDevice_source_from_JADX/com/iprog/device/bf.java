package com.iprog.device;

class bf implements Runnable {
    final /* synthetic */ ay f449a;
    private final /* synthetic */ int f450b;

    bf(ay ayVar, int i) {
        this.f449a = ayVar;
        this.f450b = i;
    }

    public void run() {
        this.f449a.f437j.m938a(this.f450b);
    }
}
