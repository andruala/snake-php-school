package com.iprog.device;

import com.iprog.view.bu;

class C0066r implements bu {
    final /* synthetic */ ChipInfoView f652a;

    C0066r(ChipInfoView chipInfoView) {
        this.f652a = chipInfoView;
    }

    public void mo21a(int i, int i2) {
    }
}
