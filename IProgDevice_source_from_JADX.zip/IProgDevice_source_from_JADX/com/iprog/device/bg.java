package com.iprog.device;

class bg implements Runnable {
    final /* synthetic */ ay f451a;
    private final /* synthetic */ int f452b;

    bg(ay ayVar, int i) {
        this.f451a = ayVar;
        this.f452b = i;
    }

    public void run() {
        this.f451a.f437j.m941b(this.f452b);
    }
}
