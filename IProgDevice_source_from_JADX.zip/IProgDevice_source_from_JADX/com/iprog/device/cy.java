package com.iprog.device;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.iprog.p003d.C0030f;
import com.iprog.p003d.C0035k;
import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;

class cy implements OnItemClickListener {
    final /* synthetic */ cw f536a;

    cy(cw cwVar) {
        this.f536a = cwVar;
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        C0104d.m830a("SearchCpview current pos:" + this.f536a.f534k);
        try {
            C0041q c0041q;
            if (this.f536a.f534k == 0) {
                int c = this.f536a.x.m84c((String) this.f536a.f524a.get(i));
                this.f536a.f527d = this.f536a.x.m56a(c, this.f536a.getWorkType());
                this.f536a.f534k = 1;
                c0041q = new C0041q();
                c0041q.m220a("pos", Integer.valueOf(1));
                this.f536a.m227a((int) R.layout.activity_search_cp, c0041q);
            } else if (this.f536a.f534k == 1) {
                this.f536a.f534k = 2;
                String str = (String) this.f536a.f529f.get(i);
                this.f536a.f528e.clear();
                for (int i2 = 0; i2 < this.f536a.f527d.size(); i2++) {
                    if (((C0030f) this.f536a.f527d.get(i2)).f170d.equals(str)) {
                        this.f536a.f528e.add((C0030f) this.f536a.f527d.get(i2));
                    }
                }
                c0041q = new C0041q();
                c0041q.m220a("pos", Integer.valueOf(2));
                this.f536a.m227a((int) R.layout.activity_search_cp, c0041q);
            } else if (this.f536a.f534k == 2) {
                C0035k c0035k = new C0035k((C0030f) this.f536a.f528e.get(i), 0, 1);
                C0104d.m830a(c0035k.toString());
                c0041q = new C0041q();
                c0041q.m220a("chip_data", c0035k);
                this.f536a.m228a((int) R.layout.activity_chip_info, c0041q, this.f536a.getWorkType());
            }
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }
}
