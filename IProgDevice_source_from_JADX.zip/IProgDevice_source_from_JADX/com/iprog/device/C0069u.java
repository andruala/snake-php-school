package com.iprog.device;

import com.iprog.p006g.C0104d;
import com.iprog.view.C0050m;

class C0069u implements C0050m {
    final /* synthetic */ ChipInfoView f655a;

    C0069u(ChipInfoView chipInfoView) {
        this.f655a = chipInfoView;
    }

    public void mo31a(int i, String str) {
        C0104d.m830a("view _cb_nat_ctrl onclick:" + str);
        this.f655a.m290n();
        this.f655a.setColorList(str);
    }
}
