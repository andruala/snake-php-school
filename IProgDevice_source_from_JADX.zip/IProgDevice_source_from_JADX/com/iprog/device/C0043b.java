package com.iprog.device;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.p006g.C0104d;

class C0043b implements OnClickListener {
    final /* synthetic */ C0042a f443a;

    C0043b(C0042a c0042a) {
        this.f443a = c0042a;
    }

    public void onClick(View view) {
        BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
        C0104d.m830a("Scan Mode:" + defaultAdapter.getScanMode());
        Intent intent = new Intent("android.bluetooth.adapter.action.REQUEST_DISCOVERABLE");
        intent.putExtra("android.bluetooth.adapter.extra.DISCOVERABLE_DURATION", 120);
        ((Activity) this.f443a.getApplication()).startActivity(intent);
        C0104d.m830a("Scan Mode:" + defaultAdapter.getScanMode());
    }
}
