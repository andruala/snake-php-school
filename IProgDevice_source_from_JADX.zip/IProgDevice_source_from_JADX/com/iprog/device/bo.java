package com.iprog.device;

import com.iprog.p004f.C0045e;
import com.iprog.p004f.C0099y;

class bo implements C0045e {
    final /* synthetic */ IProgActivity f461a;

    bo(IProgActivity iProgActivity) {
        this.f461a = iProgActivity;
    }

    public boolean mo20a(C0099y c0099y) {
        this.f461a.m388c(c0099y);
        return false;
    }
}
