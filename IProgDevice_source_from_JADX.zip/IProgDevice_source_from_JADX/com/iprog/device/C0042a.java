package com.iprog.device;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;

public class C0042a extends cg {
    Button f343a = null;
    Button f344b = null;
    TextView f345c = null;
    TextView f346d = null;
    LinearLayout f347e = null;
    ImageView f348f = null;

    public C0042a(Context context) {
        super(context);
        m390b();
    }

    private void m390b() {
        m246c((int) R.layout.activity_bluetooth, (int) R.string.str_pos_bluetooth_setting);
        this.f348f = (ImageView) findViewById(R.id.img_onoff);
        this.f343a = (Button) findViewById(R.id.btn_show);
        this.f345c = (TextView) findViewById(R.id.tv_bt_name);
        this.f346d = (TextView) findViewById(R.id.tv_con_device_name);
        this.f344b = (Button) findViewById(R.id.btn_disconnect);
        this.f347e = (LinearLayout) findViewById(R.id.ll_connect);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.ll_tmp);
        this.f343a.setOnClickListener(new C0043b(this));
        this.f344b.setOnClickListener(new C0046c(this));
    }

    public void mo3a() {
    }

    public void mo5a(C0041q c0041q) {
        C0104d.m830a("onStart:" + c0041q.m217a());
        if (c0041q.m217a() == 0) {
            BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
            try {
                if (defaultAdapter.getAddress().trim().isEmpty()) {
                    this.f348f.setImageResource(R.drawable.img_off);
                } else {
                    this.f345c.setText(defaultAdapter.getName());
                    this.f348f.setImageResource(R.drawable.img_on);
                }
            } catch (Exception e) {
                this.f348f.setImageResource(R.drawable.img_off);
                this.f345c.setText("");
            }
            mo12a(!C0013d.m42d().af.isEmpty());
        }
    }

    public void mo12a(boolean z) {
        if (z) {
            this.f344b.setVisibility(0);
            this.f346d.setText(new StringBuilder(String.valueOf(this.x.m123t())).append("\n").append(this.x.m125u()).toString());
            return;
        }
        this.f346d.setText(R.string.bt_connect_empty);
        this.f344b.setVisibility(8);
    }
}
