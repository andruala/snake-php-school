package com.iprog.device;

class bn implements Runnable {
    final /* synthetic */ IProgActivity f460a;

    bn(IProgActivity iProgActivity) {
        this.f460a = iProgActivity;
    }

    public void run() {
        this.f460a.m339c();
    }
}
