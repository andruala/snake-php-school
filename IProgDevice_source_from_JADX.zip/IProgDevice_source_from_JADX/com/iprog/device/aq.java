package com.iprog.device;

import com.iprog.view.ac;

class aq implements ac {
    final /* synthetic */ aj f403a;

    aq(aj ajVar) {
        this.f403a = ajVar;
    }

    public void mo17a(int i) {
        if (i != 1) {
            this.f403a.f385h.m64a(false);
        } else if (this.f403a.m425j()) {
            this.f403a.mo4a(0, this.f403a.m248d(R.string.dlg_credit_send_title), this.f403a.m248d(R.string.dlg_credit_send_msg), false);
            this.f403a.m411a(96, 97, this.f403a.f386i);
        } else {
            this.f403a.m415a(this.f403a.m248d(R.string.online_credit_type_mismatch));
        }
    }
}
