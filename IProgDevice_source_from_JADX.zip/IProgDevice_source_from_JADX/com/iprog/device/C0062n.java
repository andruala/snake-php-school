package com.iprog.device;

import com.iprog.p004f.C0082d;
import com.iprog.p004f.C0099y;
import com.iprog.p006g.C0104d;

class C0062n extends Thread {
    boolean f645a;
    boolean f646b;
    C0099y f647c;
    final /* synthetic */ C0047d f648d;

    private C0062n(C0047d c0047d) {
        this.f648d = c0047d;
        this.f645a = false;
        this.f646b = false;
        this.f647c = null;
    }

    public void m613a() {
        int i = 0;
        this.f645a = true;
        interrupt();
        while (this.f646b) {
            try {
                C0062n.sleep(100);
                int i2 = i + 1;
                C0104d.m831a("AutoJobThread Exit count", i);
                i = i2;
            } catch (Exception e) {
                C0104d.m829a(e, "AutoJobThread Exit");
                return;
            }
        }
    }

    public void m614a(C0099y c0099y) {
        this.f647c = c0099y;
    }

    public boolean m615b() {
        return this.f646b;
    }

    public void run() {
        C0104d.m832a("AutoJobThread", "Start");
        try {
            C0062n.sleep(2000);
        } catch (Exception e) {
        }
        while (!this.f645a) {
            try {
                C0062n.sleep(1200);
                this.f646b = true;
                if (!(this.f647c == null || this.f648d.f549M || this.f648d.f551O || this.f648d.f549M || this.f648d.f551O)) {
                    C0104d.m830a("AutoJob Send");
                    C0082d.m729c().m732a(this.f647c);
                }
            } catch (InterruptedException e2) {
                this.f645a = true;
            } catch (Exception e3) {
                C0104d.m829a(e3, "AuitoJobThread");
            }
        }
        this.f646b = false;
        C0104d.m832a("AutoJobThread", "End");
    }
}
