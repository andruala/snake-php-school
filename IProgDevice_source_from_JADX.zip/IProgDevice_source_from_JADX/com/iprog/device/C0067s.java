package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class C0067s implements OnClickListener {
    final /* synthetic */ ChipInfoView f653a;

    C0067s(ChipInfoView chipInfoView) {
        this.f653a = chipInfoView;
    }

    public void onClick(View view) {
        this.f653a.m292p();
    }
}
