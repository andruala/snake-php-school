package com.iprog.device;

import com.iprog.view.ak;

class bc implements ak {
    final /* synthetic */ ay f446a;

    bc(ay ayVar) {
        this.f446a = ayVar;
    }

    public void mo15a(int i) {
        if (i == 1) {
            this.f446a.f437j.m942b(this.f446a.m248d(R.string.up_data_download_wait));
            this.f446a.f437j.show();
            new Thread(new bd(this)).start();
        }
    }
}
