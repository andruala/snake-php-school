package com.iprog.device;

class ai implements Runnable {
    final /* synthetic */ ab f377a;

    ai(ab abVar) {
        this.f377a = abVar;
    }

    public void run() {
        this.f377a.m249d(R.string.dlg_data_send_title, R.string.dlg_data_send_error);
    }
}
