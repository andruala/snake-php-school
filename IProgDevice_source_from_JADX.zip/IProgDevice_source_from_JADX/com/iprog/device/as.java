package com.iprog.device;

import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.os.SystemClock;
import android.widget.Button;
import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;
import java.util.Calendar;

public class as extends cg {
    Button f408a = null;
    Button f409b = null;
    DatePickerDialog f410c = null;
    TimePickerDialog f411d = null;
    private int f412e;
    private int f413f;
    private int f414g;
    private int f415h;
    private int f416i;
    private OnDateSetListener f417j = new at(this);
    private OnTimeSetListener f418k = new au(this);

    public as(Context context) {
        super(context);
        m440b();
    }

    private void m440b() {
        m246c((int) R.layout.activity_datetime, (int) R.string.str_pos_datetime_setting);
        this.f408a = (Button) findViewById(R.id.btn_date);
        this.f409b = (Button) findViewById(R.id.btn_time);
        this.f410c = new DatePickerDialog(getApplication(), this.f417j, this.f412e, this.f413f, this.f414g);
        this.f411d = new TimePickerDialog(getApplication(), this.f418k, this.f415h, this.f416i, false);
        this.f408a.setOnClickListener(new av(this));
        this.f409b.setOnClickListener(new aw(this));
    }

    public void mo3a() {
    }

    void m449a(int i, int i2, int i3) {
        Calendar instance = Calendar.getInstance();
        instance.set(1, i);
        instance.set(2, i2);
        instance.set(5, i3);
        long timeInMillis = instance.getTimeInMillis();
        if (timeInMillis / 1000 < 2147483647L) {
            SystemClock.setCurrentTimeMillis(timeInMillis);
        }
    }

    public void mo5a(C0041q c0041q) {
        try {
            C0104d.m830a("onStart DateTimeView:" + c0041q.m217a());
            c0041q.m217a();
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }

    void m451b(int i, int i2) {
        Calendar instance = Calendar.getInstance();
        instance.set(11, i);
        instance.set(12, i2);
        instance.set(13, 0);
        instance.set(14, 0);
        long timeInMillis = instance.getTimeInMillis();
        if (timeInMillis / 1000 < 2147483647L) {
            SystemClock.setCurrentTimeMillis(timeInMillis);
        }
    }
}
