package com.iprog.device;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import com.iprog.p001b.C0013d;

public class IntroActivity extends Activity {
    C0013d f339a = null;
    Handler f340b = new cl(this);
    int f341c = 5000;
    int f342d = 200;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_intro);
        getWindow().addFlags(4718720);
        C0013d.m42d().ad = this.f340b;
    }

    protected void onStart() {
        super.onStart();
    }
}
