package com.iprog.device;

import com.iprog.p003d.C0025a;
import com.iprog.p006g.C0104d;
import com.iprog.view.C0050m;

class C0054g implements C0050m {
    final /* synthetic */ C0047d f638a;

    C0054g(C0047d c0047d) {
        this.f638a = c0047d;
    }

    public void mo31a(int i, String str) {
        C0104d.m830a("view _cb_model_ctrl onclick:" + str);
        this.f638a.f555b = (C0025a) this.f638a.f558e.get(i);
        this.f638a.m542o();
        this.f638a.m551x();
        this.f638a.m546s();
    }
}
