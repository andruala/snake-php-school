package com.iprog.device;

import com.iprog.p004f.C0082d;
import com.iprog.p004f.C0099y;
import com.iprog.p006g.C0104d;

class aa extends Thread {
    boolean f349a;
    boolean f350b;
    C0099y f351c;
    final /* synthetic */ ChipInfoView f352d;

    private aa(ChipInfoView chipInfoView) {
        this.f352d = chipInfoView;
        this.f349a = false;
        this.f350b = false;
        this.f351c = null;
    }

    public void m394a() {
        int i = 0;
        this.f349a = true;
        C0082d.m729c().m734b(2);
        interrupt();
        while (this.f350b) {
            try {
                sleep(100);
                int i2 = i + 1;
                C0104d.m831a("AutoJobThread Exit count", i);
                i = i2;
            } catch (Exception e) {
                C0104d.m829a(e, "AutoJobThread Exit");
                return;
            }
        }
    }

    public void m395a(C0099y c0099y) {
        this.f351c = c0099y;
    }

    public boolean m396b() {
        return this.f350b || !this.f349a;
    }

    public void run() {
        C0104d.m830a("AutoJobThread Start:" + getId());
        this.f350b = true;
        while (!this.f349a) {
            try {
                sleep(1200);
                if (!(this.f351c == null || this.f352d.f262V || this.f352d.f264Z || this.f352d.f262V || this.f352d.f264Z)) {
                    C0104d.m830a("AutoJobThread send packet:" + getId());
                    C0082d.m729c().m733a(this.f351c, false);
                }
            } catch (InterruptedException e) {
                this.f349a = true;
            } catch (Exception e2) {
                C0104d.m829a(e2, "AuitoJobThread");
            }
        }
        this.f350b = false;
        C0104d.m830a("AutoJobThread End:" + getId());
    }
}
