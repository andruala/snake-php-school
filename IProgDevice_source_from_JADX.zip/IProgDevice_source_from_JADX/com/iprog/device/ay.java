package com.iprog.device;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;
import com.iprog.p001b.C0013d;
import com.iprog.p002c.C0023a;
import com.iprog.p003d.C0037m;
import com.iprog.p003d.C0039o;
import com.iprog.p003d.C0040p;
import com.iprog.p003d.C0041q;
import com.iprog.p004f.ab;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import com.iprog.view.ai;
import com.iprog.view.bk;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Locale;

public class ay extends cg {
    TextView f428a = null;
    TextView f429b = null;
    TextView f430c = null;
    TextView f431d = null;
    Button f432e = null;
    Button f433f = null;
    C0013d f434g = null;
    C0040p f435h = null;
    ai f436i = null;
    bk f437j = null;
    final int f438k = 1;
    boolean f439l = false;
    boolean f440m = false;
    Handler f441n = new az(this);

    public ay(Context context) {
        super(context);
        m458b();
    }

    private ab m456a(C0039o c0039o) {
        InputStream bufferedInputStream;
        Exception e;
        Throwable th;
        Object valueOf = String.valueOf(this.f434g.f53B);
        if (C0013d.m42d().m110l()) {
            valueOf = String.valueOf(this.f434g.f53B + 16);
        }
        String stringBuilder = new StringBuilder(String.valueOf(this.f434g.m114o())).append("?mtype=DOWN&req=IPROG&ver2=X2").append("&p_id=").append(c0039o.f218a).append("&device=").append(this.f434g.m117q()).append("&dev_id=").append(this.f434g.m119r().replace("-", "")).append("&local_id=").append(Locale.getDefault().toString()).append("&xver=").append(this.f434g.m131x(this.f434g.f94z)).append("&appver=").append(this.f434g.m115p()).append("&version=").append(C0013d.m48x()).append("&hw_ver=").append(String.valueOf(valueOf)).append("&xe_ver=").append(String.valueOf(this.f434g.f53B)).append("&hw_ver2=").append(String.valueOf(this.f434g.f54C)).append("&xr_ver=").append(String.valueOf(this.f434g.f52A)).append("&mac_addr=").append(String.valueOf(C0108h.m872g("eth0"))).toString();
        ab abVar = new ab();
        try {
            URL url = new URL(stringBuilder);
            URLConnection openConnection = url.openConnection();
            openConnection.connect();
            abVar.f704q = openConnection.getContentLength();
            abVar.f705r = new byte[abVar.f704q];
            abVar.f701n = c0039o.f220c;
            abVar.f702o = this.f434g.m104j(c0039o.f221d);
            bufferedInputStream = new BufferedInputStream(url.openStream(), 4096);
            int i = 0;
            while (i < abVar.f704q) {
                try {
                    int read = bufferedInputStream.read(abVar.f705r, i, Math.min(abVar.f704q - i, 4096));
                    if (read < 0) {
                        break;
                    }
                    m463j(read);
                    i += read;
                } catch (Exception e2) {
                    e = e2;
                }
            }
            if (i != abVar.f704q) {
                C0108h.m855a(bufferedInputStream);
                return null;
            }
            abVar.f703p = C0023a.m139a(abVar.f705r);
            C0104d.m830a("Download Data Success:" + abVar.f701n + "," + abVar.f704q);
            C0108h.m855a(bufferedInputStream);
            return abVar;
        } catch (Exception e3) {
            e = e3;
            bufferedInputStream = null;
            try {
                C0104d.m829a(e, "DeviceUpgradeView");
                C0108h.m855a(bufferedInputStream);
                return null;
            } catch (Throwable th2) {
                th = th2;
                C0108h.m855a(bufferedInputStream);
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            bufferedInputStream = null;
            C0108h.m855a(bufferedInputStream);
            throw th;
        }
    }

    private void m458b() {
        m246c((int) R.layout.activity_device_upgrade, (int) R.string.str_pos_env_setting);
        this.f428a = (TextView) findViewById(R.id.tv_cur_version);
        this.f429b = (TextView) findViewById(R.id.tv_lst_version);
        this.f430c = (TextView) findViewById(R.id.tv_lst_date);
        this.f431d = (TextView) findViewById(R.id.tv_msg);
        this.f433f = (Button) findViewById(R.id.btn_upgrade);
        this.f432e = (Button) findViewById(R.id.btn_confirm);
        this.f434g = C0013d.m42d();
        this.f436i = new ai(getContext());
        this.f436i.m916a(m248d(R.string.dlg_title_upgrade));
        this.f436i.m917b(1);
        this.f437j = new bk(getContext());
        this.f437j.m939a(m248d(R.string.dlg_title_upgrade));
        this.f433f.setOnClickListener(new ba(this));
        this.f432e.setOnClickListener(new bb(this));
        this.f436i.m915a(new bc(this));
    }

    private void m460b(boolean z) {
        ((Activity) getApplication()).runOnUiThread(new bh(this, z));
    }

    private void m461i(int i) {
        ((Activity) getApplication()).runOnUiThread(new bf(this, i));
    }

    private void m462j() {
        int i;
        int i2;
        ArrayList arrayList = new ArrayList();
        if (this.f434g.m104j(this.f435h.f230e.f221d) > this.f434g.f93y) {
            i = this.f435h.f230e.f224g + 0;
            arrayList.add(this.f435h.f230e);
        } else {
            i = 0;
        }
        if (this.f434g.m104j(this.f435h.f232g.f221d) > this.f434g.f92x) {
            i2 = this.f435h.f232g.f224g + i;
            arrayList.add(this.f435h.f232g);
            i = this.f435h.f232g.f224g + 0;
        } else {
            i2 = i;
            i = 0;
        }
        if (this.f434g.m104j(this.f435h.f233h.f221d) > this.f434g.f94z) {
            i2 += this.f435h.f233h.f224g;
            i += this.f435h.f233h.f224g;
            arrayList.add(this.f435h.f233h);
        }
        i2 += this.f435h.f231f.f224g;
        i += this.f435h.f231f.f224g;
        arrayList.add(this.f435h.f231f);
        m461i(i2 * 2);
        Object c0037m = new C0037m();
        for (i2 = 0; i2 < arrayList.size(); i2++) {
            ab a = m456a((C0039o) arrayList.get(i2));
            if (a == null) {
                C0108h.m853a(1000);
                m460b(false);
                m254f(R.string.dlg_title_upgrade, R.string.up_data_download_error);
                return;
            }
            c0037m.m203b(a);
        }
        this.f434g.m70a(this.f434g.f77i, 17, c0037m);
        m460b(false);
    }

    private void m463j(int i) {
        ((Activity) getApplication()).runOnUiThread(new bg(this, i));
    }

    private void m464k() {
        new Thread(new be(this)).start();
    }

    public void mo3a() {
        this.f429b.setText("");
        this.f430c.setText("");
        this.f431d.setText("");
        this.f437j.hide();
        this.f436i.hide();
    }

    public void mo5a(C0041q c0041q) {
        try {
            C0104d.m830a("onStart DeviceInfoView:" + c0041q.m217a());
            this.f439l = false;
            this.f440m = false;
            this.f435h = null;
            this.f428a.setText(this.f434g.m115p());
            c0041q.m217a();
            super.m226a(0, (int) R.string.dlg_title_upgrade, (int) R.string.new_ver_find, true);
            m464k();
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }
}
