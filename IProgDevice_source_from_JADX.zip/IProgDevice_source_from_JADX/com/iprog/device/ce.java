package com.iprog.device;

import java.util.TimerTask;

class ce extends TimerTask {
    final /* synthetic */ IProgActivity f482a;

    ce(IProgActivity iProgActivity) {
        this.f482a = iProgActivity;
    }

    public void run() {
        this.f482a.f310X.m69a(this.f482a.f301O, 1);
    }
}
