package com.iprog.device;

import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.os.IPowerManager;
import android.os.IPowerManager.Stub;
import android.os.Process;
import android.os.ServiceManager;
import android.view.KeyEvent;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.iprog.io.DeviceIO;
import com.iprog.p001b.C0011b;
import com.iprog.p001b.C0013d;
import com.iprog.p002c.C0023a;
import com.iprog.p003d.C0036l;
import com.iprog.p003d.C0037m;
import com.iprog.p003d.C0038n;
import com.iprog.p004f.C0044n;
import com.iprog.p004f.C0078a;
import com.iprog.p004f.C0082d;
import com.iprog.p004f.C0096v;
import com.iprog.p004f.C0099y;
import com.iprog.p004f.aa;
import com.iprog.p004f.ab;
import com.iprog.p004f.ac;
import com.iprog.p006g.C0102b;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0105e;
import com.iprog.p006g.C0106f;
import com.iprog.p006g.C0107g;
import com.iprog.p006g.C0108h;
import com.iprog.view.ai;
import com.iprog.view.al;
import com.iprog.view.bk;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;

public class IProgActivity extends Activity {
    cf f287A = null;
    Handler f288B = new bw(this);
    C0037m f289C = new C0037m();
    boolean f290D = false;
    ab f291E = null;
    final int f292F = 512;
    final int f293G = 72;
    int f294H = 0;
    boolean f295I = false;
    boolean f296J = false;
    boolean f297K = false;
    final int f298L = 1;
    final int f299M = 2;
    final int f300N = 3;
    Handler f301O = new bx(this);
    boolean f302P = false;
    boolean f303Q = false;
    boolean f304R = true;
    int f305S = 1;
    boolean f306T = false;
    final int f307U = 1;
    Handler f308V = new by(this);
    private LinearLayout f309W = null;
    private C0013d f310X = null;
    private cg f311Y = null;
    private int f312Z = 0;
    public cm f313a = null;
    private Button aa = null;
    private ImageButton ab = null;
    private TextView ac = null;
    private TextView ad = null;
    private FileDescriptor ae;
    private FileDescriptor af;
    private C0082d ag = C0082d.m729c();
    private IntentFilter ah;
    private BroadcastReceiver ai;
    ArrayList f314b = new ArrayList();
    ai f315c = null;
    ai f316d = null;
    al f317e = null;
    ai f318f = null;
    ai f319g = null;
    C0096v f320h = null;
    C0078a f321i = null;
    LinearLayout f322j = null;
    bk f323k = null;
    Timer f324l = null;
    Timer f325m = null;
    Timer f326n = null;
    ImageView f327o = null;
    BluetoothAdapter f328p;
    cb f329q = null;
    C0044n f330r = new bi(this);
    int f331s = 0;
    boolean f332t = false;
    Handler f333u = new bs(this);
    Handler f334v = new bt(this);
    Handler f335w = new bu(this);
    int f336x = 0;
    boolean f337y = false;
    boolean f338z = true;

    private void m317a(int i, int i2) {
        C0104d.m830a("**endUpgradeMessage:" + i + "," + i2);
        m358i();
        C0108h.m853a(50);
        m318a(0, 2, 0, i2);
        C0108h.m853a(50);
        if (i2 == 1 || i2 == 0) {
            this.f318f.m918b(getString(R.string.up_success));
        } else {
            this.f318f.m918b(String.format("%s(%d)", new Object[]{getString(R.string.up_fail), Integer.valueOf(i2)}));
        }
        this.f289C.m213f();
        m368n();
        this.f318f.show();
        this.f295I = false;
        this.f296J = false;
        this.f297K = false;
        this.f290D = false;
    }

    private void m318a(int i, int i2, int i3, int i4) {
        int i5 = 1;
        if (!this.f290D) {
            ac acVar = new ac(190, 0);
            C0104d.m830a("sendUpdateStatusToManager:" + i2);
            if (this.f310X.m127v() == 2) {
                C0078a c0078a = this.f321i;
                if (i4 == 0) {
                    i4 = 1;
                }
                c0078a.mo35a(acVar.m714a(i, i2, i3, i4));
                return;
            }
            C0096v c0096v = this.f320h;
            if (i4 != 0) {
                i5 = i4;
            }
            c0096v.mo35a(acVar.m714a(i, i2, i3, i5));
        }
    }

    private void m319a(int i, ab abVar) {
        m332b(5000);
        m330a(abVar);
    }

    private void m325a(ac acVar, int i) {
        ac acVar2 = new ac(acVar.m698b().f754b, 0);
        if (this.f310X.m127v() == 2) {
            this.f321i.mo35a(acVar2.m720c(i));
        } else {
            this.f320h.mo35a(acVar2.m720c(i));
        }
    }

    private void m326a(boolean z) {
        if (z) {
            try {
                this.f328p.enable();
                return;
            } catch (Exception e) {
                C0104d.m829a(e, "BluetoothStatus");
                return;
            }
        }
        this.f328p.disable();
    }

    private void m327a(boolean z, String str, String str2) {
        if (z) {
            this.f310X.ae = str;
            this.f310X.af = str2;
            this.f327o.setImageResource(R.drawable.img_blue_ico);
        } else {
            this.f310X.ae = "";
            this.f310X.af = "";
            this.f327o.setImageBitmap(null);
        }
        this.f311Y.mo12a(z);
    }

    private boolean m328a(int i, ab abVar, int i2) {
        C0099y c0099y = new C0099y();
        int i3 = (i == 134 || i == 139) ? 72 : 512;
        int i4 = abVar.f704q / i3;
        int i5 = i2 - 1;
        if (i4 * i3 < abVar.f704q) {
            i4++;
        }
        c0099y.m781d(i);
        c0099y.f806V = i2;
        if (i5 < i4) {
            i4 = Math.min(abVar.f704q - (i5 * i3), i3);
            if (C0013d.f49c) {
                C0104d.m830a("DATA:" + i + "," + (i5 * i3) + "," + i5);
            }
            System.arraycopy(abVar.f705r, i5 * i3, c0099y.aa, 0, i4);
        }
        boolean b = this.ag.m656b(c0099y.m807v());
        if (i2 % 4 == 0) {
            m318a(0, 1, i3 * 4, 1);
            m340c(i3 * 4);
        }
        return b;
    }

    private boolean m329a(C0037m c0037m, ac acVar) {
        OutputStream fileOutputStream;
        int i;
        Exception e;
        Throwable th;
        if (!c0037m.m204b("BL")) {
            return false;
        }
        m325a(acVar, 1);
        ab c = c0037m.m207c("BL");
        c0037m.m208c(c);
        try {
            fileOutputStream = new FileOutputStream("/system/media/bootanimation.zip");
            try {
                fileOutputStream.write(c.f705r);
                C0108h.m856a(fileOutputStream);
                i = 0;
            } catch (Exception e2) {
                e = e2;
                try {
                    C0104d.m829a(e, "dataSave");
                    i = -1;
                    C0108h.m856a(fileOutputStream);
                    m317a(0, i);
                    return true;
                } catch (Throwable th2) {
                    th = th2;
                    C0108h.m856a(fileOutputStream);
                    throw th;
                }
            }
        } catch (Exception e3) {
            e = e3;
            fileOutputStream = null;
            C0104d.m829a(e, "dataSave");
            i = -1;
            C0108h.m856a(fileOutputStream);
            m317a(0, i);
            return true;
        } catch (Throwable th3) {
            th = th3;
            fileOutputStream = null;
            C0108h.m856a(fileOutputStream);
            throw th;
        }
        m317a(0, i);
        return true;
    }

    private boolean m330a(ab abVar) {
        C0099y c0099y = new C0099y();
        if (abVar.f701n.equals("FW")) {
            c0099y.m781d(113);
        } else if (abVar.f701n.equals("FD")) {
            c0099y.m781d(129);
        } else if (abVar.f701n.equals("XC")) {
            c0099y.m781d(133);
        } else if (!abVar.f701n.equals("XR")) {
            return false;
        } else {
            c0099y.m781d(138);
        }
        c0099y.f804T = abVar.f702o;
        c0099y.f805U = abVar.f704q;
        return this.ag.m733a(c0099y, false);
    }

    private void m331b() {
        runOnUiThread(new bn(this));
    }

    private void m332b(int i) {
        try {
            this.f287A.m481a(i);
        } catch (Exception e) {
        }
    }

    private void m333b(int i, int i2) {
        this.f319g.m918b(getString(i) + "(" + i2 + ":1)");
        m368n();
        this.f319g.show();
        m367m();
        this.f310X.ag = i2;
        this.f310X.ah = i;
    }

    private void m336b(String str) {
        runOnUiThread(new br(this, str));
    }

    private boolean m337b(C0037m c0037m, ac acVar) {
        if (!c0037m.m204b("SW")) {
            return false;
        }
        C0104d.m830a("##TYPE_SW Upgrade");
        if (c0037m.m212e()) {
            c0037m.m200a(new C0038n(1, this.f323k.m940b(), this.f323k.m937a()));
            if (acVar != null) {
                m325a(acVar, 1);
            }
            m352g();
            m369o();
        } else {
            c0037m.m210d();
            if (acVar != null) {
                m325a(acVar, 24010);
            }
        }
        c0037m.m213f();
        return true;
    }

    private int m338c(String str) {
        aa aaVar = new aa();
        String str2 = "/data/data/com.iprog.main/fileshid/" + str;
        C0013d d = C0013d.m42d();
        try {
            byte[] f = C0108h.m871f(str2);
            aaVar.m690a("msg_id", 161);
            aaVar.m691a("dev_id", d.m119r().replace("-", ""));
            aaVar.m691a("file_name", str);
            aaVar.m691a("data", new String(f));
            aaVar.m691a("dev_type", "IPROG");
            String a = C0105e.m836a(d.m111m(), aaVar.m689a());
            ac acVar = new ac();
            C0036l c0036l = new C0036l();
            if (acVar.m712a(a, c0036l) && c0036l.f210b == 1) {
                new File(str2).delete();
                C0104d.m830a("DeleteFile:" + str);
            }
        } catch (Exception e) {
            C0104d.m829a(e, "sendChipData");
        }
        return 1;
    }

    private void m339c() {
        m382a(new cm(this));
        m382a(new db(this));
        m382a(new cw(this));
        m382a(new df(this));
        m382a(new ChipInfoView(this));
        m382a(new C0047d(this));
        m382a(new C0051do(this));
        m382a(new ab(this));
        m382a(new dk(this));
        m382a(new ax(this));
        m382a(new ay(this));
        m382a(new aj(this));
        m382a(new as(this));
        m382a(new C0042a(this));
        this.f335w.sendEmptyMessageDelayed(4, 50);
    }

    private void m340c(int i) {
        runOnUiThread(new bq(this, i));
    }

    private void m343d() {
        this.f310X.m97g();
        this.f310X.m100h();
        this.f310X.m103i();
        this.f310X.m106j();
        C0104d.m830a("Time: Activity Init 18");
        this.f310X.m95f();
        this.f335w.sendEmptyMessageDelayed(5, 50);
    }

    private void m344d(int i) {
        C0104d.m830a("SET FW-Version:" + i);
        try {
            Editor edit = getSharedPreferences("IPROG", 0).edit();
            edit.putInt("FW_VER", i);
            edit.commit();
        } catch (Exception e) {
        }
    }

    private void m346e() {
        this.f310X.m69a(this.f310X.f76h, (int) R.layout.activity_main);
        this.ae = DeviceIO.serialOpen("/dev/ttySAC0", 921600, 0);
        this.ag.m735b(this.ae);
        this.ag.m731a(new bo(this));
        C0108h.m853a(20);
        m350f();
        this.af = DeviceIO.serialOpen("/dev/ttySAC1", 576000, 0);
        this.f320h = new C0096v(this.af, this.f334v);
        this.f320h.m671a(this.f330r);
        this.f320h.mo36c();
        this.f320h.m671a(new bp(this));
        m380a(0, 0, false);
        this.f325m = new Timer();
        this.f325m.schedule(new cd(this), 30000);
        this.f326n = new Timer();
        this.f328p = BluetoothAdapter.getDefaultAdapter();
        if (this.f328p == null) {
            C0104d.m830a("***************************Bluttooth Error ********************");
            return;
        }
        if (!this.f328p.isEnabled()) {
            m326a(true);
        }
        C0104d.m830a(" ## _bt_adapter.getAddress()::" + this.f328p.getAddress());
        if (this.f328p.getAddress() != null) {
            this.f321i = new C0078a(this, this.f334v);
            this.f321i.m687c();
        }
    }

    private void m347e(int i) {
        C0104d.m830a("SET HW-Version:" + i);
        try {
            Editor edit = getSharedPreferences("IPROG", 0).edit();
            edit.putInt("HW_VER", i);
            edit.commit();
        } catch (Exception e) {
        }
    }

    private boolean m348e(C0099y c0099y) {
        if (c0099y.f792H == 1) {
            this.f305S = 24995;
            return true;
        } else if (c0099y.f794J == 1) {
            this.f305S = 24802;
            return true;
        } else if (c0099y.f788D == 65535 || c0099y.f788D == 256 || c0099y.f788D == 0) {
            this.f305S = 24991;
            return true;
        } else if (c0099y.f791G) {
            this.f305S = 1;
            return false;
        } else {
            this.f305S = 24998;
            return true;
        }
    }

    private void m350f() {
        C0104d.m830a("FW Power Reset");
        boolean gPIOStatus = DeviceIO.getGPIOStatus(1);
        C0108h.m853a(20);
        if (gPIOStatus) {
            DeviceIO.setGPIOStatus(1, false);
            C0108h.m853a(200);
        }
        if (DeviceIO.getGPIOStatus(0)) {
            DeviceIO.setGPIOStatus(0, false);
            C0108h.m853a(400);
        }
        DeviceIO.setGPIOStatus(0, true);
        C0108h.m853a(50);
    }

    private void m351f(int i) {
        C0104d.m830a("SET XE-Version:" + i);
        try {
            Editor edit = getSharedPreferences("IPROG", 0).edit();
            edit.putInt("XE_VER", i);
            edit.commit();
        } catch (Exception e) {
        }
    }

    private void m352g() {
        stopService(new Intent(this, IProgAutorunService.class));
        unregisterReceiver(this.ai);
        if (this.f321i != null) {
            this.f321i.m688d();
        }
        this.f310X.m86c();
        m358i();
        if (this.ag != null) {
            this.ag.m736d();
        }
        if (this.f320h != null) {
            this.f320h.m748d();
        }
        if (this.af != null) {
            DeviceIO.serialClose(this.af);
            this.af = null;
        }
        if (this.ae != null) {
            DeviceIO.serialClose(this.ae);
            this.ae = null;
        }
        DeviceIO.setGPIOStatus(1, false);
        C0108h.m853a(100);
        DeviceIO.setGPIOStatus(0, false);
        C0108h.m853a(20);
        Iterator it = this.f314b.iterator();
        while (it.hasNext()) {
            ((cg) it.next()).mo23g();
        }
        if (this.f329q != null) {
            this.f329q.m479a();
        }
    }

    private void m353g(int i) {
        C0104d.m830a("SET XC-Version:" + i);
        try {
            Editor edit = getSharedPreferences("IPROG", 0).edit();
            edit.putInt("XC_VER", i);
            edit.commit();
        } catch (Exception e) {
        }
    }

    private void m355h() {
        if (this.f287A != null) {
            this.f287A.m482b();
            this.f287A = null;
        }
        C0108h.m853a(50);
        this.f287A = new cf();
        this.f287A.start();
    }

    private void m356h(int i) {
        C0104d.m830a("SET XR-Version:" + i);
        try {
            Editor edit = getSharedPreferences("IPROG", 0).edit();
            edit.putInt("XR_VER", i);
            edit.commit();
        } catch (Exception e) {
        }
    }

    private void m358i() {
        if (this.f287A != null) {
            this.f287A.m482b();
        }
        C0108h.m853a(50);
        this.f287A = null;
    }

    private void m359i(int i) {
        C0104d.m830a("SET Device ID:" + i);
        try {
            Editor edit = getSharedPreferences("IPROG", 0).edit();
            edit.putInt("DV_ID", i);
            edit.commit();
        } catch (Exception e) {
        }
    }

    private void m362j() {
        try {
            this.f287A.m480a();
        } catch (Exception e) {
        }
    }

    private void m363j(int i) {
        try {
            IPowerManager asInterface = Stub.asInterface(ServiceManager.getService("power"));
            if (asInterface != null) {
                asInterface.setBacklightBrightness(i);
            }
        } catch (Exception e) {
            C0104d.m829a(e, "setBrightness");
        }
    }

    private void m364k() {
        this.f295I = false;
        this.f296J = false;
        this.f297K = false;
    }

    private void m366l() {
        C0104d.m830a("*** Start FW App *** ");
        this.f302P = false;
        if (this.f324l != null) {
            this.f324l.cancel();
            this.f324l = null;
        }
        this.f324l = new Timer();
        this.f324l.schedule(new ce(this), 5000);
        C0099y c0099y = new C0099y();
        c0099y.m781d(112);
        this.ag.m733a(c0099y, false);
    }

    private void m367m() {
        this.f310X.m69a(this.f310X.ad, 1);
    }

    private void m368n() {
        this.f315c.hide();
        this.f317e.hide();
        this.f318f.hide();
        this.f319g.hide();
        this.f316d.hide();
        this.f323k.hide();
    }

    private void m369o() {
        C0104d.m830a("installPackage");
        String d = this.f289C.m209d("SW");
        try {
            Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage("com.iprog.service");
            launchIntentForPackage.putExtra("proc", "install");
            launchIntentForPackage.putExtra("fileName", d);
            launchIntentForPackage.putExtra("packageName", "com.iprog.device");
            launchIntentForPackage.putExtra("msg", "MessageTest");
            launchIntentForPackage.putExtra("pid", Process.myPid());
            startActivity(launchIntentForPackage);
        } catch (Exception e) {
            C0104d.m829a(e, "InstallAPP installPackage Error");
        }
    }

    private int m370p() {
        C0104d.m830a("GET FW-Version:" + getSharedPreferences("IPROG", 0).getInt("FW_VER", 257));
        return getSharedPreferences("IPROG", 0).getInt("FW_VER", 257);
    }

    private int m371q() {
        C0104d.m830a("GET HW-Version:" + getSharedPreferences("IPROG", 0).getInt("HW_VER", 17));
        return getSharedPreferences("IPROG", 0).getInt("HW_VER", 17);
    }

    private int m372r() {
        C0104d.m830a("GET XC-Version:" + getSharedPreferences("IPROG", 0).getInt("XC_VER", 259));
        return getSharedPreferences("IPROG", 0).getInt("XC_VER", 259);
    }

    private int m373s() {
        C0104d.m830a("GET XE-Version:" + getSharedPreferences("IPROG", 0).getInt("XE_VER", 1));
        return getSharedPreferences("IPROG", 0).getInt("XE_VER", 1);
    }

    private int m374t() {
        C0104d.m830a("GET XR-Version:" + getSharedPreferences("IPROG", 0).getInt("XR_VER", 512));
        return getSharedPreferences("IPROG", 0).getInt("XR_VER", 512);
    }

    private int m375u() {
        C0104d.m830a("GET DeviceID:" + getSharedPreferences("IPROG", 0).getInt("DV_ID", 0));
        return getSharedPreferences("IPROG", 0).getInt("DV_ID", 0);
    }

    private int m376v() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception e) {
            C0104d.m828a(e);
            return 1;
        }
    }

    private List m377w() {
        List arrayList = new ArrayList();
        try {
            File[] listFiles = new File("/data/data/com.iprog.main/fileshid/").listFiles();
            for (File name : listFiles) {
                arrayList.add(name.getName());
            }
        } catch (Exception e) {
            C0104d.m829a(e, "getSendChipDataList");
        }
        return arrayList;
    }

    public void m378a() {
        if (this.f311Y.getResourceId() != R.layout.activity_main) {
            C0104d.m830a("goHome return :" + this.f311Y.m255f());
            this.f310X.m69a(this.f310X.f76h, (int) R.layout.activity_main);
        }
    }

    public void m379a(int i) {
        this.f310X.f60I = i;
        m380a(this.f310X.f58G, this.f310X.f60I, this.f310X.f61J);
    }

    public void m380a(int i, int i2, boolean z) {
        if (z) {
            if (i == 0) {
                this.ac.setText(C0013d.m47o(i2));
            } else {
                this.ac.setText(String.format("[T%d] %s", new Object[]{Integer.valueOf(i), C0013d.m47o(i2)}));
            }
            this.f322j.setVisibility(0);
            return;
        }
        this.f322j.setVisibility(4);
    }

    public void m381a(C0037m c0037m) {
        this.f290D = true;
        this.f289C = c0037m;
        this.f323k.m942b(getString(R.string.up_data_trans_ing));
        this.f323k.m938a(c0037m.m205c() * 2);
        this.f323k.m941b(c0037m.m205c());
        if (!m337b(this.f289C, null)) {
            this.f323k.show();
            this.f323k.m941b(0);
            this.f302P = false;
            this.f289C.m210d();
            m350f();
        }
    }

    public void m382a(cg cgVar) {
        this.f314b.add(cgVar);
    }

    public void m383a(ac acVar) {
        int i = 1;
        if (acVar.m698b().f754b != 188) {
            C0104d.m830a(String.format("onMessageUpgradeFromMA:%02x", new Object[]{Integer.valueOf(acVar.m698b().f754b)}));
        }
        ab e = acVar.m722e();
        switch (e.f688a) {
            case 186:
                m378a();
                C0108h.m853a(50);
                C0104d.m830a(String.format("Upgrade MSG_ID_UP_INFO:%d", new Object[]{Integer.valueOf(e.f697j)}));
                m368n();
                this.f290D = false;
                this.f289C.m197a(e);
                this.f289C.m213f();
                this.f323k.m938a(e.m692a());
                this.f323k.m941b(0);
                this.f323k.m942b(getString(R.string.up_data_trans_wait));
                this.f323k.show();
                m355h();
                m332b(5000);
                break;
            case 187:
                C0104d.m830a(String.format("Upgrade Data Start[%s]:%d,%d,%s", new Object[]{e.f701n, Integer.valueOf(e.f702o), Integer.valueOf(e.f704q), e.f703p}));
                this.f291E = e;
                if (!this.f297K) {
                    m332b(5000);
                    this.f297K = true;
                    this.f323k.m942b(getString(R.string.up_data_trans_ing));
                    break;
                }
                break;
            case 188:
                int a = C0102b.m820a(e.f705r);
                if (a == e.f710w) {
                    System.arraycopy(e.f705r, 0, this.f291E.f705r, Math.max(e.f709v - 1, 0) * 2048, e.f704q);
                    if (e.f708u == 1) {
                        String a2 = C0023a.m139a(this.f291E.f705r);
                        if (a2.equals(this.f291E.f703p)) {
                            this.f289C.m203b(this.f291E);
                        } else {
                            C0104d.m830a("MD5:" + a2 + "," + this.f291E.f703p);
                            C0104d.m830a("Hash Error:");
                            return;
                        }
                    }
                    m340c(e.f704q);
                    break;
                }
                C0104d.m830a("###CRC Error:" + a + "," + e.f710w);
                i = 23204;
                break;
            case 189:
                this.f323k.m942b(getString(R.string.up_data_trans_ing));
                this.f302P = false;
                if (!m337b(this.f289C, acVar) && !m329a(this.f289C, acVar)) {
                    this.f289C.m210d();
                    m350f();
                    break;
                }
                return;
            default:
                C0104d.m831a("Unknow Message:", e.f688a);
                return;
        }
        m362j();
        m325a(acVar, i);
    }

    public void m384a(C0099y c0099y) {
        if (c0099y.f835z) {
            C0104d.m830a(String.format("In Credit Type:%d,Count:%d,Version:%02x", new Object[]{Integer.valueOf(c0099y.f833x), Integer.valueOf(c0099y.f834y), Integer.valueOf(c0099y.f832w)}));
            if (this.f310X.m110l()) {
                if (c0099y.f833x < 110 || c0099y.f833x >= 210) {
                    this.f310X.m61a(0, getString(R.string.credit_not_comp), 0);
                    return;
                }
                c0099y.f833x -= 110;
            } else if (c0099y.f833x < 0 || c0099y.f833x > 109) {
                this.f310X.m61a(0, getString(R.string.credit_not_comp), 0);
                return;
            }
        }
        m387b(c0099y);
        this.f336x++;
        if (this.f336x == 1) {
            this.f337y = this.f310X.f61J;
        } else if (this.f337y != this.f310X.f61J) {
            this.f337y = this.f310X.f61J;
            if (!this.f290D) {
                if (this.f310X.f61J) {
                    if (!this.f310X.m122s()) {
                        if (this.f310X.f58G == 0) {
                            this.f338z = true;
                            this.f317e.hide();
                            this.f316d.m916a(getString(R.string.dlg_title_credit));
                            this.f316d.m918b(String.format("%s\n\nCredit:%s", new Object[]{getString(R.string.credit_in), C0013d.m47o(this.f310X.f60I)}));
                            this.f316d.show();
                            return;
                        }
                        this.f338z = false;
                        this.f316d.hide();
                        C0104d.m830a("Credit Show:" + this.f310X.f59H);
                        this.f317e.m919a(this.f310X.f58G, this.f310X.f60I, c0099y.f832w);
                        this.f317e.show();
                    }
                } else if (!this.f310X.m122s()) {
                    this.f317e.hide();
                    if (this.f338z) {
                        this.f316d.m916a(getString(R.string.dlg_title_credit));
                        this.f316d.m918b(getString(R.string.credit_out));
                    } else {
                        this.f316d.m916a(getString(R.string.dlg_title_counter));
                        this.f316d.m918b(getString(R.string.counter_out));
                    }
                    this.f316d.show();
                }
            }
        }
    }

    public void m385a(String str) {
        this.ad.setText(str);
    }

    public void m386b(cg cgVar) {
        C0104d.m830a("setView child count:" + this.f309W.getChildCount());
        if (this.f309W.getChildCount() > 0) {
            ((cg) this.f309W.getChildAt(0)).mo3a();
            this.f312Z = ((cg) this.f309W.getChildAt(0)).getResourceId();
        }
        this.f309W.removeAllViews();
        this.f311Y = cgVar;
        if (cgVar.getResourceId() == R.layout.activity_main) {
            this.aa.setVisibility(4);
        } else {
            this.aa.setVisibility(0);
        }
        this.f309W.addView(cgVar, new LayoutParams(-1, -1));
        m385a(this.f311Y.mo33h());
    }

    public void m387b(C0099y c0099y) {
        this.f310X.f59H = c0099y.f832w;
        this.f310X.f58G = c0099y.f833x;
        this.f310X.f60I = c0099y.f834y;
        this.f310X.f61J = c0099y.f835z;
        if (!this.f310X.f61J) {
            c0099y.f833x = 0;
        }
        m380a(this.f310X.f58G, this.f310X.f60I, this.f310X.f61J);
    }

    public void m388c(C0099y c0099y) {
        C0099y c0099y2 = new C0099y();
        switch (c0099y.m808w()) {
            case 113:
            case 129:
            case 133:
            case 138:
                m332b(25000);
                if (!this.f295I) {
                    this.f323k.m942b(getString(R.string.up_ready_wait));
                    this.f295I = true;
                    this.f296J = false;
                }
                m318a(0, 3, 25000, 1);
                break;
            case 114:
            case 130:
            case 134:
            case 139:
                if (!this.f296J) {
                    m336b(getString(R.string.up_process_wait));
                    this.f296J = true;
                    this.f295I = false;
                }
                m332b(5000);
                m328a(c0099y.m808w(), this.f289C.m206c(c0099y.m808w()), c0099y.f806V);
                break;
            case 115:
            case 131:
            case 135:
            case 140:
                C0104d.m830a(String.format("FW Upgrade End : 0x%02X,%d,", new Object[]{Integer.valueOf(c0099y.m808w()), Integer.valueOf(c0099y.m763A())}));
                this.f289C.m202b(c0099y.m808w());
                if (!this.f289C.m199a()) {
                    m317a(c0099y.m808w(), c0099y.m763A());
                    m366l();
                    break;
                }
                m330a(this.f289C.m201b());
                break;
            case 242:
                this.f318f.m918b(getString(R.string.up_fail) + "(" + 242 + ")");
                m368n();
                this.f318f.show();
                break;
        }
        m362j();
    }

    public void m389d(C0099y c0099y) {
        String str = "onMessageInit:MSG_ID[%02x],STATUS[%b,%d],ERR_CODE[%d],INIT_KIND[%d:%s]FW_VER:[%04X],FD_VER[%04X],XC_VER:[%04X],XC_STATUS[%d],DEVICE_ID[%s],AT88_STATUS[%d],XR_VER:[%04X],XR_STATUS[%d],HW_VER:[%04X]";
        Object[] objArr = new Object[15];
        objArr[0] = Integer.valueOf(c0099y.m808w());
        objArr[1] = Boolean.valueOf(c0099y.f791G);
        objArr[2] = Integer.valueOf(c0099y.f800P);
        objArr[3] = Integer.valueOf(c0099y.m763A());
        objArr[4] = Integer.valueOf(c0099y.f787C);
        objArr[5] = c0099y.f787C == 1 ? "BOOT" : "APP";
        objArr[6] = Integer.valueOf(c0099y.f788D & 65535);
        objArr[7] = Integer.valueOf(c0099y.f790F & 65535);
        objArr[8] = Integer.valueOf(c0099y.f793I & 65535);
        objArr[9] = Integer.valueOf(c0099y.f792H);
        objArr[10] = this.f310X.m133z(c0099y.f799O);
        objArr[11] = Integer.valueOf(c0099y.f796L);
        objArr[12] = Integer.valueOf(c0099y.f795K & 65535);
        objArr[13] = Integer.valueOf(c0099y.f794J);
        objArr[14] = Integer.valueOf(c0099y.f798N & 65535);
        C0104d.m830a(String.format(str, objArr));
        C0099y c0099y2 = new C0099y();
        if (c0099y.f787C == 1) {
            this.f325m.cancel();
            c0099y2.m781d(16);
            c0099y2.f789E = this.f310X.f93y;
            c0099y2.f801Q = 0;
            this.ag.m733a(c0099y2, false);
            this.f306T = true;
            C0108h.m853a(20);
            C0104d.m830a("_b_system_error=" + this.f302P);
            C0037m c0037m = new C0037m();
            C0038n g = c0037m.m214g();
            C0104d.m830a("UpgradeMsg:" + g.f215a);
            if (g.f215a == 3 || g.f215a == 1) {
                c0037m.m215h();
                this.f310X.ag = 24011;
                m367m();
                C0108h.m853a(50);
                m368n();
                m317a(115, this.f310X.ag);
                return;
            }
            if (g.f215a == 2) {
                c0037m.m211e("SW");
                c0037m.m216i();
                c0037m.m215h();
                m367m();
                C0108h.m853a(50);
                m368n();
                m364k();
                if (c0037m.m199a()) {
                    this.f323k.m938a(g.f217c);
                    this.f323k.m941b(g.f216b);
                    this.f323k.m942b(getString(R.string.up_data_trans_wait));
                    this.f323k.show();
                    this.f323k.m941b(0);
                    m355h();
                    m332b(5000);
                    this.f289C = c0037m;
                } else {
                    m317a(115, 1);
                }
            }
            c0037m.m210d();
            if (this.f289C.m199a()) {
                C0104d.m830a("**systemUpgrade**");
                m319a(this.f289C.m205c(), this.f289C.m201b());
            } else if (m348e(c0099y) || this.f302P) {
                this.f310X.m129w(m371q());
                this.f310X.m120r(m370p());
                this.f310X.m121s(m370p());
                this.f310X.m126u(m373s());
                this.f310X.m124t(m372r());
                this.f310X.m128v(m374t());
                if (c0099y.f799O == 0) {
                    this.f310X.f55D = String.valueOf(m375u());
                }
                C0104d.m830a("Error:" + this.f305S);
                C0104d.m830a("_b_system_error:" + this.f302P);
                if (this.f302P) {
                    this.f319g.m918b(getString(R.string.system_error_ma_upgrade));
                } else if (c0099y.f792H != 2) {
                    this.f319g.m918b(getString(R.string.system_error_stop_reboot) + "(" + 24995 + ")");
                } else if (c0099y.f794J != 2) {
                    this.f319g.m918b(getString(R.string.system_error_stop_reboot) + "(" + 24802 + ")");
                } else {
                    this.f319g.m918b(getString(R.string.system_error_ma_upgrade) + "(" + this.f305S + ")");
                }
                this.f310X.ag = this.f305S;
                m367m();
                C0108h.m853a(100);
                m368n();
                this.f319g.show();
            } else {
                m366l();
            }
        } else if (c0099y.f787C == 2) {
            int i;
            int i2;
            boolean z;
            boolean z2;
            boolean z3;
            boolean z4;
            this.f310X.ag = 1;
            if (this.f324l != null) {
                this.f324l.cancel();
            }
            this.f310X.m129w(c0099y.f798N);
            this.f310X.m120r(c0099y.f788D);
            this.f310X.m121s(c0099y.f790F);
            this.f310X.m126u(c0099y.f797M);
            this.f310X.m124t(c0099y.f793I);
            this.f310X.m128v(c0099y.f795K);
            this.f310X.f55D = String.valueOf(c0099y.f799O);
            m344d(c0099y.f788D);
            m347e(c0099y.f798N);
            if (c0099y.f792H == 1) {
                i = true;
                i2 = true;
                this.f310X.m124t(m372r());
            } else {
                z = true;
                z2 = true;
            }
            if (c0099y.f794J == 1) {
                i = true;
                i2 = true;
                this.f310X.m128v(m374t());
            }
            if (c0099y.f796L != 2) {
                if (c0099y.f796L == 0) {
                    i = R.string.system_error_stop_reboot;
                    i2 = 24996;
                } else if (c0099y.f799O != 0) {
                    i = R.string.system_error_stop_reboot;
                    i2 = 24997;
                }
            }
            if (c0099y.f793I == 260 || ((c0099y.f788D >= 512 && c0099y.f793I < 261) || (m376v() >= 200 && c0099y.f788D < 512))) {
                z3 = true;
                z4 = R.string.system_error_ma_upgrade;
            } else {
                z3 = true;
                z4 = true;
            }
            if (c0099y.f792H == 3 || c0099y.f799O == 0) {
                z3 = true;
                if (c0099y.f793I < 259 || c0099y.f793I == 65535) {
                    this.f310X.m124t(0);
                } else if (c0099y.f793I == 259) {
                    this.f310X.m124t(c0099y.f793I);
                } else {
                    this.f310X.m124t(260);
                }
                this.f310X.f55D = String.valueOf(m375u());
                z4 = R.string.system_error_ma_upgrade;
            }
            if (c0099y.f794J == 3) {
                z3 = true;
                this.f310X.m128v(0);
                z4 = R.string.system_error_ma_upgrade;
            }
            if (c0099y.f800P == 18 || c0099y.f800P == 17) {
                z3 = true;
                this.f310X.m121s(0);
                z4 = R.string.system_error_ma_upgrade;
            }
            if (i2 == 1) {
                z2 = z3;
                z = z4;
            }
            C0011b a = C0011b.m14a((Context) this);
            if (i2 == 1 && (a.m29g() || a.m27e())) {
                i2 = 24990;
                i = R.string.dlg_notice_device_lock;
            }
            if (i2 != 1) {
                m367m();
                C0108h.m853a(20);
                try {
                    this.f311Y.mo22e();
                } catch (Exception e) {
                }
                m333b(i, i2);
                return;
            }
            if (c0099y.f792H == 2) {
                m353g(c0099y.f793I);
            }
            if (c0099y.f794J == 2) {
                m356h(c0099y.f795K);
            }
            m351f(c0099y.f797M);
            C0104d.m830a("Package VersionCode:" + m376v());
            C0108h.m853a(20);
            DeviceIO.setGPIOStatus(1, true);
            C0104d.m830a("setGPIOStatus FB_PWR_IO2 ON");
            C0108h.m853a(30);
            byte[] d = C0108h.m869d(16);
            this.f310X.m65a(d);
            c0099y2.m781d(16);
            c0099y2.f789E = this.f310X.f93y;
            c0099y2.f801Q = 1;
            c0099y2.m786e(d);
            this.ag.m733a(c0099y2, false);
            try {
                this.f311Y.mo22e();
            } catch (Exception e2) {
            }
            if (this.f326n != null) {
                this.f326n.schedule(new cc(this), 1500);
            }
            m367m();
        }
    }

    public void onCreate(Bundle bundle) {
        C0104d.m830a("IProg Activity onCreate...");
        super.onCreate(bundle);
        setContentView(R.layout.activity_iprog);
        getWindow().addFlags(4718720);
        m363j(230);
        this.f310X = C0013d.m38b((Context) this);
        this.f310X.f75g = this;
        this.f310X.f76h = this.f333u;
        this.f310X.f77i = this.f335w;
        this.f310X.f78j = this.f288B;
        this.f336x = 0;
        this.f310X.m68a((Context) this);
        C0104d.m830a("IProg Activity Resource.getInstance.");
        try {
            this.f310X.m102i(getPackageManager().getPackageInfo(getPackageName(), 0).versionName);
        } catch (Exception e) {
            C0104d.m828a(e);
        }
        startActivity(new Intent(this, IntroActivity.class));
        this.f309W = (LinearLayout) findViewById(R.id.ll_reset_content);
        this.ab = (ImageButton) findViewById(R.id.btn_home);
        this.aa = (Button) findViewById(R.id.btn_back);
        this.ad = (TextView) findViewById(R.id.tv_current_pos);
        this.ac = (TextView) findViewById(R.id.tv_credit);
        this.f322j = (LinearLayout) findViewById(R.id.ll_credit_view);
        this.f327o = (ImageView) findViewById(R.id.img_bt);
        this.f315c = new ai(this);
        this.f315c.m916a(getString(R.string.dlg_title_exit));
        this.f315c.m918b(getString(R.string.dlg_body_exit));
        this.f315c.m917b(1);
        this.f317e = new al(this);
        this.f323k = new bk(this);
        this.f323k.m939a(getResources().getString(R.string.dlg_title_upgrade));
        this.f318f = new ai(this);
        this.f318f.m916a(getResources().getString(R.string.dlg_title_upgrade));
        this.f318f.m918b("");
        this.f318f.m917b(2);
        this.f319g = new ai(this);
        this.f319g.m916a(getString(R.string.dlg_title_application));
        this.f319g.m918b("");
        this.f319g.m917b(2);
        this.f316d = new ai(this);
        this.f316d.setTitle(R.string.dlg_title_credit);
        this.f316d.m918b("");
        this.f316d.m917b(2);
        this.f327o.setImageBitmap(null);
        C0107g.m839a().m841a((Context) this);
        this.aa.setOnClickListener(new bz(this));
        this.ab.setOnClickListener(new ca(this));
        this.f315c.m915a(new bj(this));
        this.f317e.m920a(new bk(this));
        this.f316d.m915a(new bl(this));
        this.f310X.m108k();
        this.f335w.sendEmptyMessageDelayed(3, 400);
        C0104d.m830a("Mac Address:" + C0108h.m872g("eth0"));
        Intent intent = new Intent(this, IProgAutorunService.class);
        intent.putExtra("START", true);
        startService(intent);
        this.ah = new IntentFilter("android.intent.action.SCREEN_ON");
        this.ai = new bm(this);
        registerReceiver(this.ai, this.ah);
        this.f329q = new cb();
        this.f329q.start();
    }

    protected Dialog onCreateDialog(int i) {
        return null;
    }

    protected void onDestroy() {
        C0104d.m830a("IProg onDestroy");
        m352g();
        this.f323k.hide();
        super.onDestroy();
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (this.f311Y == null) {
            return false;
        }
        if (keyEvent.getAction() == 1) {
            i = C0106f.m838a(i);
            if (!this.f311Y.mo7a(1, i)) {
                return false;
            }
            switch (i) {
                case 4:
                    this.f310X.m69a(this.f310X.f77i, 1);
                    return false;
                case 19:
                case 20:
                case 26:
                    return false;
            }
        }
        return super.onKeyUp(i, keyEvent);
    }

    protected void onStart() {
        C0104d.m830a("IProg onStart");
        super.onStart();
    }

    protected void onStop() {
        super.onStop();
    }
}
