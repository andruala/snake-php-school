package com.iprog.device;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import com.iprog.p000a.C0000a;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0036l;
import com.iprog.p003d.C0041q;
import com.iprog.p004f.ac;
import com.iprog.p005e.C0075a;
import com.iprog.p006g.C0103c;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0105e;
import com.iprog.p006g.C0108h;
import com.iprog.view.ai;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.message.BasicNameValuePair;

public class ab extends cg implements OnCheckedChangeListener {
    C0000a f353a = null;
    final int f354b = 0;
    final int f355c = 1;
    final int f356d = 2;
    Cursor f357e = null;
    Button f358f = null;
    Button f359g = null;
    TextView f360h = null;
    ai f361i = null;
    int f362j = 0;
    final int f363k = 1;
    final int f364l = -1;
    final int f365m = 5000;
    int f366n = 0;
    int f367o = 0;
    String f368p = "";
    ArrayList f369q = new ArrayList();
    private ListView f370r = null;

    public ab(Context context) {
        super(context);
        m404b();
    }

    private String getQuery() {
        String str = "";
        if (this.f368p.equals("Y")) {
            str = String.format("  AND send_yn='Y' \n", new Object[0]);
        } else if (this.f368p.equals("N")) {
            str = String.format("  AND ( send_yn='N' or send_yn='' or send_yn is null ) \n", new Object[0]);
        }
        return String.format(" SELECT reg_dt,mdl_name,nat_cd,color,yield,send_time        ,_id,file_name    FROM rp_chip_read   WHERE substr(reg_dt,1,7) = '%s' " + str + "  ORDER BY _id desc ", new Object[]{this.f360h.getText()});
    }

    private void m400i(int i) {
        this.f369q = new ArrayList();
        C0104d.m830a("Current total:" + this.f366n + ",current:" + this.f367o);
        try {
            this.f357e = getDatabase().m631a(getQuery());
            this.f366n = this.f357e.getCount();
            this.f367o = 0;
            C0104d.m830a("Start total:" + this.f366n + ",current:" + this.f367o);
            int i2 = 0;
            for (int i3 = this.f367o; i3 < this.f366n && i2 < 5000; i3++) {
                ArrayList arrayList = this.f369q;
                String str = "%d|%s|%s|%s|%s|%s|%s|%s|%s|%s";
                Object[] objArr = new Object[10];
                objArr[0] = Integer.valueOf(this.f366n - i3);
                objArr[1] = this.f357e.getString(0);
                objArr[2] = this.f357e.getString(1);
                objArr[3] = this.f357e.getString(2);
                objArr[4] = this.f357e.getString(3);
                objArr[5] = C0013d.m46n(this.f357e.getInt(4));
                objArr[6] = C0108h.m870e(this.f357e.getString(5));
                objArr[7] = C0108h.m868d(this.f357e.getString(5)) ? "Y" : "N";
                objArr[8] = this.f357e.getString(6);
                objArr[9] = this.f357e.getString(7);
                arrayList.add(String.format(str, objArr));
                this.f357e.moveToNext();
                this.f367o++;
                i2++;
            }
            this.f353a.m1a(this.f369q);
            this.f370r.setAdapter(this.f353a);
            C0075a.m626a(this.f357e);
        } catch (Exception e) {
            throw e;
        } catch (Throwable th) {
            C0075a.m626a(this.f357e);
        }
    }

    private void m401j() {
        C0108h.m853a(500);
        String[] split = ((String) this.f369q.get(this.f362j)).split("\\|");
        C0104d.m832a("ChipReadSend:", (String) this.f369q.get(this.f362j));
        String str = "";
        try {
            str = new String(C0108h.m871f(split[9]));
            List arrayList = new ArrayList();
            arrayList.add(new BasicNameValuePair("msg_id", String.valueOf(179)));
            arrayList.add(new BasicNameValuePair("company", "IPROG"));
            arrayList.add(new BasicNameValuePair("read_dt", split[1]));
            arrayList.add(new BasicNameValuePair("model", split[2]));
            arrayList.add(new BasicNameValuePair("nat_cd", split[3]));
            arrayList.add(new BasicNameValuePair("color", split[4]));
            arrayList.add(new BasicNameValuePair("yield", split[5]));
            arrayList.add(new BasicNameValuePair("cat_no", " "));
            arrayList.add(new BasicNameValuePair("data", str));
            arrayList.add(new BasicNameValuePair("dev_id_r", this.x.f55D));
            str = C0105e.m836a(this.x.m113n(), arrayList);
            C0104d.m832a("Send Log:", str);
            ac acVar = new ac();
            C0036l c0036l = new C0036l();
            Object obj;
            if (acVar.m712a(str, c0036l) && c0036l.f210b == 1) {
                getDatabase().m629a(C0108h.m844a(split[8]), "IPROG", "", split[4], " ", "Y");
                obj = 1;
                C0108h.m853a(500);
                super.mo9c();
                if (obj != 1) {
                    ((Activity) getApplication()).runOnUiThread(new ai(this));
                } else {
                    ((Activity) getApplication()).runOnUiThread(new ah(this));
                }
            }
            obj = null;
            C0108h.m853a(500);
            super.mo9c();
            if (obj != 1) {
                ((Activity) getApplication()).runOnUiThread(new ah(this));
            } else {
                ((Activity) getApplication()).runOnUiThread(new ai(this));
            }
        } catch (Exception e) {
            C0104d.m829a(e, "ChipRead Send");
            int i = 1;
        }
    }

    private void setMonthText(int i) {
        int i2 = 1;
        String replaceAll = (this.f360h.getText() + "-01-01010101").replaceAll("-", "");
        if (i != 1) {
            i2 = -1;
        }
        this.f360h.setText(new SimpleDateFormat("yyyy-MM").format(C0103c.m826a(i2, C0103c.m827b(replaceAll))));
    }

    public void mo3a() {
        C0075a.m626a(this.f357e);
    }

    public void mo5a(C0041q c0041q) {
        try {
            C0104d.m830a("onStart ChipreadListView:" + c0041q.m217a());
            if (c0041q.m217a() == 0) {
                m400i(0);
            }
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }

    public void m404b() {
        int[] iArr = new int[]{R.id.tv_num, R.id.tv_read_date, R.id.tv_model, R.id.tv_nat, R.id.tv_color, R.id.tv_yield, R.id.tv_send_date, R.id.tv_send_yn};
        m246c((int) R.layout.activity_chip_read_list, (int) R.string.str_pos_data_send_list);
        this.f370r = (ListView) findViewById(R.id.lv_data);
        this.f353a = new C0000a(getContext(), R.layout.chip_read_list_item);
        this.f353a.m2a(iArr);
        this.f358f = (Button) findViewById(R.id.btn_month_next);
        this.f359g = (Button) findViewById(R.id.btn_month_prev);
        this.f360h = (TextView) findViewById(R.id.tv_month);
        TextView[] textViewArr = new TextView[iArr.length];
        String[] stringArray = getContext().getResources().getStringArray(R.array.arry_chipread_list_title);
        int i = 0;
        while (i < iArr.length && i < stringArray.length) {
            textViewArr[i] = (TextView) findViewById(iArr[i]);
            textViewArr[i].setText(stringArray[i]);
            i++;
        }
        this.f360h.setText(C0103c.m823a().substring(0, 7));
        this.f361i = new ai(getContext());
        this.f361i.m916a(m248d(R.string.dlg_data_send_title));
        this.f361i.m917b(1);
        ((RadioButton) findViewById(R.id.rb_send_all)).setOnCheckedChangeListener(this);
        ((RadioButton) findViewById(R.id.rb_send_y)).setOnCheckedChangeListener(this);
        ((RadioButton) findViewById(R.id.rb_send_n)).setOnCheckedChangeListener(this);
        ((RadioButton) findViewById(R.id.rb_send_all)).setChecked(true);
        this.f358f.setOnClickListener(new ac(this));
        this.f359g.setOnClickListener(new ad(this));
        this.f353a.m0a(new ae(this));
        this.f361i.m915a(new af(this));
    }

    public Object mo13d() {
        return m243c((int) R.layout.activity_main);
    }

    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        if (z) {
            switch (compoundButton.getId()) {
                case R.id.rb_send_all:
                    this.f368p = "";
                    break;
                case R.id.rb_send_y:
                    this.f368p = "Y";
                    break;
                case R.id.rb_send_n:
                    this.f368p = "N";
                    break;
            }
            try {
                m400i(0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
