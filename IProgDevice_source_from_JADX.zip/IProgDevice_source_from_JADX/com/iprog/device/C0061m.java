package com.iprog.device;

import com.iprog.view.bu;

class C0061m implements bu {
    final /* synthetic */ C0047d f644a;

    C0061m(C0047d c0047d) {
        this.f644a = c0047d;
    }

    public void mo21a(int i, int i2) {
    }
}
