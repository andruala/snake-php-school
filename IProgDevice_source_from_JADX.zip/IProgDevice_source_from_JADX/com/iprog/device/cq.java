package com.iprog.device;

import com.iprog.p004f.C0099y;
import com.iprog.view.ba;

class cq implements ba {
    final /* synthetic */ cm f520a;

    cq(cm cmVar) {
        this.f520a = cmVar;
    }

    public void mo26a(C0099y c0099y) {
        this.f520a.f506i.m926a();
        this.f520a.f512o = false;
        this.f520a.m487a(c0099y);
    }
}
