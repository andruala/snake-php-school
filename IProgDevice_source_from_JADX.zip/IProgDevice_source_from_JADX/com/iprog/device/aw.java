package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;
import java.util.Calendar;

class aw implements OnClickListener {
    final /* synthetic */ as f422a;

    aw(as asVar) {
        this.f422a = asVar;
    }

    public void onClick(View view) {
        Calendar instance = Calendar.getInstance();
        this.f422a.f412e = instance.get(1);
        this.f422a.f413f = instance.get(2);
        this.f422a.f414g = instance.get(5);
        this.f422a.f415h = instance.get(11);
        this.f422a.f416i = instance.get(12);
        this.f422a.f411d.updateTime(this.f422a.f415h, this.f422a.f416i);
        this.f422a.f411d.show();
    }
}
