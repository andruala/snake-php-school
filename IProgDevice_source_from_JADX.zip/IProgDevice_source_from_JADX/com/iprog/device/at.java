package com.iprog.device;

import android.app.DatePickerDialog.OnDateSetListener;
import android.widget.DatePicker;
import com.iprog.p006g.C0104d;

class at implements OnDateSetListener {
    final /* synthetic */ as f419a;

    at(as asVar) {
        this.f419a = asVar;
    }

    public void onDateSet(DatePicker datePicker, int i, int i2, int i3) {
        C0104d.m830a(new StringBuilder(String.valueOf(i)).append("년 ").append(i2 + 1).append("월 ").append(i3).append("일").toString());
        this.f419a.m449a(i, i2, i3);
    }
}
