package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class ca implements OnClickListener {
    final /* synthetic */ IProgActivity f476a;

    ca(IProgActivity iProgActivity) {
        this.f476a = iProgActivity;
    }

    public void onClick(View view) {
        this.f476a.m378a();
    }
}
