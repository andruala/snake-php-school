package com.iprog.device;

import android.content.Context;
import android.database.Cursor;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.iprog.p000a.C0009j;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0041q;
import com.iprog.p005e.C0075a;
import com.iprog.p006g.C0103c;
import com.iprog.p006g.C0104d;
import com.iprog.view.C0116j;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class C0051do extends cg {
    C0009j f612a = null;
    final int f613b = 0;
    final int f614c = 1;
    final int f615d = 2;
    Cursor f616e = null;
    Button f617f = null;
    Button f618g = null;
    Button f619h = null;
    Button f620i = null;
    TextView f621j = null;
    int f622k = 0;
    String[] f623l = null;
    final int f624m = 1;
    final int f625n = -1;
    final int f626o = 1000;
    int f627p = 0;
    int f628q = 0;
    private ListView f629r = null;
    private C0116j f630s = null;
    private C0116j f631t = null;

    public C0051do(Context context) {
        super(context);
        m600b();
    }

    private String getQuery() {
        String str = "";
        if (!this.f630s.m977c().equals("0")) {
            str = "AND job_type='" + this.f630s.m977c() + "'";
        }
        if (this.f622k == 1) {
            return String.format("SELECT reg_dt, job_type,mdl_name,color,nat_cd, yield,count(*) as cnt  FROM rp_work_his  WHERE substr(reg_dt,1,7) = '%s'    %s  GROUP BY reg_dt, job_type,mdl_name,color,nat_cd, yield  ORDER BY reg_dt desc, cnt desc", new Object[]{this.f621j.getText(), str});
        } else if (this.f622k == 2) {
            return String.format("SELECT substr(reg_dt,1,7), job_type,mdl_name,color,nat_cd, yield,count(*) as cnt  FROM rp_work_his  WHERE substr(reg_dt,1,7) = '%s'    %s  GROUP BY substr(reg_dt,1,7), job_type,mdl_name,color,nat_cd, yield  ORDER BY reg_dt desc, cnt desc", new Object[]{this.f621j.getText(), str});
        } else {
            return String.format("SELECT reg_dt, job_type,mdl_name,color,nat_cd, yield,1  FROM rp_work_his  WHERE substr(reg_dt,1,7) = '%s'    %s  ORDER BY reg_dt desc,_id desc", new Object[]{this.f621j.getText(), str});
        }
    }

    private String m596i(int i) {
        try {
            return this.f630s.m978c(i);
        } catch (Exception e) {
            return " ";
        }
    }

    private void m597j(int i) {
        ArrayList arrayList = new ArrayList();
        C0104d.m830a("Current total:" + this.f627p + ",current:" + this.f628q);
        if (i != 1 && i != 2) {
            if (this.f616e != null) {
                C0075a.m626a(this.f616e);
            }
            this.f616e = getDatabase().m631a(getQuery());
            this.f627p = this.f616e.getCount();
            this.f628q = 0;
            C0104d.m830a("Start total:" + this.f627p + ",current:" + this.f628q);
            int i2 = 0;
            for (int i3 = this.f628q; i3 < this.f627p && i2 < 1000; i3++) {
                arrayList.add(String.format("%d|%s|%s|%s|%s|%s|%s|%s ", new Object[]{Integer.valueOf(this.f627p - i3), this.f616e.getString(0), m596i(this.f616e.getInt(1)), this.f616e.getString(2), this.f616e.getString(3), this.f616e.getString(4), C0013d.m44g(this.f616e.getString(5)), this.f616e.getString(6)}));
                this.f616e.moveToNext();
                this.f628q++;
                i2++;
            }
            this.f612a.m11a(arrayList);
            this.f629r.setAdapter(this.f612a);
            C0075a.m626a(this.f616e);
        }
    }

    private void setMonthText(int i) {
        int i2 = 1;
        String replaceAll = (this.f621j.getText() + "-01-01010101").replaceAll("-", "");
        if (i != 1) {
            i2 = -1;
        }
        Date a = C0103c.m826a(i2, C0103c.m827b(replaceAll));
        this.f621j.setText(new SimpleDateFormat("yyyy-MM").format(a));
    }

    public void mo3a() {
        C0075a.m626a(this.f616e);
    }

    public void mo5a(C0041q c0041q) {
        try {
            this.f631t.m974b(0);
            this.f622k = 0;
            C0104d.m830a("onStart WorkHistoryView1:" + c0041q.m217a());
            if (c0041q.m217a() == 0) {
                m597j(0);
            }
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }

    public void m600b() {
        int[] iArr = new int[]{R.id.tv_wk_title_num, R.id.tv_wk_title_date, R.id.tv_wk_job_type, R.id.tv_wk_title_model, R.id.tv_wk_title_color, R.id.tv_wk_title_nat, R.id.tv_wk_title_yield, R.id.tv_wk_title_hap};
        int[] iArr2 = new int[5];
        iArr2[1] = 1;
        iArr2[2] = 3;
        iArr2[3] = 4;
        iArr2[4] = 5;
        m246c((int) R.layout.activity_work_history1, (int) R.string.str_pos_work_history);
        this.f629r = (ListView) findViewById(R.id.lv_data);
        this.f612a = new C0009j(getContext(), R.layout.work_history_tiem1);
        this.f612a.m12a(iArr);
        this.f623l = m252e(R.array.array_wklist_combobox);
        this.f630s = new C0116j(getContext(), (Button) findViewById(R.id.sp_work_type), R.layout.dlg_model_select);
        this.f630s.m960a((int) R.string.str_cb_title_jobtype);
        this.f630s.m969a(this.f623l, iArr2);
        this.f630s.m974b(0);
        this.f631t = new C0116j(getContext(), (Button) findViewById(R.id.sp_sum_type), R.layout.dlg_popup_list);
        this.f631t.m960a((int) R.string.str_cb_title_sumtype);
        this.f631t.m968a(getContext().getResources().getStringArray(R.array.array_tab_work_list));
        this.f631t.m974b(0);
        this.f619h = (Button) findViewById(R.id.btn_month_next);
        this.f620i = (Button) findViewById(R.id.btn_month_prev);
        this.f621j = (TextView) findViewById(R.id.tv_month);
        TextView[] textViewArr = new TextView[iArr.length];
        String[] stringArray = getContext().getResources().getStringArray(R.array.arry_wklist_title1);
        int i = 0;
        while (i < iArr.length && i < stringArray.length) {
            textViewArr[i] = (TextView) findViewById(iArr[i]);
            textViewArr[i].setText(stringArray[i]);
            i++;
        }
        this.f621j.setText(C0103c.m823a().substring(0, 7));
        this.f631t.m961a(new dp(this));
        this.f630s.m961a(new dq(this));
        this.f619h.setOnClickListener(new dr(this));
        this.f620i.setOnClickListener(new ds(this));
    }

    public Object mo13d() {
        return m243c((int) R.layout.activity_main);
    }

    public String mo33h() {
        return getContext().getString(R.string.str_pos_work_history);
    }
}
