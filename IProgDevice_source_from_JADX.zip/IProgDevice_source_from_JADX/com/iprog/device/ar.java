package com.iprog.device;

import com.iprog.p003d.C0036l;
import com.iprog.p006g.C0104d;

class ar implements Runnable {
    final /* synthetic */ aj f404a;
    private final /* synthetic */ int f405b;
    private final /* synthetic */ String f406c;
    private final /* synthetic */ int f407d;

    ar(aj ajVar, int i, String str, int i2) {
        this.f404a = ajVar;
        this.f405b = i;
        this.f406c = str;
        this.f407d = i2;
    }

    public void run() {
        try {
            C0104d.m830a(String.format("sendServer[%d],DATA[%s]:", new Object[]{Integer.valueOf(this.f405b), this.f406c}));
            C0036l a = this.f404a.m417b(this.f405b, this.f406c);
            C0104d.m830a(String.format("sendFWID[%d],DATA[%s]:", new Object[]{Integer.valueOf(this.f407d), a.f212d}));
            if (a.f210b == 1) {
                if (98 == this.f405b) {
                    this.f404a.m427k();
                } else {
                    this.f404a.m422c(this.f407d, a.f212d);
                }
            } else if (a.f210b == -1) {
                this.f404a.m424j(R.string.e_credit_send_error);
            } else {
                this.f404a.m423i(a.f210b);
            }
        } catch (Exception e) {
            C0104d.m829a(e, "sendProcess");
            this.f404a.m423i(-1);
        }
    }
}
