package com.iprog.device;

import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;
import com.iprog.view.br;

class cn implements br {
    final /* synthetic */ cm f517a;

    cn(cm cmVar) {
        this.f517a = cmVar;
    }

    public void mo24a(int i, int i2) {
        C0104d.m830a("MenuOnClickListener:" + i);
        C0041q c0041q = new C0041q();
        c0041q.m220a("menu", Integer.valueOf(i));
        switch (i) {
            case R.id.menu_reset:
                this.f517a.f498a.f87s = this.f517a.f498a.m99h(this.f517a.f498a.f58G);
                this.f517a.f498a.f88t = 1;
                this.f517a.m227a((int) R.layout.activity_search_recent, c0041q);
                return;
            case R.id.menu_etc:
                this.f517a.f501d.show();
                return;
            case R.id.menu_env:
                this.f517a.m227a((int) R.layout.activity_setting, c0041q);
                return;
            default:
                return;
        }
    }
}
