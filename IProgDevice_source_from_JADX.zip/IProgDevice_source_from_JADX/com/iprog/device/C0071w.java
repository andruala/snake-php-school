package com.iprog.device;

import com.iprog.p006g.C0104d;
import com.iprog.view.C0050m;

class C0071w implements C0050m {
    final /* synthetic */ ChipInfoView f657a;

    C0071w(ChipInfoView chipInfoView) {
        this.f657a = chipInfoView;
    }

    public void mo31a(int i, String str) {
        this.f657a.m290n();
        C0104d.m830a("view _cb_yield_ctrl onclick:" + str);
    }
}
