package com.iprog.device;

import android.os.Handler;
import android.os.Message;
import com.iprog.p004f.C0099y;
import com.iprog.p004f.ac;
import com.iprog.p006g.C0104d;

class bw extends Handler {
    final /* synthetic */ IProgActivity f471a;

    bw(IProgActivity iProgActivity) {
        this.f471a = iProgActivity;
    }

    public void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                return;
            case 3:
                C0099y c0099y = (C0099y) message.obj;
                switch (c0099y.m808w()) {
                    case 16:
                        this.f471a.m389d(c0099y);
                        return;
                    case 26:
                        int i;
                        byte[] bArr = new byte[2];
                        ac acVar = new ac(c0099y.m808w(), 0);
                        if (c0099y.m763A() == 0) {
                            if (c0099y.m808w() == 26) {
                                this.f471a.f310X.f55D = String.valueOf(c0099y.f799O);
                                this.f471a.m359i(c0099y.f799O);
                            }
                            i = 1;
                        } else {
                            i = c0099y.m763A();
                        }
                        this.f471a.f320h.mo35a(acVar.m716a(bArr, bArr.length, i));
                        return;
                    case 97:
                    case 98:
                    case 99:
                    case 100:
                    case 101:
                    case 225:
                    case 226:
                        if (this.f471a.f310X.m122s()) {
                            this.f471a.f311Y.mo8b(c0099y);
                            return;
                        }
                        ac acVar2 = new ac(c0099y.m808w(), 0);
                        C0104d.m830a(" SEND Device ==> Manager:" + c0099y.m808w() + "," + c0099y.m811z().length);
                        if (this.f471a.f310X.m127v() == 2) {
                            this.f471a.f321i.mo35a(acVar2.m716a(c0099y.m811z(), c0099y.m811z().length, 1));
                            return;
                        } else {
                            this.f471a.f320h.mo35a(acVar2.m716a(c0099y.m811z(), c0099y.m811z().length, 1));
                            return;
                        }
                    case 113:
                    case 114:
                    case 115:
                    case 129:
                    case 130:
                    case 131:
                    case 133:
                    case 134:
                    case 135:
                    case 138:
                    case 139:
                    case 140:
                    case 242:
                        this.f471a.m388c(c0099y);
                        return;
                    case 194:
                        this.f471a.m384a(c0099y);
                        return;
                    default:
                        this.f471a.f311Y.mo8b(c0099y);
                        return;
                }
            case 4:
                switch (((ac) message.obj).m698b().f754b) {
                    case 186:
                    case 187:
                    case 188:
                    case 189:
                        this.f471a.m383a((ac) message.obj);
                        return;
                    default:
                        return;
                }
            case 5:
                C0104d.m830a("Message Recv:PACKET_FB_SOCKET");
                return;
            default:
                C0104d.m830a("Message Recv:");
                return;
        }
    }
}
