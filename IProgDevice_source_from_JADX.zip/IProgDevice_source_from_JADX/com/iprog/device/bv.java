package com.iprog.device;

class bv implements Runnable {
    final /* synthetic */ bu f470a;

    bv(bu buVar) {
        this.f470a = buVar;
    }

    public void run() {
        this.f470a.f469a.m343d();
    }
}
