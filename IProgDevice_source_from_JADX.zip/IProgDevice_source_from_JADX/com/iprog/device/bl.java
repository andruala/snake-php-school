package com.iprog.device;

import com.iprog.view.ak;

class bl implements ak {
    final /* synthetic */ IProgActivity f458a;

    bl(IProgActivity iProgActivity) {
        this.f458a = iProgActivity;
    }

    public void mo15a(int i) {
        this.f458a.m378a();
    }
}
