package com.iprog.device;

import com.iprog.p003d.C0025a;
import com.iprog.view.C0050m;

class C0068t implements C0050m {
    final /* synthetic */ ChipInfoView f654a;

    C0068t(ChipInfoView chipInfoView) {
        this.f654a = chipInfoView;
    }

    public void mo31a(int i, String str) {
        boolean c = this.f654a.f266b.m158c();
        this.f654a.f266b = (C0025a) this.f654a.f269e.get(i);
        this.f654a.m290n();
        this.f654a.m311a(this.f654a.f266b, c);
        this.f654a.m261A();
        this.f654a.m294r();
    }
}
