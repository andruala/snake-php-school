package com.iprog.device;

import com.iprog.p004f.C0044n;
import com.iprog.p004f.ac;

class bi implements C0044n {
    final /* synthetic */ IProgActivity f455a;

    bi(IProgActivity iProgActivity) {
        this.f455a = iProgActivity;
    }

    public boolean mo18a(ac acVar) {
        return false;
    }
}
