package com.iprog.device;

import com.iprog.p006g.C0104d;
import com.iprog.view.C0050m;
import java.util.Locale;

class dm implements C0050m {
    final /* synthetic */ dk f610a;

    dm(dk dkVar) {
        this.f610a = dkVar;
    }

    public void mo31a(int i, String str) {
        String d = this.f610a.f600b.m980d(i);
        String locale = Locale.getDefault().toString();
        C0104d.m830a("view _dlg_lang current locale:" + locale);
        C0104d.m830a("view _dlg_lang new locale:" + d);
        if (locale.indexOf(d) < 0) {
            Locale locale2 = new Locale(this.f610a.f600b.m980d(i));
            if (d.indexOf("zh") >= 0) {
                dk.m582a(Locale.CHINA);
            } else {
                dk.m582a(locale2);
            }
        }
    }
}
