package com.iprog.device;

class ah implements Runnable {
    final /* synthetic */ ab f376a;

    ah(ab abVar) {
        this.f376a = abVar;
    }

    public void run() {
        try {
            this.f376a.m400i(0);
        } catch (Exception e) {
        }
        this.f376a.m249d(R.string.dlg_data_send_title, R.string.dlg_data_send_ok);
    }
}
