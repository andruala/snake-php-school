package com.iprog.device;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.iprog.p003d.C0035k;
import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;

class dg implements OnItemClickListener {
    final /* synthetic */ df f595a;

    dg(df dfVar) {
        this.f595a = dfVar;
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        C0104d.m830a("RecentView Selected:");
        C0035k c0035k = (C0035k) this.f595a.f592e.getAdapter().getItem(i);
        C0041q c0041q = new C0041q();
        c0041q.m220a("chip_data", c0035k);
        this.f595a.m228a((int) R.layout.activity_chip_info, c0041q, this.f595a.getWorkType());
    }
}
