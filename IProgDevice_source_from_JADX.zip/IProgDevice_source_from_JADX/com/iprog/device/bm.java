package com.iprog.device;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

class bm extends BroadcastReceiver {
    final /* synthetic */ IProgActivity f459a;

    bm(IProgActivity iProgActivity) {
        this.f459a = iProgActivity;
    }

    public void onReceive(Context context, Intent intent) {
        this.f459a.f335w.sendEmptyMessageDelayed(6, 50);
    }
}
