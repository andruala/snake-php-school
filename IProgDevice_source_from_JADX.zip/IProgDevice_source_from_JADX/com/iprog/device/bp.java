package com.iprog.device;

import com.iprog.p004f.C0044n;
import com.iprog.p004f.ac;

class bp implements C0044n {
    final /* synthetic */ IProgActivity f462a;

    bp(IProgActivity iProgActivity) {
        this.f462a = iProgActivity;
    }

    public boolean mo18a(ac acVar) {
        this.f462a.m383a(acVar);
        return false;
    }
}
