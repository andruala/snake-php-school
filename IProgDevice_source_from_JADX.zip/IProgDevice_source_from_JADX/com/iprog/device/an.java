package com.iprog.device;

import android.os.Handler;
import android.os.Message;
import com.iprog.p003d.C0029e;
import com.iprog.p006g.C0104d;

class an extends Handler {
    final /* synthetic */ aj f399a;

    an(aj ajVar) {
        this.f399a = ajVar;
    }

    public void handleMessage(Message message) {
        C0104d.m830a("credit _handler:" + message.what);
        switch (message.what) {
            case 1:
                this.f399a.mo9c();
                this.f399a.f394q = (C0029e) message.obj;
                this.f399a.f383f.m905a(String.valueOf(this.f399a.f394q.f164b), this.f399a.f394q.f165c, this.f399a.f394q.f166d);
                this.f399a.f383f.show();
                return;
            case 2:
                this.f399a.mo9c();
                return;
            case 9:
                this.f399a.mo9c();
                ((Integer) message.obj).intValue();
                return;
            default:
                return;
        }
    }
}
