package com.iprog.device;

import com.iprog.view.C0050m;

class C0060l implements C0050m {
    final /* synthetic */ C0047d f643a;

    C0060l(C0047d c0047d) {
        this.f643a = c0047d;
    }

    public void mo31a(int i, String str) {
        this.f643a.m542o();
    }
}
