package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

class ao implements OnClickListener {
    final /* synthetic */ aj f400a;

    ao(aj ajVar) {
        this.f400a = ajVar;
    }

    public void onClick(View view) {
        if (!this.f400a.x.f61J) {
            this.f400a.m249d(R.string.dlt_title_credit_err, R.string.e_credit_connect);
        } else if (this.f400a.x.m66a()) {
            for (EditText length : this.f400a.f378a) {
                if (length.length() != 4) {
                    this.f400a.m249d(R.string.dlt_title_credit_err, R.string.e_credit_input_err);
                    return;
                }
            }
            if (this.f400a.f379b[0].getText().toString().equals(this.f400a.f379b[1].getText().toString())) {
                String str = "%s%s%s^%s^%s^%s";
                Object[] objArr = new Object[6];
                objArr[0] = this.f400a.f378a[0].getText();
                objArr[1] = this.f400a.f378a[1].getText();
                objArr[2] = this.f400a.f378a[2].getText();
                objArr[3] = this.f400a.f379b[0].getText();
                objArr[4] = this.f400a.x.m117q();
                objArr[5] = Integer.valueOf(this.f400a.x.m110l() ? this.f400a.x.f58G + 110 : this.f400a.x.f58G);
                String format = String.format(str, objArr);
                this.f400a.f386i = format;
                this.f400a.f385h.m64a(true);
                this.f400a.mo4a(0, this.f400a.m248d(R.string.setting_nm_credit), this.f400a.m248d(R.string.dlg_credit_confirm), false);
                new Thread(new ap(this, format)).start();
                return;
            }
            this.f400a.m249d(R.string.dlt_title_pwd_err, R.string.e_pwd_mismatch);
        } else {
            this.f400a.m249d(R.string.dlt_title_credit_err, R.string.e_credit_add_type);
        }
    }
}
