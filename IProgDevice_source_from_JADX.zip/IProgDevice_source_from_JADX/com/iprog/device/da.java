package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class da implements OnClickListener {
    final /* synthetic */ cw f576a;

    da(cw cwVar) {
        this.f576a = cwVar;
    }

    public void onClick(View view) {
        this.f576a.m514i(-10);
    }
}
