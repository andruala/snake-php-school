package com.iprog.device;

import com.iprog.p006g.C0104d;
import com.iprog.view.bf;

class dn implements bf {
    final /* synthetic */ dk f611a;

    dn(dk dkVar) {
        this.f611a = dkVar;
    }

    public void mo32a(int i) {
        C0104d.m831a("sound action", i);
    }
}
