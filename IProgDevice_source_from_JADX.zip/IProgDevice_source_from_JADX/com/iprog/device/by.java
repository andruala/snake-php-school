package com.iprog.device;

import android.os.Handler;
import android.os.Message;

class by extends Handler {
    final /* synthetic */ IProgActivity f473a;

    by(IProgActivity iProgActivity) {
        this.f473a = iProgActivity;
    }

    public void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                this.f473a.m317a(115, ((Integer) message.obj).intValue());
                return;
            default:
                return;
        }
    }
}
