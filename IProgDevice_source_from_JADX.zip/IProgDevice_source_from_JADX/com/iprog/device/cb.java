package com.iprog.device;

import com.iprog.p001b.C0013d;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0105e;
import java.util.List;

class cb extends Thread {
    boolean f477a;
    boolean f478b;
    final /* synthetic */ IProgActivity f479c;

    private cb(IProgActivity iProgActivity) {
        this.f479c = iProgActivity;
        this.f477a = false;
        this.f478b = false;
    }

    public void m479a() {
        int i = 0;
        this.f477a = true;
        interrupt();
        while (this.f478b) {
            try {
                sleep(100);
                int i2 = i + 1;
                C0104d.m831a("AutoChipDataUploadThread Exit count", i);
                i = i2;
            } catch (Exception e) {
                C0104d.m829a(e, "AutoChipDataUploadThread Exit");
                return;
            }
        }
    }

    public void run() {
        C0104d.m830a("AutoChipDataUploadThread Start:" + getId());
        this.f478b = true;
        while (!this.f477a) {
            try {
                sleep(60000);
                if (C0105e.m837a(C0013d.m42d().m111m())) {
                    List j = this.f479c.m377w();
                    C0104d.m830a("SendData Size:" + j.size());
                    if (j.size() > 0) {
                        sleep(30000);
                        for (int i = 0; i < j.size(); i++) {
                            this.f479c.m338c((String) j.get(i));
                            sleep(200);
                        }
                    }
                }
                sleep(300000);
            } catch (InterruptedException e) {
                this.f477a = true;
            } catch (Exception e2) {
                C0104d.m829a(e2, "AutoChipDataUploadThread");
            }
        }
        this.f478b = false;
        C0104d.m830a("AutoChipDataUploadThread End:" + getId());
    }
}
