package com.iprog.device;

import com.iprog.view.ak;

class bj implements ak {
    final /* synthetic */ IProgActivity f456a;

    bj(IProgActivity iProgActivity) {
        this.f456a = iProgActivity;
    }

    public void mo15a(int i) {
    }
}
