package com.iprog.device;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0030f;
import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import com.iprog.view.TabView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class cw extends cg {
    public ArrayList f524a = null;
    final int f525b = 0;
    final int f526c = -10;
    ArrayList f527d = new ArrayList();
    ArrayList f528e = new ArrayList();
    ArrayList f529f = new ArrayList();
    private TabView f530g = null;
    private ListView f531h = null;
    private Button f532i = null;
    private Button f533j = null;
    private int f534k = 0;

    public cw(Context context) {
        super(context);
        m516b();
    }

    private void m514i(int i) {
        int lastVisiblePosition = this.f531h.getLastVisiblePosition();
        C0104d.m831a("list pos", lastVisiblePosition);
        this.f531h.setSelectionFromTop(Math.max(lastVisiblePosition + i, 0), 0);
    }

    public void mo5a(C0041q c0041q) {
        try {
            this.f534k = c0041q.m221b("pos");
        } catch (Exception e) {
            this.f534k = 0;
        }
        this.f530g.setTabIndex(2);
        C0104d.m830a("OnStart SearchCpView:" + this.f534k);
        this.f524a = this.x.m101i(getWorkType());
        if (this.f534k == 0) {
            Collections.sort(this.f524a);
            this.f531h.setAdapter(new ArrayAdapter(getContext(), R.layout.view_search_item, this.f524a));
        } else if (this.f534k == 1) {
            this.f529f.clear();
            for (r1 = 0; r1 < this.f527d.size(); r1++) {
                if (!C0108h.m858a(this.f529f, ((C0030f) this.f527d.get(r1)).f170d)) {
                    this.f529f.add(((C0030f) this.f527d.get(r1)).f170d);
                }
            }
            Collections.sort(this.f529f);
            this.f531h.setAdapter(new ArrayAdapter(getContext(), R.layout.view_search_item, this.f529f));
        } else if (this.f534k == 2) {
            List arrayList = new ArrayList();
            for (r1 = 0; r1 < this.f528e.size(); r1++) {
                arrayList.add(((C0030f) this.f528e.get(r1)).f171e);
            }
            this.f531h.setAdapter(new ArrayAdapter(getContext(), R.layout.view_search_item, arrayList));
        }
    }

    public void m516b() {
        setView(R.layout.activity_search_cp);
        this.f530g = (TabView) findViewById(R.id.tab_view);
        this.x = C0013d.m42d();
        this.f531h = (ListView) findViewById(R.id.lv_data);
        this.f532i = (Button) findViewById(R.id.btn_prev);
        this.f533j = (Button) findViewById(R.id.btn_next);
        this.f530g.setOnClickListener(new cx(this));
        this.f530g.setTitle(new int[]{R.string.str_tab_search1, R.string.str_tab_search2, R.string.str_tab_search3});
        this.f531h.setOnItemClickListener(new cy(this));
        this.f533j.setOnClickListener(new cz(this));
        this.f532i.setOnClickListener(new da(this));
    }

    public Object mo13d() {
        if (this.f534k <= 0) {
            return m244c((int) R.layout.activity_main, null);
        }
        C0041q c0041q = new C0041q();
        int i = this.f534k - 1;
        this.f534k = i;
        c0041q.m220a("pos", Integer.valueOf(i));
        return m244c((int) R.layout.activity_search_cp, c0041q);
    }
}
