package com.iprog.device;

import android.content.Context;
import android.widget.TextView;
import com.iprog.p000a.C0007h;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0041q;
import com.iprog.p006g.C0104d;
import com.iprog.view.C0048b;
import com.iprog.view.CalcView;
import com.iprog.view.ChipSearchView;
import com.iprog.view.SearchTextView;
import com.iprog.view.TabView;

public class db extends cg {
    C0048b f577a = new dc(this);
    private CalcView f578b = null;
    private TextView f579c = null;
    private SearchTextView f580d = null;
    private ChipSearchView f581e = null;
    private C0007h f582f = null;
    private C0013d f583g = null;
    private TabView f584h = null;

    public db(Context context) {
        super(context);
        m567b();
    }

    public void mo5a(C0041q c0041q) {
        C0104d.m830a("onStart SearchModelView:" + c0041q.m217a());
        this.f584h.setTabIndex(1);
        if (c0041q.m217a() == 0) {
            m566a("");
            this.f580d.m894b();
        }
    }

    public void m566a(String str) {
        this.f582f.m9a(str.isEmpty() ? this.f583g.m105j(getWorkType()) : this.f583g.m58a(str, getWorkType()));
        this.f581e.setAdapter(this.f582f);
    }

    public void m567b() {
        setView(R.layout.activity_search_model);
        this.f578b = (CalcView) findViewById(R.id.s_calcview);
        this.f580d = (SearchTextView) findViewById(R.id.ly_search_text);
        this.f582f = new C0007h(getContext(), R.layout.view_chip_item);
        this.f581e = (ChipSearchView) findViewById(R.id.v_chip_search);
        this.f584h = (TabView) findViewById(R.id.tab_view);
        this.f584h.setTitle(new int[]{R.string.str_tab_search1, R.string.str_tab_search2, R.string.str_tab_search3});
        this.f583g = C0013d.m42d();
        this.f578b.setOnClickListener(this.f577a);
        this.f584h.setOnClickListener(new dd(this));
        this.f581e.setOnClickListener(new de(this));
    }

    public Object mo13d() {
        return m243c((int) R.layout.activity_main);
    }
}
