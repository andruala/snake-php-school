package com.iprog.device;

import com.iprog.p003d.C0035k;
import com.iprog.p003d.C0041q;
import com.iprog.view.C0049i;

class de implements C0049i {
    final /* synthetic */ db f587a;

    de(db dbVar) {
        this.f587a = dbVar;
    }

    public void mo30a(C0035k c0035k) {
        C0041q c0041q = new C0041q();
        c0041q.m220a("chip_data", c0035k);
        this.f587a.m228a((int) R.layout.activity_chip_info, c0041q, this.f587a.getWorkType());
    }
}
