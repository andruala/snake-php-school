package com.iprog.device;

import com.iprog.p006g.C0104d;
import com.iprog.view.C0050m;

class C0055h implements C0050m {
    final /* synthetic */ C0047d f639a;

    C0055h(C0047d c0047d) {
        this.f639a = c0047d;
    }

    public void mo31a(int i, String str) {
        C0104d.m830a("view _cb_nat_ctrl onclick:" + str);
        this.f639a.m542o();
        this.f639a.setColorList(str);
    }
}
