package com.iprog.device;

import com.iprog.p006g.C0104d;
import com.iprog.view.C0050m;

class C0056i implements C0050m {
    final /* synthetic */ C0047d f640a;

    C0056i(C0047d c0047d) {
        this.f640a = c0047d;
    }

    public void mo31a(int i, String str) {
        C0104d.m830a("view _cb_color_ctrl onclick:" + str);
        this.f640a.m542o();
        this.f640a.m527c(this.f640a.f569p.m973b(), str);
    }
}
