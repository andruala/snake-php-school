package com.iprog.device;

import android.view.View;
import android.view.View.OnClickListener;

class C0052e implements OnClickListener {
    final /* synthetic */ C0047d f636a;

    C0052e(C0047d c0047d) {
        this.f636a = c0047d;
    }

    public void onClick(View view) {
        this.f636a.m543p();
    }
}
