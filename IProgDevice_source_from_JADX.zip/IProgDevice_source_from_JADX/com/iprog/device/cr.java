package com.iprog.device;

import com.iprog.view.bu;

class cr implements bu {
    final /* synthetic */ cm f521a;

    cr(cm cmVar) {
        this.f521a = cmVar;
    }

    public void mo21a(int i, int i2) {
    }
}
