package com.iprog.device;

import android.content.Context;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0025a;
import com.iprog.p003d.C0032h;
import com.iprog.p003d.C0035k;
import com.iprog.p003d.C0041q;
import com.iprog.p004f.C0099y;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0107g;
import com.iprog.p006g.C0108h;
import com.iprog.view.C0116j;
import com.iprog.view.CheckBoxEx;
import com.iprog.view.bs;
import java.util.ArrayList;
import java.util.Collections;

public class C0047d extends cg {
    private TextView f538B = null;
    private TextView f539C = null;
    private TextView f540D = null;
    private TextView f541E = null;
    private TextView f542F = null;
    private TextView f543G = null;
    private TextView f544H = null;
    private TextView f545I = null;
    private TextView f546J = null;
    private TextView f547K = null;
    private TextView f548L = null;
    private boolean f549M = false;
    private Object f550N = new Object();
    private boolean f551O = false;
    private TextView f552P = null;
    private TextView f553Q = null;
    C0035k f554a = new C0035k();
    C0025a f555b = null;
    C0013d f556c = C0013d.m42d();
    ImageView f557d = null;
    ArrayList f558e = new ArrayList();
    ImageButton f559f = null;
    ImageButton f560g = null;
    bs f561h = null;
    C0062n f562i = null;
    boolean f563j = false;
    boolean f564k = false;
    C0107g f565l = C0107g.m839a();
    C0032h f566m = null;
    boolean f567n = false;
    private C0116j f568o = null;
    private C0116j f569p = null;
    private C0116j f570q = null;
    private C0116j f571r = null;
    private C0116j f572s = null;
    private CheckBoxEx f573t = null;
    private CheckBoxEx f574u = null;
    private CheckBoxEx f575v = null;

    public C0047d(Context context) {
        super(context);
        m561b();
    }

    private void m520a(TextView textView, String str, boolean z) {
        if (z) {
            textView.setTextAppearance(getContext(), R.style.style_chipcheck_value);
        } else {
            textView.setTextAppearance(getContext(), R.style.style_chipcheck_error);
        }
        textView.setText(str);
    }

    private void m523a(bs bsVar) {
        if (bsVar != null) {
            try {
                if (bsVar.isShowing()) {
                    bsVar.dismiss();
                }
            } catch (Exception e) {
            }
        }
    }

    private void m527c(String str, String str2) {
        if ((this.f555b.m159d() && str.equals("-")) || str2.equals("-")) {
            this.f571r.m970a(new String[]{"-"}, new String[]{String.valueOf(0)});
            this.f571r.m974b(0);
            return;
        }
        ArrayList a = this.f555b.m152a(str, str2);
        for (int i = 0; i < a.size(); i++) {
            C0104d.m832a("Yield", (String) a.get(i));
        }
        this.f571r.m965a(C0013d.m39b(a), a);
        this.f571r.m974b(0);
    }

    private int m528d(C0099y c0099y) {
        int i = 23106;
        C0025a a = this.f556c.m107k(c0099y.f812c).m169a(c0099y.f824o);
        ArrayList arrayList = new ArrayList();
        if (a == null) {
            m557a(m256g(23003), true);
            return 23102;
        }
        boolean z;
        if (this.f555b.f127a.equals(String.valueOf(c0099y.f812c))) {
            m520a(this.f544H, a.f132f, true);
            z = false;
        } else {
            C0104d.m830a("Model Error:" + this.f555b.f127a + "," + c0099y.f812c);
            m520a(this.f544H, a.f132f, false);
            z = true;
        }
        String f = this.f556c.m94f(c0099y.f815f);
        if (f.equals(this.f569p.m973b())) {
            m520a(this.f545I, f, true);
        } else {
            C0104d.m830a("Nat Error:" + f + "," + this.f569p.m973b());
            arrayList.add(f);
            m520a(this.f545I, f, false);
            z = true;
        }
        f = this.f556c.m96g(c0099y.f816g);
        if (f.equals(this.f570q.m973b())) {
            m520a(this.f546J, f, true);
        } else {
            C0104d.m830a("Color Error:" + f + "," + this.f570q.m973b());
            arrayList.add(f);
            m520a(this.f546J, f, false);
            z = true;
        }
        f = Integer.toString(c0099y.m809x());
        if (f.equals(this.f571r.m977c())) {
            m520a(this.f547K, C0013d.m44g(f), true);
        } else {
            C0104d.m830a("Yield Error:" + f + "," + this.f571r.m977c());
            arrayList.add(f);
            m520a(this.f547K, C0013d.m44g(f), false);
            z = true;
        }
        if (c0099y.f822m == 2) {
            m520a(this.f539C, m248d(R.string.str_new_chip), true);
            i = z;
        } else if (c0099y.f822m == 1) {
            m520a(this.f539C, m248d(R.string.str_used_chip), false);
        }
        setChipAttributes(c0099y);
        return i;
    }

    private boolean m531e(C0099y c0099y) {
        if (!(c0099y.f807W == 1 || c0099y.f807W == 2 || c0099y.f807W != 3)) {
            C0104d.m830a(c0099y.m764B());
            this.f563j = false;
            int a = m552a(c0099y);
            if (a == 0) {
                m557a(m256g(23004), false);
            } else {
                m557a(m256g(a), false);
            }
        }
        return true;
    }

    private boolean m533f(C0099y c0099y) {
        C0104d.m831a("receive process status", c0099y.f807W);
        if (c0099y.f807W != 1) {
            if (c0099y.f807W == 2) {
                if (c0099y.f818i) {
                    this.f564k = true;
                }
            } else if (c0099y.f807W == 3) {
                m551x();
                int d = m528d(c0099y);
                if (d == 0) {
                    m557a(m256g(23007), false);
                } else {
                    m557a(m256g(d), false);
                }
                this.f564k = false;
                mo9c();
            }
        }
        return true;
    }

    private String getProgressMessage() {
        return m248d(R.string.str_pbdlg_check);
    }

    private void m536i(int i) {
        getDatabase().m634a(i, getWorkType(), this.f555b.f127a, this.f555b.f132f, "", "", 0, 0);
    }

    private void m537j() {
        getDatabase().m635a(0, getWorkType(), this.f555b.f127a, this.f555b.f132f, this.f569p.m973b(), this.f570q.m973b(), C0108h.m844a(this.f571r.m977c()), 0, 1);
    }

    private C0099y m538k() {
        C0099y c0099y = new C0099y();
        c0099y.m785e(this.f555b.f143q);
        c0099y.m781d(this.f556c.m75b(getWorkType()));
        c0099y.m777c(this.f556c.m53a(getWorkType()));
        c0099y.m766a(this.f555b.f127a);
        c0099y.m788f(this.f556c.m54a(this.f569p.m973b()));
        c0099y.m792h(this.f556c.m76b(this.f570q.m973b()));
        c0099y.m790g(C0108h.m844a(this.f571r.m977c()));
        c0099y.m767a(this.f573t.isChecked());
        c0099y.m768a(this.f555b.f146t, this.f575v.isChecked());
        c0099y.m772b(false);
        c0099y.m778c(this.f574u.isChecked());
        return c0099y;
    }

    private void m539l() {
        if (this.f555b.f140n > 0) {
            this.f574u.setEnabled(true);
        } else {
            this.f574u.setEnabled(false);
        }
        if (this.f555b.f139m == 0) {
            this.f574u.setChecked(true);
        } else {
            this.f574u.setChecked(false);
        }
    }

    private boolean m540m() {
        if (!this.f573t.isChecked()) {
            return false;
        }
        C0104d.m833a("isAutoJob:", true);
        return true;
    }

    private void m541n() {
        if (m540m()) {
            setAutoJobProgress(true);
            if (this.f562i == null || !this.f562i.m615b()) {
                this.f562i = new C0062n();
                C0099y k = m538k();
                k.m781d(33);
                this.f562i.m614a(k);
                this.f562i.start();
                return;
            }
            C0104d.m830a("already running..");
        }
    }

    private void m542o() {
        setAutoJobProgress(false);
        if (this.f562i != null) {
            this.f562i.m613a();
        }
        this.f562i = null;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m543p() {
        /*
        r5 = this;
        r4 = 1;
        r3 = 0;
        r0 = r5.m260i();
        if (r0 == 0) goto L_0x0009;
    L_0x0008:
        return;
    L_0x0009:
        r0 = r5.f563j;
        if (r0 == 0) goto L_0x001a;
    L_0x000d:
        r0 = r5.f556c;
        r1 = 2131230915; // 0x7f0800c3 float:1.8077896E38 double:1.0529679785E-314;
        r1 = r5.m248d(r1);
        r0.m61a(r3, r1, r3);
        goto L_0x0008;
    L_0x001a:
        r0 = r5.f555b;
        r0 = r0.f127a;
        r0 = com.iprog.p006g.C0108h.m844a(r0);
        r0 = com.iprog.p001b.C0013d.m35C(r0);
        if (r0 == 0) goto L_0x0035;
    L_0x0028:
        r0 = r5.f556c;
        r1 = 2131230968; // 0x7f0800f8 float:1.8078004E38 double:1.0529680046E-314;
        r1 = r5.m248d(r1);
        r0.m61a(r3, r1, r3);
        goto L_0x0008;
    L_0x0035:
        r0 = r5.f555b;
        r0 = r0.m159d();
        if (r0 == 0) goto L_0x0060;
    L_0x003d:
        r0 = r5.f556c;
        r1 = r5.f569p;
        r1 = r1.m973b();
        r0 = r0.m54a(r1);
        r1 = r5.f556c;
        r2 = "-";
        r1 = r1.m54a(r2);
        if (r0 != r1) goto L_0x0060;
    L_0x0053:
        r0 = r5.f556c;
        r1 = 2131230969; // 0x7f0800f9 float:1.8078006E38 double:1.052968005E-314;
        r1 = r5.m248d(r1);
        r0.m61a(r3, r1, r3);
        goto L_0x0008;
    L_0x0060:
        r0 = r5.f555b;
        r0 = r0.m159d();
        if (r0 == 0) goto L_0x008c;
    L_0x0068:
        r0 = r5.f556c;
        r1 = r5.f570q;
        r1 = r1.m973b();
        r0 = r0.m76b(r1);
        r1 = r5.f556c;
        r2 = "-";
        r1 = r1.m76b(r2);
        if (r0 != r1) goto L_0x008c;
    L_0x007e:
        r0 = r5.f556c;
        r1 = 2131230970; // 0x7f0800fa float:1.8078008E38 double:1.0529680056E-314;
        r1 = r5.m248d(r1);
        r0.m61a(r3, r1, r3);
        goto L_0x0008;
    L_0x008c:
        r0 = r5.f555b;
        r0 = r0.m159d();
        if (r0 == 0) goto L_0x00ae;
    L_0x0094:
        r0 = r5.f571r;
        r0 = r0.m977c();
        r0 = com.iprog.p006g.C0108h.m844a(r0);
        if (r0 != 0) goto L_0x00ae;
    L_0x00a0:
        r0 = r5.f556c;
        r1 = 2131230971; // 0x7f0800fb float:1.807801E38 double:1.052968006E-314;
        r1 = r5.m248d(r1);
        r0.m61a(r3, r1, r3);
        goto L_0x0008;
    L_0x00ae:
        r1 = r5.f550N;
        monitor-enter(r1);
        r0 = r5.f549M;	 Catch:{ all -> 0x00c1 }
        if (r0 != 0) goto L_0x00b9;
    L_0x00b5:
        r0 = r5.f551O;	 Catch:{ all -> 0x00c1 }
        if (r0 == 0) goto L_0x00c4;
    L_0x00b9:
        r0 = "시작이 이미 실행중입니다.";
        com.iprog.p006g.C0104d.m830a(r0);	 Catch:{ all -> 0x00c1 }
        monitor-exit(r1);	 Catch:{ all -> 0x00c1 }
        goto L_0x0008;
    L_0x00c1:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x00c1 }
        throw r0;
    L_0x00c4:
        r0 = 1;
        r5.f549M = r0;	 Catch:{ all -> 0x00c1 }
        r0 = 1;
        r5.f551O = r0;	 Catch:{ all -> 0x00c1 }
        monitor-exit(r1);	 Catch:{ all -> 0x00c1 }
        r0 = r5.getTitleName();
        r1 = r5.getProgressMessage();
        r5.mo4a(r3, r0, r1, r4);
        r5.m542o();
        r0 = r5.m538k();
        r1 = "";
        r5.m557a(r1, r3);
        r5.m242c(r0);
        r0 = r5.getWorkType();
        r1 = 6;
        if (r0 != r1) goto L_0x0008;
    L_0x00ec:
        r5.m537j();
        r0 = r5.f554a;
        r0 = r0.f207b;
        r5.m536i(r0);
        goto L_0x0008;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.iprog.device.d.p():void");
    }

    private void m544q() {
        if (!m260i()) {
            synchronized (this.f550N) {
                if (this.f549M || this.f551O) {
                    C0104d.m830a("검색이 이미 실행중입니다.");
                    return;
                }
                this.f549M = true;
                this.f551O = true;
                mo4a(0, m248d(R.string.search_chip_title), m248d(R.string.str_pbdlg_search), true);
                m542o();
                C0099y c0099y = new C0099y();
                c0099y.m785e(this.f555b.f143q);
                c0099y.m781d(32);
                c0099y.m777c(this.f556c.m53a(getWorkType()));
                c0099y.m766a(this.f555b.f127a);
                c0099y.m778c(this.f574u.isChecked());
                m557a("", false);
                m242c(c0099y);
            }
        }
    }

    private void m545r() {
        this.f558e = this.f556c.m57a(this.f555b, this.f555b.m158c());
        Collections.sort(this.f558e, C0013d.f46Z);
        this.f568o.m963a(this.f556c.m59a(this.f558e));
        this.f568o.m972b(this.f555b.f132f);
        m551x();
        m549v();
        m546s();
    }

    private void m546s() {
        ArrayList b = this.f555b.m157b();
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < b.size(); i++) {
            arrayList.add(String.valueOf(this.f556c.m54a((String) b.get(i))));
        }
        this.f569p.m963a(b);
        this.f569p.m974b(0);
        setColorList((String) b.get(0));
    }

    private void setAutoJobProgress(boolean z) {
        if (!z) {
            this.f573t.m878b();
        } else if (m540m()) {
            this.f573t.m876a();
        }
    }

    private void setColorList(String str) {
        if (this.f555b.m159d() && str.equals("-")) {
            this.f570q.m962a("-");
            this.f570q.m974b(0);
            m527c(str, "-");
            return;
        }
        ArrayList a = this.f555b.m151a(str);
        this.f570q.m963a(a);
        this.f570q.m974b(0);
        m527c(str, (String) a.get(0));
    }

    private void m547t() {
        this.f568o.m962a(new StringBuilder(String.valueOf(this.f555b.f142p)).append(" Series").toString());
        this.f568o.m974b(0);
        this.f560g.setVisibility(0);
        this.f569p.m967a(false);
        this.f570q.m967a(false);
        this.f571r.m967a(false);
        this.f559f.setVisibility(4);
        this.f553Q.setText(m256g(23002));
    }

    private void m548u() {
        this.f569p.m967a(true);
        this.f570q.m967a(true);
        this.f571r.m967a(true);
        this.f559f.setVisibility(0);
        this.f560g.setVisibility(0);
        this.f553Q.setText(" ");
    }

    private void m549v() {
        if (this.f556c.m71a(this.f555b, getWorkType())) {
            this.f573t.setEnabled(true);
        } else {
            this.f573t.setEnabled(false);
        }
    }

    private void m550w() {
        if (this.f555b.f143q == 10) {
            this.f575v.setText((int) R.string.chipinfo_nonhp_cb);
            this.f552P.setText(R.string.chipinfo_hp_title);
        } else {
            this.f575v.setText((int) R.string.str_chipinfo_autoregion);
            this.f552P.setText(R.string.str_chipinfo_autoregion2);
        }
        this.f575v.setEnabled(false);
    }

    private void m551x() {
        this.f538B.setText(C0013d.m43d(this.f555b.f139m, this.f555b.f140n));
        this.f539C.setText(" ");
        this.f540D.setText(" ");
        this.f541E.setText(" ");
        this.f543G.setText(" ");
        this.f542F.setText(" ");
        this.f544H.setText(" ");
        this.f545I.setText(" ");
        this.f546J.setText(" ");
        this.f547K.setText(" ");
        this.f553Q.setText(" ");
        this.f548L.setText(" ");
        m539l();
    }

    public int m552a(C0099y c0099y) {
        C0025a c0025a = null;
        try {
            c0025a = this.f556c.m107k(c0099y.f812c).m169a(false);
        } catch (Exception e) {
        }
        if (c0025a == null) {
            return 23102;
        }
        this.f555b = c0025a;
        m560a(this.f555b);
        m548u();
        m545r();
        String f = this.f556c.m94f(c0099y.f815f);
        String g = this.f556c.m96g(c0099y.f816g);
        String num = Integer.toString(c0099y.m809x());
        if (this.f555b.m159d() && f.equals("-")) {
            this.f569p.m957a(c0099y.f815f, f);
        }
        if (this.f569p.m972b(f) < 0) {
            return 23103;
        }
        if (this.f555b.m159d() && f.equals("-")) {
            this.f570q.m962a(g);
            this.f570q.m974b(0);
        } else {
            setColorList(f);
            if (g.equals("-")) {
                this.f570q.m957a(c0099y.f816g, g);
            }
        }
        if (this.f570q.m972b(g) < 0) {
            return 23104;
        }
        m527c(f, g);
        this.f571r.m958a(num, C0013d.m44g(num));
        setChipAttributes(c0099y);
        return 0;
    }

    public void mo3a() {
        C0104d.m832a("onStop", "chipcheck viw");
        m542o();
        this.f568o.m983e();
        this.f568o.m983e();
        this.f569p.m983e();
        this.f570q.m983e();
        this.f571r.m983e();
        this.f572s.m983e();
    }

    protected void mo4a(int i, String str, String str2, boolean z) {
        mo9c();
        try {
            this.f561h = new bs(getContext());
            this.f561h.m948a(i);
            this.f561h.m950a(str);
            this.f561h.m952b(str2);
            this.f561h.m949a(new C0061m(this));
            this.f561h.show();
        } catch (Exception e) {
            C0104d.m829a(e, "showProgress");
        }
    }

    public void m555a(int i, boolean z) {
        if (z) {
            m557a(m253f(i), z);
        } else {
            m557a(m256g(i), z);
        }
    }

    public void mo5a(C0041q c0041q) {
        try {
            C0104d.m832a("ChipInfoView:", "OnStart");
            this.f554a = (C0035k) c0041q.m222c("chip_data");
            this.f555b = this.f554a.f206a.f174h;
            m560a(this.f554a.f206a.f174h);
            m551x();
            m549v();
            m550w();
            if (this.f554a.f207b == 2) {
                this.f563j = true;
                m547t();
            } else {
                m548u();
                m545r();
                this.f563j = false;
            }
            m536i(this.f554a.f207b);
        } catch (Exception e) {
            C0104d.m828a(e);
        }
    }

    public void m557a(String str, boolean z) {
        this.f553Q.setText(str);
    }

    public boolean mo28a(int i) {
        return i == 0 || i == 1;
    }

    public boolean mo7a(int i, int i2) {
        C0104d.m831a("chipinfoview onkey event", i2);
        switch (i2) {
            case 1:
                if (this.f559f.getVisibility() == 0) {
                    m543p();
                    break;
                }
                break;
            case 2:
                if (this.f560g.getVisibility() == 0) {
                    m544q();
                    break;
                }
                break;
            case 4:
            case 8:
                if (this.f549M) {
                    return false;
                }
                break;
        }
        return super.mo7a(i, i2);
    }

    public boolean m560a(C0025a c0025a) {
        try {
            this.f557d.setImageBitmap(c0025a.f121H);
        } catch (Exception e) {
            this.f557d.setImageBitmap(null);
        }
        return true;
    }

    public void m561b() {
        setView(R.layout.activity_chip_check);
        this.f557d = (ImageView) findViewById(R.id.img_chip);
        this.f568o = new C0116j(getContext(), (Button) findViewById(R.id.sp_model), R.layout.dlg_popup_list);
        this.f568o.m960a((int) R.string.str_cb_title_model);
        this.f569p = new C0116j(getContext(), (Button) findViewById(R.id.sp_nat), R.layout.dlg_popup_list);
        this.f569p.m960a((int) R.string.str_cb_title_nat);
        this.f570q = new C0116j(getContext(), (Button) findViewById(R.id.sp_color), R.layout.dlg_popup_list);
        this.f570q.m960a((int) R.string.str_cb_title_color);
        this.f571r = new C0116j(getContext(), (Button) findViewById(R.id.sp_yield), R.layout.dlg_popup_list);
        this.f571r.m960a((int) R.string.str_cb_title_yield);
        this.f553Q = (TextView) findViewById(R.id.tv_msg);
        this.f559f = (ImageButton) findViewById(R.id.btn_start);
        this.f560g = (ImageButton) findViewById(R.id.btn_search);
        this.f538B = (TextView) findViewById(R.id.tv_zig);
        this.f539C = (TextView) findViewById(R.id.tv_status);
        this.f540D = (TextView) findViewById(R.id.tv_chip_mark);
        this.f541E = (TextView) findViewById(R.id.tv_remain);
        this.f543G = (TextView) findViewById(R.id.tv_autoregion);
        this.f542F = (TextView) findViewById(R.id.tv_ident);
        this.f573t = (CheckBoxEx) findViewById(R.id.cb_auto_job);
        this.f574u = (CheckBoxEx) findViewById(R.id.cb_ext_chip);
        this.f575v = (CheckBoxEx) findViewById(R.id.cb_auto_region);
        this.f544H = (TextView) findViewById(R.id.tv_model);
        this.f545I = (TextView) findViewById(R.id.tv_nat);
        this.f546J = (TextView) findViewById(R.id.tv_color);
        this.f547K = (TextView) findViewById(R.id.tv_yield);
        this.f548L = (TextView) findViewById(R.id.tv_version);
        this.f572s = new C0116j(getContext(), (Button) findViewById(R.id.sp_job), R.layout.dlg_popup_list);
        this.f572s.m960a((int) R.string.str_cb_title_job);
        this.f552P = (TextView) findViewById(R.id.tv_auto_region_title);
        this.f559f.setOnClickListener(new C0052e(this));
        this.f560g.setOnClickListener(new C0053f(this));
        this.f568o.m961a(new C0054g(this));
        this.f569p.m961a(new C0055h(this));
        this.f570q.m961a(new C0056i(this));
        this.f571r.m961a(new C0057j(this));
        this.f573t.setOnClickListener(new C0059k(this));
        this.f572s.m961a(new C0060l(this));
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        arrayList.add(m248d(R.string.str_job_check));
        arrayList2.add(String.valueOf(5));
        this.f572s.m965a(arrayList, arrayList2);
        this.f572s.m974b(0);
    }

    public boolean mo8b(C0099y c0099y) {
        C0104d.m830a(String.format("onPacketReceive:%02x,%d,%d", new Object[]{Integer.valueOf(c0099y.m808w()), Integer.valueOf(c0099y.f807W), Integer.valueOf(c0099y.m763A())}));
        this.f549M = false;
        if (mo28a(c0099y.m763A()) || c0099y.m808w() == 33) {
            switch (c0099y.m808w()) {
                case 32:
                    m531e(c0099y);
                    break;
                case 33:
                    C0104d.m833a("ChipExist:", c0099y.f829t);
                    if (c0099y.f829t) {
                        m543p();
                        break;
                    }
                    break;
                case 64:
                    m533f(c0099y);
                    break;
            }
            if (c0099y.f807W == 3) {
                mo9c();
                setSessionTime(false);
                this.f551O = false;
                this.f565l.m840a(1);
            } else {
                setSessionTime(true);
            }
            if (c0099y.m808w() == 64 && c0099y.f807W == 3) {
                m541n();
            }
        } else {
            m555a(c0099y.m763A(), true);
            mo9c();
            setSessionTime(false);
            this.f565l.m840a(0);
            this.f551O = false;
            if (c0099y.m808w() == 64 && c0099y.f807W == 3) {
                m541n();
            }
        }
        return true;
    }

    public void mo9c() {
        m523a(this.f561h);
    }

    public boolean getAutoJob() {
        return this.f567n;
    }

    public void setChipAttributes(C0099y c0099y) {
        this.f540D.setText(C0099y.m758j(c0099y.f819j));
        this.f541E.setText(C0099y.m759k(c0099y.f817h));
        if (this.f555b.f143q == 10) {
            this.f543G.setText(C0099y.m762n(c0099y.f827r));
        } else {
            this.f543G.setText(C0099y.m761m(c0099y.f827r));
        }
        this.f542F.setText(c0099y.f820k);
        m520a(this.f548L, C0099y.m760l(c0099y.f823n), true);
        this.f574u.setChecked(c0099y.f830u);
    }

    public void setTextMessage(int i) {
        m555a(i, true);
    }
}
