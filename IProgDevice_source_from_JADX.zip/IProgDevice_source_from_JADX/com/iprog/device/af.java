package com.iprog.device;

import com.iprog.view.ak;

class af implements ak {
    final /* synthetic */ ab f374a;

    af(ab abVar) {
        this.f374a = abVar;
    }

    public void mo15a(int i) {
        if (i == 1) {
            this.f374a.mo4a(0, this.f374a.m248d(R.string.dlg_data_send_title), this.f374a.m248d(R.string.dlg_data_send_msg), false);
            new Thread(new ag(this)).start();
        }
    }
}
