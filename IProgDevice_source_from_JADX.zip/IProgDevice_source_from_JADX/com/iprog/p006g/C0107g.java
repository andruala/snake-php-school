package com.iprog.p006g;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import com.iprog.device.R;

public class C0107g {
    private static C0107g f856a;
    private AudioManager f857b;
    private Context f858c;
    private int[] f859d = new int[4];
    private SoundPool f860e;

    private C0107g() {
    }

    public static C0107g m839a() {
        if (f856a == null) {
            f856a = new C0107g();
        }
        return f856a;
    }

    public void m840a(int i) {
        float streamVolume = ((float) this.f857b.getStreamVolume(3)) / ((float) this.f857b.getStreamMaxVolume(3));
        this.f860e.play(this.f859d[i], streamVolume, streamVolume, 1, 0, 1.0f);
    }

    public void m841a(Context context) {
        this.f858c = context;
        this.f860e = new SoundPool(5, 3, 0);
        this.f857b = (AudioManager) this.f858c.getSystemService("audio");
        this.f859d[0] = this.f860e.load(this.f858c, R.raw.fail, 1);
        this.f859d[1] = this.f860e.load(this.f858c, R.raw.success, 1);
        this.f859d[2] = this.f860e.load(this.f858c, R.raw.warning, 1);
        this.f859d[3] = this.f860e.load(this.f858c, R.raw.warning, 1);
    }
}
