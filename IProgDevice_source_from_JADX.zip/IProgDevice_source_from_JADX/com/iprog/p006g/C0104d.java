package com.iprog.p006g;

import android.util.Log;
import java.io.OutputStream;

public class C0104d {
    public static boolean f849a = false;
    public static String f850b = "0";
    public static boolean f851c = false;
    private static boolean f852d = true;
    private static String f853e = "IPROG";
    private static OutputStream f854f = null;
    private static Object f855g = new Object();

    public static void m828a(Exception exception) {
        C0104d.m829a(exception, "");
    }

    public static void m829a(Exception exception, String str) {
        try {
            StackTraceElement[] stackTrace = exception.getStackTrace();
            String format = String.format("********Exception %s******\n%s.%s(%s:%d)\nError Message:%s\n", new Object[]{str, stackTrace[1].getClassName(), stackTrace[1].getMethodName(), stackTrace[1].getFileName(), Integer.valueOf(stackTrace[1].getLineNumber()), exception.getMessage()});
            if (f852d) {
                Log.d(f853e, format);
            }
            exception.printStackTrace(System.err);
        } catch (Exception e) {
        }
    }

    public static void m830a(String str) {
        try {
            if (f849a) {
                String[] split = str.split("\n");
                for (int i = 0; i < split.length; i++) {
                    Log.d(f853e, split[i]);
                    C0104d.m835c(split[i]);
                }
            }
        } catch (Exception e) {
        }
    }

    public static void m831a(String str, int i) {
        C0104d.m830a(new StringBuilder(String.valueOf(str)).append(" - ").append(i).toString());
    }

    public static void m832a(String str, String str2) {
        C0104d.m830a(new StringBuilder(String.valueOf(str)).append(" - ").append(str2).toString());
    }

    public static void m833a(String str, boolean z) {
        C0104d.m830a(new StringBuilder(String.valueOf(str)).append(" - ").append(z).toString());
    }

    public static void m834b(String str) {
        if (f852d) {
            Log.d(f853e, str);
        }
    }

    private static void m835c(String str) {
        if (f854f != null) {
            try {
                synchronized (f855g) {
                    f854f.write(str.getBytes());
                    f854f.write("\r\n".getBytes());
                }
            } catch (Exception e) {
            }
        }
    }
}
