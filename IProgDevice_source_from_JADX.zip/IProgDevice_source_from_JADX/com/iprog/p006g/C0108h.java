package com.iprog.p006g;

import android.os.Handler;
import android.os.Message;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import org.apache.http.util.ByteArrayBuffer;

public class C0108h {
    public static int m842a(byte b) {
        return b & 255;
    }

    public static int m843a(int i, int i2) {
        return ((int) (Math.random() * ((double) ((i2 - i) + 1)))) + i;
    }

    public static int m844a(String str) {
        try {
            return Integer.parseInt(str);
        } catch (Exception e) {
            return (int) C0108h.m863b(str);
        }
    }

    public static int m845a(short s) {
        return 65535 & s;
    }

    public static int m846a(String[] strArr, String str) {
        int i = 0;
        while (i < strArr.length) {
            try {
                if (strArr[i].equals(str)) {
                    return i;
                }
                i++;
            } catch (Exception e) {
            }
        }
        return -1;
    }

    public static String m847a() {
        try {
            Enumeration networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                Enumeration inetAddresses = ((NetworkInterface) networkInterfaces.nextElement()).getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    InetAddress inetAddress = (InetAddress) inetAddresses.nextElement();
                    if (!inetAddress.isLoopbackAddress() && (inetAddress instanceof Inet4Address)) {
                        return inetAddress.getHostAddress().toString();
                    }
                }
            }
        } catch (Exception e) {
            C0104d.m829a(e, "getLocalIPAddress");
        }
        return "";
    }

    public static String m848a(String str, String str2) {
        return (str == null || str.trim().length() <= 0) ? str2 : str.trim();
    }

    public static String m849a(HashMap hashMap, int i) {
        try {
            String str;
            Iterator it = hashMap.keySet().iterator();
            do {
                if (it.hasNext()) {
                    str = (String) it.next();
                } else {
                    C0104d.m830a("Warning getHashValue not found:" + i);
                    return "";
                }
            } while (((Integer) hashMap.get(str)).intValue() != i);
            return str;
        } catch (Exception e) {
        }
    }

    public static String m850a(byte[] bArr) {
        return C0108h.m851a(bArr, 0, bArr.length);
    }

    public static String m851a(byte[] bArr, int i, int i2) {
        StringBuilder stringBuilder = new StringBuilder();
        if (bArr == null) {
            return "";
        }
        while (i < i2) {
            stringBuilder.append(String.format("%02x ", new Object[]{Byte.valueOf(bArr[i])}));
            if ((i + 1) % 8 == 0) {
                stringBuilder.append("    ");
            }
            if ((i + 1) % 16 == 0) {
                stringBuilder.append("\n");
            }
            i++;
        }
        return stringBuilder.toString();
    }

    public static ArrayList m852a(int[] iArr) {
        ArrayList arrayList = new ArrayList();
        int i = 0;
        while (i < iArr.length) {
            try {
                arrayList.add(Integer.toString(iArr[i]));
                i++;
            } catch (Exception e) {
            }
        }
        return arrayList;
    }

    public static void m853a(long j) {
        try {
            Thread.sleep(j);
        } catch (Exception e) {
        }
    }

    public static void m854a(BufferedReader bufferedReader) {
        if (bufferedReader != null) {
            try {
                bufferedReader.close();
            } catch (Exception e) {
            }
        }
    }

    public static void m855a(InputStream inputStream) {
        if (inputStream != null) {
            try {
                inputStream.close();
            } catch (Exception e) {
            }
        }
    }

    public static void m856a(OutputStream outputStream) {
        if (outputStream != null) {
            try {
                outputStream.flush();
            } catch (Exception e) {
            }
            try {
                outputStream.close();
            } catch (Exception e2) {
            }
        }
    }

    public static boolean m857a(Handler handler, int i, String str) {
        Message obtain = Message.obtain();
        obtain.obj = "";
        obtain.what = i;
        if (str != null) {
            obtain.obj = str;
        }
        try {
            handler.sendMessage(obtain);
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "Util.SendMessage");
            return false;
        }
    }

    public static boolean m858a(ArrayList arrayList, String str) {
        for (int i = 0; i < arrayList.size(); i++) {
            if (((String) arrayList.get(i)).equals(str)) {
                return true;
            }
        }
        return false;
    }

    public static byte[] m859a(int i) {
        return new byte[]{(byte) (i >>> 24), (byte) (i >>> 16), (byte) (i >>> 8), (byte) i};
    }

    public static byte[] m860a(String str, int i) {
        Object obj = new byte[i];
        Object bytes = str.getBytes();
        System.arraycopy(bytes, 0, obj, 0, Math.min(bytes.length, obj.length));
        return obj;
    }

    public static byte[] m861a(ByteBuffer byteBuffer, int i) {
        byte[] bArr = new byte[i];
        byteBuffer.get(bArr);
        return bArr;
    }

    public static byte[] m862a(byte[] bArr, byte[] bArr2) {
        Object obj = new byte[(bArr.length + bArr2.length)];
        System.arraycopy(bArr, 0, obj, 0, bArr.length);
        System.arraycopy(bArr2, 0, obj, bArr.length, bArr2.length);
        return obj;
    }

    public static double m863b(String str) {
        try {
            return Double.parseDouble(str);
        } catch (Exception e) {
            return 0.0d;
        }
    }

    public static int m864b(byte[] bArr) {
        return (((bArr[0] << 24) + ((bArr[1] & 255) << 16)) + ((bArr[2] & 255) << 8)) + (bArr[3] & 255);
    }

    public static String m865b(int i) {
        StringBuffer stringBuffer = new StringBuffer();
        Random random = new Random();
        char[] cArr = new char[]{'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'A', 'B', 'C', 'd', 'E', 'F', 'G', 'H', 'x', 'J', 'K', 'b', 'M', 'N', 'y', 'P', 'r', 'R', 'S', 'T', 'u', 'V', 'W', 'X', 'Y', 'Z'};
        for (int i2 = 0; i2 < i; i2++) {
            stringBuffer.append(cArr[random.nextInt(cArr.length)]);
        }
        return stringBuffer.toString();
    }

    public static boolean m866c(String str) {
        try {
            return str.equalsIgnoreCase("Y");
        } catch (Exception e) {
            return false;
        }
    }

    public static byte[] m867c(int i) {
        return new byte[i];
    }

    public static boolean m868d(String str) {
        return str != null && str.length() > 0;
    }

    public static byte[] m869d(int i) {
        byte[] bArr = new byte[i];
        for (int i2 = 0; i2 < i; i2++) {
            bArr[i2] = (byte) C0108h.m843a(1, 255);
        }
        return bArr;
    }

    public static String m870e(String str) {
        return str != null ? str : "";
    }

    public static byte[] m871f(String str) {
        Throwable th;
        ByteArrayBuffer byteArrayBuffer = new ByteArrayBuffer(4096);
        byte[] bArr = new byte[2048];
        FileInputStream fileInputStream;
        try {
            fileInputStream = new FileInputStream(str);
            while (true) {
                try {
                    int read = fileInputStream.read(bArr);
                    if (read == -1) {
                        try {
                            break;
                        } catch (IOException e) {
                        }
                    } else if (read > 0) {
                        byteArrayBuffer.append(bArr, 0, read);
                    }
                } catch (Throwable th2) {
                    th = th2;
                }
            }
            fileInputStream.close();
            return byteArrayBuffer.toByteArray();
        } catch (Throwable th3) {
            th = th3;
            fileInputStream = null;
            try {
                fileInputStream.close();
            } catch (IOException e2) {
            }
            throw th;
        }
    }

    public static String m872g(String str) {
        try {
            NetworkInterface networkInterface;
            Iterator it = Collections.list(NetworkInterface.getNetworkInterfaces()).iterator();
            do {
                if (it.hasNext()) {
                    networkInterface = (NetworkInterface) it.next();
                    if (str == null) {
                        break;
                    }
                } else {
                    return "";
                }
            } while (!networkInterface.getName().equalsIgnoreCase(str));
            byte[] hardwareAddress = networkInterface.getHardwareAddress();
            if (hardwareAddress == null) {
                return "";
            }
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < hardwareAddress.length; i++) {
                stringBuilder.append(String.format("%02X:", new Object[]{Byte.valueOf(hardwareAddress[i])}));
            }
            if (stringBuilder.length() > 0) {
                stringBuilder.deleteCharAt(stringBuilder.length() - 1);
            }
            return stringBuilder.toString();
        } catch (Exception e) {
        }
    }
}
