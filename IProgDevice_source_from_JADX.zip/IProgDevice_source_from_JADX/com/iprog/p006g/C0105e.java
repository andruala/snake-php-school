package com.iprog.p006g;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

public class C0105e {
    public static String m836a(String str, List list) {
        try {
            HttpClient defaultHttpClient = new DefaultHttpClient();
            HttpUriRequest httpPost = new HttpPost(str);
            HttpEntity urlEncodedFormEntity = new UrlEncodedFormEntity(list, "UTF-8");
            urlEncodedFormEntity.setContentType("application/x-www-form-urlencoded");
            httpPost.setEntity(urlEncodedFormEntity);
            HttpResponse execute = defaultHttpClient.execute(httpPost);
            if (execute.getStatusLine().getStatusCode() == 200) {
                HttpEntity entity = execute.getEntity();
                if (entity != null) {
                    return EntityUtils.toString(entity).trim();
                }
            }
        } catch (Exception e) {
            C0104d.m832a("Send Url", str);
            C0104d.m829a(e, "sendPost");
        }
        return "";
    }

    public static boolean m837a(String str) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.setConnectTimeout(1000);
            httpURLConnection.connect();
            int responseCode = httpURLConnection.getResponseCode();
            C0104d.m830a("ResponseCode:" + responseCode);
            if (responseCode == 200) {
                return true;
            }
        } catch (Exception e) {
            C0104d.m830a("Connection Error");
        }
        return false;
    }
}
