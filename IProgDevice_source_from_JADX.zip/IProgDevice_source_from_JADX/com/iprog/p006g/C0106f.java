package com.iprog.p006g;

public class C0106f extends Thread {
    public static int m838a(int i) {
        switch (i) {
            case 4:
                return 4;
            case 19:
                return 2;
            case 20:
                return 1;
            case 26:
                return 8;
            default:
                return 0;
        }
    }
}
