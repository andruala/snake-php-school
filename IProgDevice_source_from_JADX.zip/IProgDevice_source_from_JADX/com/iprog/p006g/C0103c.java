package com.iprog.p006g;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class C0103c {
    public static String m823a() {
        return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
    }

    public static String m824a(String str) {
        return new SimpleDateFormat(str).format(new Date());
    }

    public static Date m825a(int i, int i2, int i3, int i4, int i5, int i6) {
        Calendar gregorianCalendar = new GregorianCalendar();
        gregorianCalendar.set(i, i2 - 1, i3, i4, i5, i6);
        return gregorianCalendar.getTime();
    }

    public static Date m826a(int i, Date date) {
        Calendar instance = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        instance.setTime(date);
        instance.add(2, i);
        return instance.getTime();
    }

    public static Date m827b(String str) {
        int parseInt;
        int parseInt2;
        int parseInt3;
        int parseInt4;
        NumberFormatException numberFormatException;
        int i;
        int i2 = 0;
        try {
            parseInt = Integer.parseInt(str.substring(0, 4));
            try {
                parseInt2 = Integer.parseInt(str.substring(4, 6));
                try {
                    parseInt3 = Integer.parseInt(str.substring(6, 8));
                    try {
                        parseInt4 = Integer.parseInt(str.substring(8, 10));
                    } catch (NumberFormatException e) {
                        numberFormatException = e;
                        i = i2;
                        parseInt4 = i2;
                        numberFormatException.printStackTrace();
                        return C0103c.m825a(parseInt, parseInt2, parseInt3, parseInt4, i, i2);
                    }
                } catch (NumberFormatException e2) {
                    numberFormatException = e2;
                    i = i2;
                    parseInt3 = 1;
                    parseInt4 = i2;
                    numberFormatException.printStackTrace();
                    return C0103c.m825a(parseInt, parseInt2, parseInt3, parseInt4, i, i2);
                }
                try {
                    i = Integer.parseInt(str.substring(10, 12));
                    try {
                        i2 = Integer.parseInt(str.substring(12, 14));
                    } catch (NumberFormatException e3) {
                        numberFormatException = e3;
                        numberFormatException.printStackTrace();
                        return C0103c.m825a(parseInt, parseInt2, parseInt3, parseInt4, i, i2);
                    }
                } catch (NumberFormatException e4) {
                    numberFormatException = e4;
                    i = i2;
                    numberFormatException.printStackTrace();
                    return C0103c.m825a(parseInt, parseInt2, parseInt3, parseInt4, i, i2);
                }
            } catch (NumberFormatException e5) {
                numberFormatException = e5;
                i = i2;
                parseInt3 = 1;
                parseInt2 = 1;
                parseInt4 = i2;
                numberFormatException.printStackTrace();
                return C0103c.m825a(parseInt, parseInt2, parseInt3, parseInt4, i, i2);
            }
        } catch (NumberFormatException e6) {
            numberFormatException = e6;
            i = i2;
            parseInt3 = 1;
            parseInt = 1970;
            parseInt2 = 1;
            parseInt4 = i2;
            numberFormatException.printStackTrace();
            return C0103c.m825a(parseInt, parseInt2, parseInt3, parseInt4, i, i2);
        }
        return C0103c.m825a(parseInt, parseInt2, parseInt3, parseInt4, i, i2);
    }
}
