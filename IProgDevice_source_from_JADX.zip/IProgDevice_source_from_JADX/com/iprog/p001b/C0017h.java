package com.iprog.p001b;

import com.iprog.p003d.C0030f;
import java.util.Comparator;

class C0017h implements Comparator {
    C0017h() {
    }

    public int m137a(C0030f c0030f, C0030f c0030f2) {
        return c0030f.f170d.compareToIgnoreCase(c0030f2.f170d);
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m137a((C0030f) obj, (C0030f) obj2);
    }
}
