package com.iprog.p001b;

import com.iprog.p003d.C0035k;
import java.util.Comparator;

class C0014e implements Comparator {
    C0014e() {
    }

    public int m134a(C0035k c0035k, C0035k c0035k2) {
        return c0035k.f207b != c0035k2.f207b ? (c0035k.f207b - c0035k2.f207b) * -1 : c0035k.f208c - c0035k2.f208c;
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m134a((C0035k) obj, (C0035k) obj2);
    }
}
