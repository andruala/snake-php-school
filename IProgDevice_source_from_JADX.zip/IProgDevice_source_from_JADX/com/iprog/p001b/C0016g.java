package com.iprog.p001b;

import com.iprog.p003d.C0025a;
import java.util.Comparator;

class C0016g implements Comparator {
    C0016g() {
    }

    public int m136a(C0025a c0025a, C0025a c0025a2) {
        return c0025a.f132f.compareToIgnoreCase(c0025a2.f132f);
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m136a((C0025a) obj, (C0025a) obj2);
    }
}
