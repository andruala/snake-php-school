package com.iprog.p001b;

import android.os.Handler;

class C0019j implements Runnable {
    final /* synthetic */ C0013d f95a;
    private final /* synthetic */ Handler f96b;
    private final /* synthetic */ int f97c;
    private final /* synthetic */ Object f98d;

    C0019j(C0013d c0013d, Handler handler, int i, Object obj) {
        this.f95a = c0013d;
        this.f96b = handler;
        this.f97c = i;
        this.f98d = obj;
    }

    public void run() {
        this.f95a.m82b(this.f96b, this.f97c, this.f98d);
    }
}
