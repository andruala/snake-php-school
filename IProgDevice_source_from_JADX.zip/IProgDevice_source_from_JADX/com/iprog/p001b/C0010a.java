package com.iprog.p001b;

public class C0010a {
    public static final int[] f36a = new int[]{19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29};

    public static int[] m13a() {
        return f36a;
    }
}
