package com.iprog.p001b;

import com.iprog.p003d.C0030f;
import java.util.Comparator;

class C0018i implements Comparator {
    C0018i() {
    }

    public int m138a(C0030f c0030f, C0030f c0030f2) {
        return c0030f.f169c.compareToIgnoreCase(c0030f2.f169c);
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m138a((C0030f) obj, (C0030f) obj2);
    }
}
