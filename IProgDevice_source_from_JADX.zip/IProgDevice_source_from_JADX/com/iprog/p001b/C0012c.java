package com.iprog.p001b;

import com.iprog.p004f.C0099y;

public class C0012c {
    public static int m32a(int i) {
        return i;
    }

    public static boolean m33a(C0099y c0099y) {
        return false;
    }
}
