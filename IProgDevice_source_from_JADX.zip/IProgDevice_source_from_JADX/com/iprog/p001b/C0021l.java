package com.iprog.p001b;

import com.iprog.p004f.C0099y;

class C0021l implements Runnable {
    final /* synthetic */ C0013d f101a;
    private final /* synthetic */ C0099y f102b;
    private final /* synthetic */ int f103c;

    C0021l(C0013d c0013d, C0099y c0099y, int i) {
        this.f101a = c0013d;
        this.f102b = c0099y;
        this.f103c = i;
    }

    public void run() {
        this.f101a.m63a(this.f102b, this.f103c);
    }
}
