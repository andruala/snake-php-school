package com.iprog.p001b;

class C0020k implements Runnable {
    final /* synthetic */ C0013d f99a;
    private final /* synthetic */ int f100b;

    C0020k(C0013d c0013d, int i) {
        this.f99a = c0013d;
        this.f100b = i;
    }

    public void run() {
        this.f99a.m82b(this.f99a.f77i, this.f100b, (Object) "");
    }
}
