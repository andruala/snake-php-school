package com.iprog.p001b;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import com.iprog.p006g.C0104d;
import java.text.SimpleDateFormat;
import java.util.Date;

public class C0011b {
    private static C0011b f37e = new C0011b();
    private static Context f38f;
    final int f39a = 5;
    final int f40b = 5;
    final int f41c = 3;
    final int f42d = 5;

    public static C0011b m14a(Context context) {
        f38f = context;
        return f37e;
    }

    public static String m15a() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
    }

    private void m16a(int i) {
        try {
            Editor edit = f38f.getSharedPreferences("IPROG", 0).edit();
            edit.putInt("LOCK_RESET_FAULT_CNT", i);
            edit.commit();
        } catch (Exception e) {
        }
    }

    private void m17b(int i) {
        try {
            String str = "";
            if (i == 1) {
                str = String.format("%d@%s", new Object[]{Integer.valueOf(i), C0011b.m15a()});
            } else if (i > 1) {
                str = String.format("%s\n%d@%s", new Object[]{m24b(), Integer.valueOf(i), C0011b.m15a()});
            }
            Editor edit = f38f.getSharedPreferences("IPROG", 0).edit();
            edit.putString("LOCK_RESET_FAULT_LOG", str);
            edit.commit();
        } catch (Exception e) {
        }
    }

    private void m18c(int i) {
        try {
            Editor edit = f38f.getSharedPreferences("IPROG", 0).edit();
            edit.putInt("LOCK_CREDIT_FAULT_SES", i);
            edit.commit();
        } catch (Exception e) {
        }
    }

    private void m19d(int i) {
        try {
            Editor edit = f38f.getSharedPreferences("IPROG", 0).edit();
            edit.putInt("LOCK_CREDIT_FAULT_CNT", i);
            edit.commit();
        } catch (Exception e) {
        }
    }

    private void m20e(int i) {
        C0104d.m830a("setCreditFaultLog:" + i);
        try {
            String str = "";
            if (i == 1) {
                str = String.format("%d@%s", new Object[]{Integer.valueOf(i), C0011b.m15a()});
            } else if (i > 1) {
                str = String.format("%s\n%d@%s", new Object[]{m31i(), Integer.valueOf(i), C0011b.m15a()});
            }
            Editor edit = f38f.getSharedPreferences("IPROG", 0).edit();
            edit.putString("LOCK_CREDIT_FAULT_LOG", str);
            edit.commit();
        } catch (Exception e) {
        }
    }

    private int m21j() {
        return f38f.getSharedPreferences("IPROG", 0).getInt("LOCK_RESET_FAULT_CNT", 0);
    }

    private int m22k() {
        return f38f.getSharedPreferences("IPROG", 0).getInt("LOCK_CREDIT_FAULT_SES", 0);
    }

    private int m23l() {
        return f38f.getSharedPreferences("IPROG", 0).getInt("LOCK_CREDIT_FAULT_CNT", 0);
    }

    public String m24b() {
        return f38f.getSharedPreferences("IPROG", 0).getString("LOCK_RESET_FAULT_LOG", "");
    }

    public void m25c() {
        int j = m21j();
        m16a(j + 1);
        m17b(j + 1);
    }

    public void m26d() {
        m16a(0);
        m17b(0);
    }

    public boolean m27e() {
        return m21j() >= 5;
    }

    public void m28f() {
        int k = m22k();
        if (k + 1 >= 3) {
            k = m23l();
            m20e(k + 1);
            m19d(k + 1);
            m18c(0);
            return;
        }
        m18c(k + 1);
    }

    public boolean m29g() {
        return m23l() >= 5;
    }

    public void m30h() {
        m19d(0);
        m18c(0);
        m20e(0);
    }

    public String m31i() {
        return f38f.getSharedPreferences("IPROG", 0).getString("LOCK_CREDIT_FAULT_LOG", "");
    }
}
