package com.iprog.p001b;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;
import com.iprog.device.R;
import com.iprog.p002c.C0024b;
import com.iprog.p003d.C0025a;
import com.iprog.p003d.C0030f;
import com.iprog.p003d.C0035k;
import com.iprog.p004f.C0099y;
import com.iprog.p004f.ac;
import com.iprog.p005e.C0075a;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

public class C0013d {
    public static String f43W = "";
    public static Comparator f44X = new C0014e();
    public static Comparator f45Y = new C0015f();
    public static Comparator f46Z = new C0016g();
    public static boolean f47a = false;
    public static Comparator aa = new C0017h();
    public static Comparator ab = new C0018i();
    private static C0013d ai = new C0013d();
    public static boolean f48b = false;
    public static boolean f49c = true;
    public static boolean f50d = true;
    public static Context f51f = null;
    public int f52A = 512;
    public int f53B = 1;
    public int f54C = 1;
    public String f55D = "";
    public int f56E = 0;
    public int f57F = 0;
    public int f58G = 0;
    public int f59H = 0;
    public int f60I = 0;
    public boolean f61J = false;
    public ArrayList f62K = new ArrayList();
    public ArrayList f63L = new ArrayList();
    public ArrayList f64M = new ArrayList();
    public ArrayList f65N = new ArrayList();
    public ArrayList f66O = new ArrayList();
    public ArrayList f67P = new ArrayList();
    public HashMap f68Q = new HashMap();
    public HashMap f69R = new HashMap();
    public HashMap f70S = new HashMap();
    public HashMap f71T = new HashMap();
    public HashMap f72U = new HashMap();
    public HashMap f73V = new HashMap();
    int ac = 1;
    public Handler ad = null;
    public String ae = "";
    public String af = "";
    public int ag = 1;
    public int ah = 1;
    private C0075a aj = null;
    private C0024b ak = new C0024b();
    private ArrayList al = new ArrayList();
    public final String f74e = "data/rp3_chip_info.dat";
    public Activity f75g = null;
    public Handler f76h = null;
    public Handler f77i = null;
    public Handler f78j = null;
    public final String f79k = "http://iprog.tncore.com";
    public final String f80l = "http://iprog.tncore.com";
    public boolean f81m = false;
    public boolean f82n = false;
    public ArrayList f83o = new ArrayList();
    public ArrayList f84p = new ArrayList();
    public ArrayList f85q = new ArrayList();
    public ArrayList f86r = new ArrayList();
    public ArrayList f87s = new ArrayList();
    public int f88t = 0;
    public ArrayList f89u = new ArrayList();
    public int f90v = 257;
    public int f91w = 257;
    public int f92x = 257;
    public int f93y = 257;
    public int f94z = 257;

    private C0013d() {
        this.f70S.put("K", Integer.valueOf(1));
        this.f70S.put("C", Integer.valueOf(2));
        this.f70S.put("M", Integer.valueOf(4));
        this.f70S.put("Y", Integer.valueOf(8));
        this.f70S.put("CMY", Integer.valueOf(14));
        this.f70S.put("COLOR", Integer.valueOf(15));
        this.f70S.put("MONO", Integer.valueOf(16));
        this.f70S.put("-", Integer.valueOf(99));
        C0104d.f849a = f47a;
        f50d = false;
    }

    public static boolean m34B(int i) {
        return i == 160400011 || i == 160400111 || i == 160400211;
    }

    public static boolean m35C(int i) {
        int[] iArr = new int[]{359999111, 359999211, 359999311};
        for (int i2 : iArr) {
            if (i2 == i) {
                return true;
            }
        }
        return false;
    }

    private C0030f m36a(ArrayList arrayList, String str) {
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            C0030f c0030f = (C0030f) it.next();
            if (c0030f.f167a.equals(str)) {
                return c0030f;
            }
        }
        return null;
    }

    private void m37a(C0025a c0025a) {
        C0030f a = m36a(this.f83o, c0025a.f127a);
        if (a == null) {
            this.f83o.add(new C0030f(c0025a));
            return;
        }
        a.m170a(c0025a);
    }

    public static C0013d m38b(Context context) {
        f51f = context;
        return ai;
    }

    public static ArrayList m39b(ArrayList arrayList) {
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < arrayList.size(); i++) {
            arrayList2.add(C0013d.m46n(C0108h.m844a((String) arrayList.get(i))));
        }
        return arrayList2;
    }

    private void m40b(C0025a c0025a) {
        C0030f a = m36a(this.f84p, c0025a.f127a);
        if (a != null) {
            a.m170a(c0025a);
        } else if (c0025a.f128b != 2) {
            this.f84p.add(new C0030f(c0025a));
        } else if (c0025a.f152z || c0025a.f115B || c0025a.f145s) {
            this.f84p.add(new C0030f(c0025a));
        }
    }

    public static String m41c(int i, int i2) {
        StringBuilder stringBuilder = new StringBuilder();
        if (i == 30 || i == 31 || i == 7) {
            if (i == 30) {
                stringBuilder.append("RFID\nLF");
            } else if (i == 31 || i == 7) {
                stringBuilder.append("RFID\nHF");
            }
            if (i2 > 0) {
                stringBuilder.append("(").append(i2).append(")");
            }
            return stringBuilder.toString();
        }
        if (i > 0) {
            stringBuilder.append(i);
        } else if (i2 > 0) {
            stringBuilder.append(i2);
        } else {
            stringBuilder.append("");
        }
        return stringBuilder.toString();
    }

    public static C0013d m42d() {
        return ai;
    }

    public static String m43d(int i, int i2) {
        StringBuilder stringBuilder = new StringBuilder();
        if (i == 30 || i == 31 || i == 7) {
            if (i == 30) {
                stringBuilder.append("RFID-LF");
            } else if (i == 31 || i == 7) {
                stringBuilder.append("RFID-HF");
            }
            if (i2 > 0) {
                stringBuilder.append("(").append(i2).append(")");
            }
            return stringBuilder.toString();
        }
        if (i > 0) {
            stringBuilder.append(i);
        } else {
            stringBuilder.append(i2);
        }
        return stringBuilder.toString();
    }

    public static String m44g(String str) {
        return C0013d.m46n(C0108h.m844a(str));
    }

    private Bitmap m45k(String str) {
        Bitmap bitmap = (Bitmap) this.f71T.get(str);
        if (bitmap == null && !str.isEmpty()) {
            bitmap = m93f("image/chip/" + str);
            if (bitmap == null) {
                C0104d.m830a("###Warning Image Chip Not found:" + str);
            } else {
                this.f71T.put(str, bitmap);
            }
        }
        return bitmap;
    }

    public static String m46n(int i) {
        if (i == 0) {
            return "-";
        }
        if (i % 1000 == 0) {
            return String.format("%dK", new Object[]{Integer.valueOf(i / 1000)});
        }
        return String.format("%.1fK", new Object[]{Double.valueOf(((double) i) / 1000.0d)});
    }

    public static String m47o(int i) {
        DecimalFormat decimalFormat = new DecimalFormat("#,##0");
        DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols();
        decimalFormatSymbols.setGroupingSeparator(',');
        decimalFormat.setGroupingSize(3);
        decimalFormat.setDecimalFormatSymbols(decimalFormatSymbols);
        return decimalFormat.format((long) i).toString();
    }

    public static String m48x() {
        return Build.ID;
    }

    public static int m49y() {
        return C0108h.m844a(Build.ID.substring(3, 5));
    }

    private Context m50z() {
        return f51f;
    }

    public void m51A(int i) {
        this.ac = i;
    }

    public ArrayList m52D(int i) {
        ArrayList arrayList = new ArrayList();
        Iterator it = this.f86r.iterator();
        while (it.hasNext()) {
            C0030f c0030f = (C0030f) it.next();
            if (!m130w() && c0030f.m172a(i)) {
                arrayList.add(c0030f);
            }
        }
        return arrayList;
    }

    public int m53a(int i) {
        switch (i) {
            case 1:
            case 7:
                return 1;
            case 2:
                return 2;
            case 3:
                return 4;
            case 4:
                return 5;
            case 5:
                return 3;
            default:
                return 0;
        }
    }

    public int m54a(String str) {
        return m55a(this.f69R, str);
    }

    public int m55a(HashMap hashMap, String str) {
        int intValue;
        try {
            Integer num = (Integer) hashMap.get(str);
            if (num == null) {
                return 0;
            }
            intValue = num.intValue();
            return intValue;
        } catch (Exception e) {
            C0104d.m828a(e);
            C0104d.m832a("Error:", str);
            intValue = 0;
        }
    }

    public ArrayList m56a(int i, int i2) {
        ArrayList arrayList = new ArrayList();
        Iterator it = this.f87s.iterator();
        while (it.hasNext()) {
            C0030f c0030f = (C0030f) it.next();
            if (c0030f.f168b == i) {
                arrayList.add(c0030f);
            }
        }
        return arrayList;
    }

    public ArrayList m57a(C0025a c0025a, boolean z) {
        ArrayList arrayList = new ArrayList();
        if (c0025a.f144r == 0) {
            arrayList.add(c0025a);
            return arrayList;
        }
        Iterator it = this.f87s.iterator();
        while (it.hasNext()) {
            C0030f c0030f = (C0030f) it.next();
            if (c0030f.m173b(z) == c0025a.f144r) {
                arrayList.add(c0030f.m169a(z));
            }
        }
        C0104d.m830a("changeModelList Size:" + arrayList.size());
        return arrayList;
    }

    public ArrayList m58a(String str, int i) {
        List d = m88d(str);
        if (this.f87s == null || str.length() < 1) {
            return d;
        }
        for (int i2 = 0; i2 < this.f87s.size(); i2++) {
            int indexOf = ((C0030f) this.f87s.get(i2)).f171e.indexOf(str);
            if (indexOf >= 0) {
                d.add(new C0035k((C0030f) this.f87s.get(i2), indexOf, 1));
            } else {
                indexOf = ((C0030f) this.f87s.get(i2)).f172f.indexOf(str);
                if (indexOf >= 0) {
                    d.add(new C0035k((C0030f) this.f87s.get(i2), indexOf, 0));
                }
            }
        }
        Collections.sort(d, f44X);
        return d;
    }

    public ArrayList m59a(ArrayList arrayList) {
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < arrayList.size(); i++) {
            arrayList2.add(((C0025a) arrayList.get(i)).f132f);
        }
        return arrayList2;
    }

    public void m60a(int i, Object obj) {
        m82b(this.f77i, i, obj);
    }

    public void m61a(int i, String str, int i2) {
        Toast makeText = Toast.makeText(m50z(), str, i2);
        makeText.setGravity(17, 0, i);
        makeText.show();
    }

    public void m62a(ac acVar, int i) {
        m82b(this.f78j, i, (Object) acVar);
    }

    public void m63a(C0099y c0099y, int i) {
        m82b(this.f78j, i, (Object) c0099y);
    }

    public void m64a(boolean z) {
        this.f81m = z;
    }

    public void m65a(byte[] bArr) {
        this.ak.m146a(bArr);
    }

    public boolean m66a() {
        return this.f59H >= 35 || this.f58G == 0;
    }

    public boolean m67a(int i, HashMap hashMap) {
        hashMap.clear();
        XmlPullParser xml = f51f.getResources().getXml(i);
        String str = "";
        String str2 = "";
        while (xml.getEventType() != 1) {
            if (xml.getEventType() == 2 && xml.getName().equals("data")) {
                try {
                    str = xml.getAttributeValue(null, "code");
                    str2 = xml.nextText();
                    hashMap.put(Integer.valueOf(Integer.parseInt(str)), str2.replace("\\n", "\n"));
                } catch (Exception e) {
                    C0104d.m829a(e, "MessageCode:" + str + "," + str2);
                }
            }
            try {
                xml.next();
            } catch (Exception e2) {
                C0104d.m828a(e2);
                return false;
            }
        }
        C0104d.m830a("getResetprogXmlData2 Size:" + hashMap.size());
        return true;
    }

    public boolean m68a(Context context) {
        this.aj = new C0075a(context);
        this.aj.m633a();
        this.aj.m638b();
        return true;
    }

    public boolean m69a(Handler handler, int i) {
        return m82b(handler, i, null);
    }

    public boolean m70a(Handler handler, int i, Object obj) {
        new Thread(new C0019j(this, handler, i, obj)).start();
        return true;
    }

    public boolean m71a(C0025a c0025a, int i) {
        switch (i) {
            case 1:
            case 7:
                return c0025a.f148v;
            case 2:
                return c0025a.f148v;
            case 3:
                return true;
            case 4:
                return c0025a.f150x;
            case 5:
                return c0025a.f149w;
            default:
                return false;
        }
    }

    public boolean m72a(String str, String str2) {
        return m80b(m104j(str), m104j(str2));
    }

    public boolean m73a(ArrayList arrayList, int i) {
        String e = m92e(i);
        if (e.equals("-")) {
            return false;
        }
        for (int i2 = 0; i2 < arrayList.size(); i2++) {
            if (((String) arrayList.get(i2)).equals(e)) {
                return false;
            }
        }
        arrayList.add(e);
        return true;
    }

    public byte[] m74a(byte[] bArr, int i, int i2) {
        return this.ak.m147a(bArr, i, i2);
    }

    public int m75b(int i) {
        switch (i) {
            case 1:
            case 2:
                return 48;
            case 3:
                return 49;
            case 4:
                return 50;
            case 5:
                return 64;
            case 6:
                return 80;
            case 7:
                return 51;
            default:
                return 0;
        }
    }

    public int m76b(String str) {
        return m55a(this.f70S, str);
    }

    public C0075a m77b() {
        if (this.aj == null) {
            m68a(f51f);
        }
        return this.aj;
    }

    public void m78b(ac acVar, int i) {
        new Thread(new C0022m(this, acVar, i)).start();
    }

    public void m79b(C0099y c0099y, int i) {
        new Thread(new C0021l(this, c0099y, i)).start();
    }

    public boolean m80b(int i, int i2) {
        C0104d.m830a("sw ver:" + i);
        C0104d.m830a("fw ver:" + i2);
        C0104d.m830a("cur sw ver:" + this.f93y);
        C0104d.m830a("cur  fw ver:" + this.f91w);
        return i > this.f93y ? true : i == this.f93y && i2 > this.f91w;
    }

    public boolean m81b(int i, HashMap hashMap) {
        hashMap.clear();
        XmlPullParser xml = f51f.getResources().getXml(i);
        String str = "";
        String str2 = "";
        while (xml.getEventType() != 1) {
            if (xml.getEventType() == 2 && xml.getName().equals("data")) {
                try {
                    str = xml.getAttributeValue(null, "code").trim();
                    str2 = xml.nextText().trim();
                    hashMap.put(str, Integer.valueOf(Integer.parseInt(str2)));
                } catch (Exception e) {
                    try {
                        C0104d.m829a(e, "MessageCode:" + str + "," + str2);
                    } catch (Exception e2) {
                        C0104d.m828a(e2);
                        return false;
                    }
                }
            }
            xml.next();
        }
        return true;
    }

    public boolean m82b(Handler handler, int i, Object obj) {
        Message obtain = Message.obtain();
        obtain.obj = obj;
        obtain.what = i;
        try {
            handler.sendMessage(obtain);
            return true;
        } catch (Exception e) {
            C0104d.m832a("Exception SendMessage", e.getMessage());
            return false;
        }
    }

    public byte[] m83b(byte[] bArr, int i, int i2) {
        return this.ak.m148b(bArr, i, i2);
    }

    public int m84c(String str) {
        try {
            return ((Integer) this.f68Q.get(str)).intValue();
        } catch (Exception e) {
            return 0;
        }
    }

    public String m85c(int i) {
        if (i == 0) {
            try {
                return f51f.getString(R.string.credit_type);
            } catch (Exception e) {
            }
        } else {
            String str = (String) this.f72U.get(Integer.valueOf(i));
            if (str != null) {
                return str;
            }
            return "-";
        }
    }

    public void m86c() {
        this.aj.close();
        this.aj = null;
    }

    public boolean m87c(int i, HashMap hashMap) {
        hashMap.clear();
        XmlPullParser xml = f51f.getResources().getXml(i);
        String str = "";
        String str2 = "";
        while (xml.getEventType() != 1) {
            if (xml.getEventType() == 2 && xml.getName().equals("data")) {
                try {
                    str = xml.getAttributeValue(null, "code").trim();
                    str2 = xml.nextText().trim();
                    hashMap.put(str, str2);
                } catch (Exception e) {
                    C0104d.m829a(e, "MessageCode:" + str + "," + str2);
                }
            }
            try {
                xml.next();
            } catch (Exception e2) {
                C0104d.m828a(e2);
                return false;
            }
        }
        return true;
    }

    public ArrayList m88d(String str) {
        ArrayList arrayList = new ArrayList();
        if (this.f87s == null || str.length() < 1) {
            return arrayList;
        }
        Iterator it = this.f87s.iterator();
        while (it.hasNext()) {
            C0030f c0030f = (C0030f) it.next();
            int indexOf = c0030f.m179f().indexOf(str);
            if (indexOf >= 0) {
                Object obj;
                for (int i = 0; i < arrayList.size(); i++) {
                    if (((C0035k) arrayList.get(i)).f206a.m179f().equals(c0030f.m179f())) {
                        obj = null;
                        break;
                    }
                }
                obj = 1;
                if (obj != null) {
                    arrayList.add(new C0035k(c0030f, indexOf, 2));
                }
            }
        }
        return arrayList;
    }

    public boolean m89d(int i) {
        C0104d.m830a("isCredit:online:" + i);
        return i >= 35;
    }

    public C0011b m90e() {
        return C0011b.m14a(ai.m50z());
    }

    public C0030f m91e(String str) {
        if (this.f87s == null || str.length() < 1) {
            return null;
        }
        for (int i = 0; i < this.f87s.size(); i++) {
            if (((C0030f) this.f87s.get(i)).f167a.indexOf(str) >= 0) {
                return (C0030f) this.f87s.get(i);
            }
        }
        return null;
    }

    public String m92e(int i) {
        return C0108h.m849a(this.f68Q, i);
    }

    public Bitmap m93f(String str) {
        try {
            InputStream open = f51f.getAssets().open(str);
            Bitmap decodeStream = BitmapFactory.decodeStream(open);
            try {
                open.close();
                return decodeStream;
            } catch (Exception e) {
                return decodeStream;
            }
        } catch (Exception e2) {
            return null;
        }
    }

    public String m94f(int i) {
        return C0108h.m849a(this.f69R, i);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean m95f() {
        /*
        r6 = this;
        r2 = 0;
        r0 = "initChipData Start.";
        com.iprog.p006g.C0104d.m830a(r0);
        r0 = f51f;
        r0 = r0.getAssets();
        r1 = "data/rp3_chip_info.dat";
        r1 = r0.open(r1);	 Catch:{ Exception -> 0x0241, all -> 0x0237 }
        r3 = new java.io.BufferedReader;	 Catch:{ Exception -> 0x0244, all -> 0x023b }
        r0 = new java.io.InputStreamReader;	 Catch:{ Exception -> 0x0244, all -> 0x023b }
        r0.<init>(r1);	 Catch:{ Exception -> 0x0244, all -> 0x023b }
        r3.<init>(r0);	 Catch:{ Exception -> 0x0244, all -> 0x023b }
        r0 = "";
        r0 = r6.f83o;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0.clear();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = r6.f84p;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0.clear();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = r6.f85q;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0.clear();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = r6.f86r;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0.clear();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = r6.f87s;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0.clear();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = r6.f63L;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0.clear();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = r6.f64M;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0.clear();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = r6.f63L;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0.clear();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
    L_0x0046:
        r2 = r3.readLine();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        if (r2 != 0) goto L_0x0186;
    L_0x004c:
        r0 = r6.f83o;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r2 = r0.iterator();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
    L_0x0052:
        r0 = r2.hasNext();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        if (r0 != 0) goto L_0x01e6;
    L_0x0058:
        r0 = r6.f84p;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r2 = r0.iterator();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
    L_0x005e:
        r0 = r2.hasNext();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        if (r0 != 0) goto L_0x021a;
    L_0x0064:
        com.iprog.p006g.C0108h.m854a(r3);
        com.iprog.p006g.C0108h.m855a(r1);
        r0 = r6.f62K;
        java.util.Collections.sort(r0);
        r0 = r6.f64M;
        java.util.Collections.sort(r0);
        r0 = r6.f63L;
        java.util.Collections.sort(r0);
        r0 = r6.f65N;
        java.util.Collections.sort(r0);
        r0 = r6.f67P;
        java.util.Collections.sort(r0);
        r0 = r6.f66O;
        java.util.Collections.sort(r0);
        r0 = new java.lang.StringBuilder;
        r1 = "Load All   Chip size:";
        r0.<init>(r1);
        r1 = r6.f83o;
        r1 = r1.size();
        r0 = r0.append(r1);
        r0 = r0.toString();
        com.iprog.p006g.C0104d.m830a(r0);
        r0 = new java.lang.StringBuilder;
        r1 = "Load Reset Chip size:";
        r0.<init>(r1);
        r1 = r6.f84p;
        r1 = r1.size();
        r0 = r0.append(r1);
        r0 = r0.toString();
        com.iprog.p006g.C0104d.m830a(r0);
        r0 = new java.lang.StringBuilder;
        r1 = "Load Check Chip size:";
        r0.<init>(r1);
        r1 = r6.f86r;
        r1 = r1.size();
        r0 = r0.append(r1);
        r0 = r0.toString();
        com.iprog.p006g.C0104d.m830a(r0);
        r0 = new java.lang.StringBuilder;
        r1 = "Load Read  Chip size:";
        r0.<init>(r1);
        r1 = r6.f85q;
        r1 = r1.size();
        r0 = r0.append(r1);
        r0 = r0.toString();
        com.iprog.p006g.C0104d.m830a(r0);
        r0 = new java.lang.StringBuilder;
        r1 = "Load CP LIST reset size:";
        r0.<init>(r1);
        r1 = r6.f62K;
        r1 = r1.size();
        r0 = r0.append(r1);
        r0 = r0.toString();
        com.iprog.p006g.C0104d.m830a(r0);
        r0 = new java.lang.StringBuilder;
        r1 = "Load CP LIST check size:";
        r0.<init>(r1);
        r1 = r6.f64M;
        r1 = r1.size();
        r0 = r0.append(r1);
        r0 = r0.toString();
        com.iprog.p006g.C0104d.m830a(r0);
        r0 = new java.lang.StringBuilder;
        r1 = "Load CP LIST read  size:";
        r0.<init>(r1);
        r1 = r6.f63L;
        r1 = r1.size();
        r0 = r0.append(r1);
        r0 = r0.toString();
        com.iprog.p006g.C0104d.m830a(r0);
        r0 = new java.lang.StringBuilder;
        r1 = "Load CP LIST Xerox reset size:";
        r0.<init>(r1);
        r1 = r6.f65N;
        r1 = r1.size();
        r0 = r0.append(r1);
        r0 = r0.toString();
        com.iprog.p006g.C0104d.m830a(r0);
        r0 = new java.lang.StringBuilder;
        r1 = "Load CP LIST Xerox check size:";
        r0.<init>(r1);
        r1 = r6.f67P;
        r1 = r1.size();
        r0 = r0.append(r1);
        r0 = r0.toString();
        com.iprog.p006g.C0104d.m830a(r0);
        r0 = new java.lang.StringBuilder;
        r1 = "Load CP LIST Xerox read  size:";
        r0.<init>(r1);
        r1 = r6.f66O;
        r1 = r1.size();
        r0 = r0.append(r1);
        r0 = r0.toString();
        com.iprog.p006g.C0104d.m830a(r0);
        r0 = r6.f84p;
        r1 = r0.iterator();
    L_0x017e:
        r0 = r1.hasNext();
        if (r0 != 0) goto L_0x0229;
    L_0x0184:
        r0 = 1;
    L_0x0185:
        return r0;
    L_0x0186:
        r0 = new com.iprog.d.a;	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r4 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r5 = java.lang.String.valueOf(r2);	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r4.<init>(r5);	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r5 = " ";
        r4 = r4.append(r5);	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r4 = r4.toString();	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r0.<init>(r4);	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r4 = r0.m150a();	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r4 = r6.m45k(r4);	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r0.f121H = r4;	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r4 = r0.f129c;	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r4 = r6.m92e(r4);	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r0.f130d = r4;	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r6.m37a(r0);	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        r6.m40b(r0);	 Catch:{ Exception -> 0x01b8, all -> 0x0212 }
        goto L_0x0046;
    L_0x01b8:
        r0 = move-exception;
        r4 = "/**************Data file load Error**********************/";
        com.iprog.p006g.C0104d.m830a(r4);	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r4 = "Data File Error";
        com.iprog.p006g.C0104d.m829a(r0, r4);	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r4 = "ERROR CHIP:";
        r0.<init>(r4);	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = r0.append(r2);	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = r0.toString();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        com.iprog.p006g.C0104d.m830a(r0);	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        goto L_0x0046;
    L_0x01d7:
        r0 = move-exception;
        r2 = r3;
    L_0x01d9:
        r3 = "initChipData";
        com.iprog.p006g.C0104d.m829a(r0, r3);	 Catch:{ all -> 0x023e }
        com.iprog.p006g.C0108h.m854a(r2);
        com.iprog.p006g.C0108h.m855a(r1);
        r0 = 0;
        goto L_0x0185;
    L_0x01e6:
        r0 = r2.next();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = (com.iprog.p003d.C0030f) r0;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r4 = r0.m171a();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        if (r4 == 0) goto L_0x01fe;
    L_0x01f2:
        r4 = r6.f85q;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r4.add(r0);	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r4 = r6.f63L;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r5 = r0.f168b;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r6.m73a(r4, r5);	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
    L_0x01fe:
        r4 = r0.m174b();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        if (r4 == 0) goto L_0x0052;
    L_0x0204:
        r4 = r6.f86r;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r4.add(r0);	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r4 = r6.f64M;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = r0.f168b;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r6.m73a(r4, r0);	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        goto L_0x0052;
    L_0x0212:
        r0 = move-exception;
    L_0x0213:
        com.iprog.p006g.C0108h.m854a(r3);
        com.iprog.p006g.C0108h.m855a(r1);
        throw r0;
    L_0x021a:
        r0 = r2.next();	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = (com.iprog.p003d.C0030f) r0;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r4 = r6.f62K;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r0 = r0.f168b;	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        r6.m73a(r4, r0);	 Catch:{ Exception -> 0x01d7, all -> 0x0212 }
        goto L_0x005e;
    L_0x0229:
        r0 = r1.next();
        r0 = (com.iprog.p003d.C0030f) r0;
        r2 = r0.f174h;
        if (r2 == 0) goto L_0x017e;
    L_0x0233:
        r0 = r0.f173g;
        goto L_0x017e;
    L_0x0237:
        r0 = move-exception;
        r1 = r2;
        r3 = r2;
        goto L_0x0213;
    L_0x023b:
        r0 = move-exception;
        r3 = r2;
        goto L_0x0213;
    L_0x023e:
        r0 = move-exception;
        r3 = r2;
        goto L_0x0213;
    L_0x0241:
        r0 = move-exception;
        r1 = r2;
        goto L_0x01d9;
    L_0x0244:
        r0 = move-exception;
        goto L_0x01d9;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.iprog.b.d.f():boolean");
    }

    public String m96g(int i) {
        return C0108h.m849a(this.f70S, i);
    }

    public boolean m97g() {
        return m67a((int) R.xml.errorcode, this.f73V);
    }

    public String m98h(String str) {
        return String.format("%s/manager/proc/%s", new Object[]{"http://iprog.tncore.com", str});
    }

    public ArrayList m99h(int i) {
        ArrayList arrayList = new ArrayList();
        C0010a.m13a();
        Iterator it = this.f83o.iterator();
        while (it.hasNext()) {
            C0030f c0030f = (C0030f) it.next();
            if (i == 0) {
                Object obj = null;
                for (int i2 = 80; i2 <= 89; i2++) {
                    if (c0030f.m172a(i2)) {
                        obj = 1;
                        break;
                    }
                }
                if (obj == null) {
                    arrayList.add(c0030f);
                }
            } else if (c0030f.m172a(i)) {
                arrayList.add(c0030f);
            }
        }
        C0104d.m830a("Model Count From Credit Type:" + i + " ,Total:" + arrayList.size());
        return arrayList;
    }

    public boolean m100h() {
        return m81b((int) R.xml.nat_cd, this.f69R);
    }

    public ArrayList m101i(int i) {
        ArrayList arrayList;
        Iterator it;
        C0030f c0030f;
        switch (i) {
            case 1:
            case 2:
            case 7:
                if (!this.f61J || this.f58G == 0) {
                    return this.f62K;
                }
                arrayList = new ArrayList();
                it = this.f87s.iterator();
                while (it.hasNext()) {
                    m73a(arrayList, ((C0030f) it.next()).f168b);
                }
                return arrayList;
            case 5:
                if (!this.f61J || this.f58G == 0) {
                    return this.f64M;
                }
                arrayList = new ArrayList();
                it = this.f83o.iterator();
                while (it.hasNext()) {
                    c0030f = (C0030f) it.next();
                    if (c0030f.m174b()) {
                        m73a(arrayList, c0030f.f168b);
                    }
                }
                return arrayList;
            case 6:
                if (!this.f61J || this.f58G == 0) {
                    return this.f63L;
                }
                arrayList = new ArrayList();
                it = this.f83o.iterator();
                while (it.hasNext()) {
                    c0030f = (C0030f) it.next();
                    if (c0030f.m174b()) {
                        m73a(arrayList, c0030f.f168b);
                    }
                }
                return arrayList;
            default:
                this.al.clear();
                return this.al;
        }
    }

    public void m102i(String str) {
        String[] split = str.split("\\.");
        this.f93y = ((Integer.parseInt(split[1]) & 255) | ((Integer.parseInt(split[0]) & 255) << 8)) & 65535;
    }

    public boolean m103i() {
        return m81b((int) R.xml.cp_cd, this.f68Q);
    }

    public int m104j(String str) {
        int i = 0;
        String[] split = str.split("\\.");
        try {
            return ((Integer.parseInt(split[1]) & 255) | ((Integer.parseInt(split[0]) & 255) << 8)) & 65535;
        } catch (Exception e) {
            return i;
        }
    }

    public ArrayList m105j(int i) {
        Object arrayList = new ArrayList();
        for (int i2 = 0; i2 < this.f87s.size(); i2++) {
            arrayList.add(new C0035k((C0030f) this.f87s.get(i2), 0, 1));
        }
        Collections.sort(arrayList, f45Y);
        return arrayList;
    }

    public boolean m106j() {
        return m67a((int) R.xml.credit_type, this.f72U);
    }

    public C0030f m107k(int i) {
        return m91e(String.valueOf(i));
    }

    public boolean m108k() {
        HashMap hashMap = new HashMap();
        boolean c = m87c((int) R.xml.device, hashMap);
        if (c) {
            String str = (String) hashMap.get("oem");
            if (str != null) {
                f43W = str.toUpperCase();
            }
        }
        return c;
    }

    public C0030f m109l(int i) {
        if (this.f83o == null || i < 1) {
            return null;
        }
        Iterator it = this.f83o.iterator();
        while (it.hasNext()) {
            C0030f c0030f = (C0030f) it.next();
            if (C0108h.m844a(c0030f.f167a) == i) {
                return c0030f;
            }
        }
        return null;
    }

    public boolean m110l() {
        return f43W.equals("CM");
    }

    public String m111m() {
        return m98h("rp3_process.jsp");
    }

    public void m112m(int i) {
        new Thread(new C0020k(this, i)).start();
    }

    public String m113n() {
        return m111m();
    }

    public String m114o() {
        return String.format("%s/manager/pc/rp3_vcheck.jsp", new Object[]{"http://iprog.tncore.com"});
    }

    public String m115p() {
        return String.format("%s.%s", new Object[]{m131x(this.f93y), m131x(this.f91w)});
    }

    public String m116p(int i) {
        String str = (String) this.f73V.get(Integer.valueOf(i));
        if (str != null) {
            return str;
        }
        try {
            return new StringBuilder(String.valueOf((String) this.f73V.get(Integer.valueOf(24999)))).append("(").append(i).append(")").toString();
        } catch (Exception e) {
            return "";
        }
    }

    public String m117q() {
        return this.f55D;
    }

    public String m118q(int i) {
        String str = (String) this.f73V.get(Integer.valueOf(i));
        if (str != null) {
            return new StringBuilder(String.valueOf(str)).append("(").append(i).append(")").toString();
        }
        try {
            return new StringBuilder(String.valueOf((String) this.f73V.get(Integer.valueOf(24999)))).append("(").append(i).append(")").toString();
        } catch (Exception e) {
            return "error(" + i + ")";
        }
    }

    public String m119r() {
        return m133z(C0108h.m844a(this.f55D));
    }

    public void m120r(int i) {
        if (i == 65535) {
            i = 0;
        }
        this.f91w = i;
    }

    public void m121s(int i) {
        if (i == 65535) {
            i = 0;
        }
        this.f92x = i;
    }

    public boolean m122s() {
        return this.f81m;
    }

    public String m123t() {
        return this.ae;
    }

    public void m124t(int i) {
        if (i == 65535) {
            i = 259;
        }
        this.f94z = i;
    }

    public String m125u() {
        return this.af;
    }

    public void m126u(int i) {
        if (i == 65535 || i == 0 || i == 1) {
            i = 0;
        }
        this.f53B = i;
    }

    public int m127v() {
        return this.ac;
    }

    public void m128v(int i) {
        if (i == 65535) {
            i = 0;
        }
        this.f52A = i;
    }

    public void m129w(int i) {
        if (i < 18 || i > 47) {
            i = 17;
        }
        this.f54C = i;
    }

    public boolean m130w() {
        return this.f53B == 161 && this.f91w >= 1792 && this.f91w <= 2047;
    }

    public String m131x(int i) {
        return String.format("%d.%d", new Object[]{Integer.valueOf((65280 & i) >> 8), Integer.valueOf(i & 255)});
    }

    public int m132y(int i) {
        return (i == 5 || i == 6 || i == 7) ? i : 0;
    }

    public String m133z(int i) {
        byte[] a = C0108h.m859a(i);
        return String.format("%02X-%02X-%02X-%02X", new Object[]{Byte.valueOf(a[0]), Byte.valueOf(a[1]), Byte.valueOf(a[2]), Byte.valueOf(a[3])});
    }
}
