package com.iprog.p001b;

import com.iprog.p003d.C0035k;
import java.util.Comparator;

class C0015f implements Comparator {
    C0015f() {
    }

    public int m135a(C0035k c0035k, C0035k c0035k2) {
        return c0035k.f206a.f171e.compareToIgnoreCase(c0035k2.f206a.f171e);
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m135a((C0035k) obj, (C0035k) obj2);
    }
}
