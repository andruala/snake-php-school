package com.iprog.p001b;

import com.iprog.p004f.ac;

class C0022m implements Runnable {
    final /* synthetic */ C0013d f104a;
    private final /* synthetic */ ac f105b;
    private final /* synthetic */ int f106c;

    C0022m(C0013d c0013d, ac acVar, int i) {
        this.f104a = c0013d;
        this.f105b = acVar;
        this.f106c = i;
    }

    public void run() {
        this.f104a.m62a(this.f105b, this.f106c);
    }
}
