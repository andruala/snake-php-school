package com.iprog.view;

import android.database.ContentObserver;
import android.os.Handler;

class bn extends ContentObserver {
    final /* synthetic */ DigitalClock f1030a;

    public bn(DigitalClock digitalClock) {
        this.f1030a = digitalClock;
        super(new Handler());
    }

    public void onChange(boolean z) {
        this.f1030a.m883a();
    }
}
