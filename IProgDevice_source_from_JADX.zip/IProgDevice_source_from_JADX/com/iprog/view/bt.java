package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class bt implements OnClickListener {
    final /* synthetic */ bs f1043a;

    bt(bs bsVar) {
        this.f1043a = bsVar;
    }

    public void onClick(View view) {
        this.f1043a.hide();
        if (this.f1043a.f1034c != null) {
            this.f1043a.f1034c.mo21a(this.f1043a.f1042k, 0);
        }
    }
}
