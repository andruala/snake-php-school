package com.iprog.view;

import android.os.Handler;
import android.os.Message;

class C0120o extends Handler {
    final /* synthetic */ C0119n f1078a;

    C0120o(C0119n c0119n) {
        this.f1078a = c0119n;
    }

    public void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                this.f1078a.f1068a.setSelectionFromTop(this.f1078a.f1073f - 1, 0);
                return;
            default:
                return;
        }
    }
}
