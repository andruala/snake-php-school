package com.iprog.view;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.iprog.p003d.C0031g;

class az implements OnItemClickListener {
    final /* synthetic */ ay f998a;

    az(ay ayVar) {
        this.f998a = ayVar;
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        if (this.f998a.f989c != null) {
            this.f998a.f989c.mo26a(((C0031g) this.f998a.f987a.getAdapter().getItem(i)).f175a);
        }
        this.f998a.hide();
    }
}
