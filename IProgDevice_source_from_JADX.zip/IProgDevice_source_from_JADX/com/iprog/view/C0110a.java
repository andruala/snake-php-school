package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class C0110a implements OnClickListener {
    final /* synthetic */ CalcView f904a;

    C0110a(CalcView calcView) {
        this.f904a = calcView;
    }

    public void onClick(View view) {
        int id = view.getId();
        int i = 0;
        while (i < this.f904a.f865b.length) {
            if (id != this.f904a.f865b[i]) {
                i++;
            } else if (this.f904a.f867d != null) {
                this.f904a.f867d.mo29a(i);
                return;
            } else {
                return;
            }
        }
    }
}
