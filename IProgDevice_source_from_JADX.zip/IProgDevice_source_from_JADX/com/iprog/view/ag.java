package com.iprog.view;

import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import com.iprog.p006g.C0104d;

class ag implements OnSeekBarChangeListener {
    final /* synthetic */ ad f935a;

    ag(ad adVar) {
        this.f935a = adVar;
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        C0104d.m831a("onProgressChanged:", i);
        this.f935a.m910d(i);
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}
