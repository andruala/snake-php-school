package com.iprog.view;

import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import com.iprog.p006g.C0104d;

class be implements OnSeekBarChangeListener {
    final /* synthetic */ bb f1008a;

    be(bb bbVar) {
        this.f1008a = bbVar;
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        C0104d.m831a("onProgressChanged", i);
        this.f1008a.f1000b.setStreamVolume(3, i, 4);
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}
