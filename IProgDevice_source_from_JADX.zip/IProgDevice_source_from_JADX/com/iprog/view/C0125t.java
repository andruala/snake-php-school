package com.iprog.view;

class C0125t implements C0048b {
    final /* synthetic */ C0123r f1103a;

    C0125t(C0123r c0123r) {
        this.f1103a = c0123r;
    }

    public void mo29a(int i) {
        if (i == 10) {
            this.f1103a.f1099q.m891a();
        } else if (i == 11) {
            this.f1103a.f1099q.m894b();
        } else {
            this.f1103a.f1099q.m893a(Integer.toString(i));
        }
        this.f1103a.setList(this.f1103a.f1099q.getData());
    }
}
