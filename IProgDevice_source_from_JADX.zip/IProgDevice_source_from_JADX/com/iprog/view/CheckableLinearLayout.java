package com.iprog.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Checkable;
import android.widget.LinearLayout;
import com.iprog.device.R;
import com.iprog.p006g.C0104d;

public class CheckableLinearLayout extends LinearLayout implements Checkable {
    int f877a = R.id.ck_select;
    Checkable f878b;

    public CheckableLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean isChecked() {
        this.f878b = (Checkable) findViewById(R.id.ck_select);
        return this.f878b == null ? false : this.f878b.isChecked();
    }

    public void setChecked(boolean z) {
        this.f878b = (Checkable) findViewById(R.id.ck_select);
        if (this.f878b != null) {
            this.f878b.setChecked(z);
        }
    }

    public void toggle() {
        this.f878b = (Checkable) findViewById(R.id.ck_select);
        C0104d.m831a("toogle:", this.f878b.hashCode());
        if (this.f878b != null) {
            this.f878b.toggle();
        }
    }
}
