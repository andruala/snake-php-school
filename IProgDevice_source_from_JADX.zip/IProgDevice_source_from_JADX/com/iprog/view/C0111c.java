package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class C0111c implements OnClickListener {
    final /* synthetic */ CheckBoxEx f1045a;

    C0111c(CheckBoxEx checkBoxEx) {
        this.f1045a = checkBoxEx;
    }

    public void onClick(View view) {
        if (this.f1045a.f870c.isChecked()) {
            this.f1045a.f870c.setChecked(false);
        } else {
            this.f1045a.f870c.setChecked(true);
        }
        this.f1045a.m877a(this.f1045a.f870c.isChecked());
    }
}
