package com.iprog.view;

import java.util.ArrayList;

public interface bo {
    void mo39a(ArrayList arrayList, int i);

    void mo40b();

    void mo41b(ArrayList arrayList, int i);

    void setData(ArrayList arrayList);

    void setSelection(int i);
}
