package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class C0118l implements OnClickListener {
    final /* synthetic */ C0116j f1067a;

    C0118l(C0116j c0116j) {
        this.f1067a = c0116j;
    }

    public void onClick(View view) {
        if (this.f1067a.f1054e.size() > 0) {
            this.f1067a.m981d();
        }
    }
}
