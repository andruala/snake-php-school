package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.p001b.C0013d;
import com.iprog.p006g.C0104d;

public class al extends Dialog {
    Button f951a = null;
    TextView f952b = null;
    TextView f953c = null;
    TextView f954d = null;
    TextView f955e = null;
    Context f956f = null;
    an f957g = null;
    int f958h = 0;
    int f959i = 0;
    int f960j = 0;
    OnClickListener f961k = new am(this);
    private TextView f962l = null;
    private String f963m = "";

    public al(Context context) {
        super(context);
        this.f956f = context;
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setGravity(17);
    }

    public void m919a(int i, int i2, int i3) {
        this.f959i = i;
        this.f958h = i2;
        this.f960j = i3;
        if (this.f952b != null) {
            this.f952b.setText(C0013d.m47o(i2));
        }
        if (this.f953c != null) {
            if (this.f959i == 0) {
                this.f953c.setText(R.string.credit_type);
            } else {
                this.f953c.setText("Type " + String.valueOf(this.f959i));
            }
        }
        if (this.f955e != null) {
            if (this.f959i == 0) {
                this.f955e.setText("");
            } else {
                C0104d.m830a("SetData:" + i3);
                this.f955e.setText(C0013d.m42d().m89d(i3) ? getContext().getString(R.string.online_charge) : getContext().getString(R.string.online_not_charge));
            }
        }
        if (this.f954d != null) {
            this.f954d.setText(C0013d.m42d().m85c(this.f959i));
        }
    }

    public void m920a(an anVar) {
        this.f957g = anVar;
    }

    public void hide() {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dlg_credit_status);
        this.f953c = (TextView) findViewById(R.id.tv_type);
        this.f954d = (TextView) findViewById(R.id.tv_series);
        this.f952b = (TextView) findViewById(R.id.tv_credit);
        this.f955e = (TextView) findViewById(R.id.tv_online);
        this.f951a = (Button) findViewById(R.id.btn_yes);
        this.f951a.setOnClickListener(this.f961k);
        m919a(this.f959i, this.f958h, this.f960j);
        setCanceledOnTouchOutside(false);
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 19 || i == 20 || i == 20) {
            return false;
        }
        if (i != 4) {
            return super.onKeyDown(i, keyEvent);
        }
        hide();
        return false;
    }

    public void show() {
        if (!isShowing()) {
            super.show();
        }
    }
}
