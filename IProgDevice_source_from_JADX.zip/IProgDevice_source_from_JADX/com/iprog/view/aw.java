package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class aw implements OnClickListener {
    final /* synthetic */ ar f986a;

    aw(ar arVar) {
        this.f986a = arVar;
    }

    public void onClick(View view) {
        String charSequence = this.f986a.f976f.getText().toString();
        if (charSequence.length() > 1) {
            this.f986a.f976f.setText(charSequence.substring(0, charSequence.length() - 1));
        } else {
            this.f986a.f976f.setText("");
        }
    }
}
