package com.iprog.view;

public interface C0050m {
    void mo31a(int i, String str);
}
