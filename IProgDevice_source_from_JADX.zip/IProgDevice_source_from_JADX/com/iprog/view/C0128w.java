package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class C0128w implements OnClickListener {
    final /* synthetic */ C0123r f1104a;

    C0128w(C0123r c0123r) {
        this.f1104a = c0123r;
    }

    public void onClick(View view) {
        this.f1104a.m992a(0);
    }
}
