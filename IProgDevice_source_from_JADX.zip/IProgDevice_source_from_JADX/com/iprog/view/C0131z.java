package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class C0131z implements OnClickListener {
    final /* synthetic */ C0123r f1107a;

    C0131z(C0123r c0123r) {
        this.f1107a = c0123r;
    }

    public void onClick(View view) {
        this.f1107a.f1086d.mo38a(-1, "");
    }
}
