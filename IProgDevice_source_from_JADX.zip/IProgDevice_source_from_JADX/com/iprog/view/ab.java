package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.device.R;

class ab implements OnClickListener {
    final /* synthetic */ aa f926a;

    ab(aa aaVar) {
        this.f926a = aaVar;
    }

    public void onClick(View view) {
        int i = 0;
        if (view.getId() == R.id.btn_yes) {
            i = 1;
        }
        this.f926a.hide();
        if (this.f926a.f916l != null) {
            this.f926a.f916l.mo17a(i);
        }
    }
}
