package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.device.R;

class ae implements OnClickListener {
    final /* synthetic */ ad f933a;

    ae(ad adVar) {
        this.f933a = adVar;
    }

    public void onClick(View view) {
        if (view.getId() == R.id.btn_up) {
            this.f933a.f927a.setProgress(Math.min(this.f933a.f927a.getProgress() + 25, 255));
        } else {
            this.f933a.f927a.setProgress(Math.max(this.f933a.f927a.getProgress() - 25, 0));
        }
    }
}
