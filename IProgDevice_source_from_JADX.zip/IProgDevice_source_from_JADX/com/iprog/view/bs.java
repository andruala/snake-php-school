package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.iprog.device.R;

public class bs extends Dialog {
    boolean f1032a = false;
    LinearLayout f1033b = null;
    bu f1034c = null;
    OnClickListener f1035d = new bt(this);
    private LinearLayout f1036e = null;
    private int f1037f = 0;
    private TextView f1038g = null;
    private TextView f1039h = null;
    private String f1040i = "";
    private String f1041j = "";
    private int f1042k = 0;

    public bs(Context context) {
        super(context);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setGravity(17);
    }

    public void m948a(int i) {
        this.f1042k = i;
    }

    public void m949a(bu buVar) {
        this.f1034c = buVar;
    }

    public void m950a(String str) {
        this.f1040i = str;
    }

    public void m951a(boolean z) {
        this.f1032a = z;
        if (this.f1033b == null) {
            return;
        }
        if (z) {
            this.f1033b.setVisibility(0);
        } else {
            this.f1033b.setVisibility(8);
        }
    }

    public void m952b(String str) {
        this.f1041j = str;
    }

    public void hide() {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dlg_progress);
        this.f1036e = (LinearLayout) findViewById(R.id.ll_content);
        this.f1038g = (TextView) findViewById(R.id.tv_body);
        this.f1039h = (TextView) findViewById(R.id.tv_title);
        this.f1033b = (LinearLayout) findViewById(R.id.ly_btn);
        if (this.f1032a) {
            this.f1033b.setVisibility(0);
        } else {
            this.f1033b.setVisibility(8);
        }
        if (this.f1037f != 0) {
            this.f1036e.addView(((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(this.f1037f, null), new LayoutParams(-1, -1));
        }
        this.f1038g.setText(this.f1041j);
        this.f1039h.setText(this.f1040i);
        ((Button) findViewById(R.id.btn_cancel)).setOnClickListener(this.f1035d);
        setCanceledOnTouchOutside(false);
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return (i == 19 || i == 20 || i == 20 || i == 4) ? false : super.onKeyDown(i, keyEvent);
    }

    public void show() {
        if (!isShowing()) {
            super.show();
        }
    }
}
