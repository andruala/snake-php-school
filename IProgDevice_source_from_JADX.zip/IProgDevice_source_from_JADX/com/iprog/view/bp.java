package com.iprog.view;

public interface bp {
    void mo38a(int i, String str);
}
