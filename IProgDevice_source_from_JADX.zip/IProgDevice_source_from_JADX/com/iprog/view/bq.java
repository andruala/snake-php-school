package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class bq implements OnClickListener {
    final /* synthetic */ IProgItem f1031a;

    bq(IProgItem iProgItem) {
        this.f1031a = iProgItem;
    }

    public void onClick(View view) {
        if (this.f1031a.f895e != null) {
            this.f1031a.f895e.mo24a(this.f1031a.getId(), 0);
        }
    }
}
