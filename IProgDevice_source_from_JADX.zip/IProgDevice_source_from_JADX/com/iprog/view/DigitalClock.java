package com.iprog.view;

import android.content.Context;
import android.os.Handler;
import android.provider.Settings.System;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.widget.TextView;
import java.util.Calendar;

public class DigitalClock extends TextView {
    Calendar f885a;
    String f886b;
    private bn f887c;
    private Runnable f888d;
    private Handler f889e;
    private boolean f890f = false;

    public DigitalClock(Context context) {
        super(context);
        m884a(context);
    }

    public DigitalClock(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m884a(context);
    }

    private void m883a() {
        if (get24HourMode()) {
            this.f886b = "yyyy-MM-dd k:mm:ss";
        } else {
            this.f886b = "yyyy-MM-dd h:mm:ss aa";
        }
    }

    private void m884a(Context context) {
        if (this.f885a == null) {
            this.f885a = Calendar.getInstance();
        }
        this.f887c = new bn(this);
        getContext().getContentResolver().registerContentObserver(System.CONTENT_URI, true, this.f887c);
        m883a();
    }

    private boolean get24HourMode() {
        return DateFormat.is24HourFormat(getContext());
    }

    protected void onAttachedToWindow() {
        this.f890f = false;
        super.onAttachedToWindow();
        this.f889e = new Handler();
        this.f888d = new bm(this);
        this.f888d.run();
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f890f = true;
    }
}
