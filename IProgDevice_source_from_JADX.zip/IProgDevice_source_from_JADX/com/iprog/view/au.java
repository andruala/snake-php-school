package com.iprog.view;

import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

class au implements OnCheckedChangeListener {
    final /* synthetic */ ar f984a;

    au(ar arVar) {
        this.f984a = arVar;
    }

    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        int i = 97;
        if (z) {
            i = 65;
        }
        for (int i2 = 0; i2 < this.f984a.f972b.length; i2++) {
            this.f984a.f972b[i2].setText(String.valueOf((char) (i + i2)));
        }
    }
}
