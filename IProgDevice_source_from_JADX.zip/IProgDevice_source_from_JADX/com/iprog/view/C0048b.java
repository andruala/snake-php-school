package com.iprog.view;

public interface C0048b {
    void mo29a(int i);
}
