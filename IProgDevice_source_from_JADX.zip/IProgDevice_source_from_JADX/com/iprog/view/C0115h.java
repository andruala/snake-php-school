package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class C0115h implements OnClickListener {
    final /* synthetic */ ChipSearchView f1049a;

    C0115h(ChipSearchView chipSearchView) {
        this.f1049a = chipSearchView;
    }

    public void onClick(View view) {
        this.f1049a.m880a(-10);
    }
}
