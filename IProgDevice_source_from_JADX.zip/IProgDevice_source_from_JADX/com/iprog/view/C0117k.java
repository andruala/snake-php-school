package com.iprog.view;

class C0117k implements bp {
    final /* synthetic */ C0116j f1066a;

    C0117k(C0116j c0116j) {
        this.f1066a = c0116j;
    }

    public void mo38a(int i, String str) {
        this.f1066a.m983e();
        if (i >= 0) {
            this.f1066a.f1063n = i;
            if (this.f1066a.f1051b != null) {
                this.f1066a.f1051b.setText(this.f1066a.m956f(this.f1066a.f1063n));
            }
            if (this.f1066a.f1062m != null) {
                this.f1066a.f1062m.mo31a(i, this.f1066a.m956f(this.f1066a.f1063n));
            }
        }
    }
}
