package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class C0129x implements OnClickListener {
    final /* synthetic */ C0123r f1105a;

    C0129x(C0123r c0123r) {
        this.f1105a = c0123r;
    }

    public void onClick(View view) {
        this.f1105a.m992a(-10);
    }
}
