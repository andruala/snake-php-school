package com.iprog.view;

import android.os.Handler;
import android.os.Message;

class C0124s extends Handler {
    final /* synthetic */ C0123r f1102a;

    C0124s(C0123r c0123r) {
        this.f1102a = c0123r;
    }

    public void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                this.f1102a.f1093k.setSelectionFromTop(this.f1102a.f1087e - 1, 0);
                return;
            default:
                return;
        }
    }
}
