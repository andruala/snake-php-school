package com.iprog.view;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.p000a.C0003d;
import java.util.ArrayList;

public class C0119n extends LinearLayout implements bo {
    ListView f1068a = null;
    Button f1069b = null;
    ArrayList f1070c = new ArrayList();
    C0003d f1071d = null;
    bp f1072e = null;
    int f1073f = 0;
    LinearLayout f1074g = null;
    final int f1075h = 1;
    Handler f1076i = new C0120o(this);
    private TextView f1077j = null;

    public C0119n(Context context) {
        super(context);
        m986a();
    }

    public void m986a() {
        ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(R.layout.dlg_popup_list, this, true);
        this.f1068a = (ListView) findViewById(R.id.lv_list);
        this.f1069b = (Button) findViewById(R.id.btn_cancel);
        this.f1077j = (TextView) findViewById(R.id.tv_title);
        this.f1071d = new C0003d(getContext(), R.layout.dlg_popup_list_item);
        this.f1068a.setItemsCanFocus(false);
        this.f1068a.setChoiceMode(1);
        this.f1069b.setOnClickListener(new C0121p(this));
        this.f1068a.setOnItemClickListener(new C0122q(this));
    }

    public void mo39a(ArrayList arrayList, int i) {
        this.f1070c.clear();
        this.f1070c.addAll(arrayList);
        this.f1071d.m6a(arrayList, i);
        this.f1068a.setAdapter(this.f1071d);
        this.f1076i.sendEmptyMessageDelayed(1, 70);
    }

    public void mo40b() {
    }

    public void mo41b(ArrayList arrayList, int i) {
    }

    public void setData(ArrayList arrayList) {
        this.f1070c.clear();
        this.f1070c.addAll(arrayList);
        this.f1071d.m5a(arrayList);
        this.f1068a.setAdapter(this.f1071d);
        this.f1076i.sendEmptyMessageDelayed(1, 70);
    }

    public void setOnMessageListener(bp bpVar) {
        this.f1072e = bpVar;
    }

    public void setSelection(int i) {
        this.f1071d.m4a(i);
        this.f1073f = i;
    }

    public void setTitle(int i) {
        this.f1077j.setText(getContext().getString(i));
    }

    public void setTitle(String str) {
        this.f1077j.setText(str);
    }
}
