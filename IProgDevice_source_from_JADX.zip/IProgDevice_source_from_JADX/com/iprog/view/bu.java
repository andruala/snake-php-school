package com.iprog.view;

public interface bu {
    void mo21a(int i, int i2);
}
