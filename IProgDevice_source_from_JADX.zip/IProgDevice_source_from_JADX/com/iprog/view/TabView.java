package com.iprog.view;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.LinearLayout;
import com.iprog.device.R;
import com.iprog.p006g.C0104d;
import java.util.ArrayList;

public class TabView extends LinearLayout {
    Button[] f899a;
    int f900b;
    public final int f901c;
    bw f902d;
    int f903e;

    public TabView(Context context) {
        super(context);
        this.f899a = new Button[3];
        this.f900b = 0;
        this.f901c = 3;
        this.f902d = null;
        this.f903e = -1;
        m896a();
    }

    public TabView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f899a = new Button[3];
        this.f900b = 0;
        this.f901c = 3;
        this.f902d = null;
        this.f903e = -1;
        m896a();
    }

    private int m895a(int i) {
        return i == 0 ? R.id.btn_tab1 : i == 1 ? R.id.btn_tab2 : i == 2 ? R.id.btn_tab3 : 0;
    }

    private void m896a() {
        ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(R.layout.view_tab, this, true);
        if (!isInEditMode()) {
            this.f899a[0] = (Button) findViewById(R.id.btn_tab1);
            this.f899a[1] = (Button) findViewById(R.id.btn_tab2);
            this.f899a[2] = (Button) findViewById(R.id.btn_tab3);
            for (int i = 0; i < this.f899a.length; i++) {
                if (this.f899a[i] != null) {
                    this.f899a[i].setOnTouchListener(new bv(this));
                }
            }
        }
    }

    private void m897a(Button button, boolean z) {
        if (z) {
            button.setTextAppearance(getContext(), R.style.style_tab_text_on);
        } else {
            button.setTextAppearance(getContext(), R.style.style_tab_text_off);
        }
    }

    private void m899b(int i) {
        this.f900b = i;
        switch (i) {
            case R.id.btn_tab1:
                this.f902d.mo27a(0);
                return;
            case R.id.btn_tab2:
                this.f902d.mo27a(1);
                return;
            case R.id.btn_tab3:
                this.f902d.mo27a(2);
                return;
            default:
                return;
        }
    }

    protected void onDraw(Canvas canvas) {
        if (!isInEditMode()) {
            super.onDraw(canvas);
        }
    }

    public void setOnClickListener(bw bwVar) {
        this.f902d = bwVar;
    }

    public void setTabImage(int i) {
        switch (i) {
            case R.id.btn_tab1:
                this.f899a[0].setBackgroundResource(R.drawable.img_tab1_on);
                this.f899a[1].setBackgroundResource(R.drawable.img_tab2_off);
                this.f899a[2].setBackgroundResource(R.drawable.img_tab3_off);
                m897a(this.f899a[0], true);
                m897a(this.f899a[1], false);
                m897a(this.f899a[2], false);
                return;
            case R.id.btn_tab2:
                this.f899a[0].setBackgroundResource(R.drawable.img_tab1_off);
                this.f899a[1].setBackgroundResource(R.drawable.img_tab2_on);
                this.f899a[2].setBackgroundResource(R.drawable.img_tab3_off);
                m897a(this.f899a[0], false);
                m897a(this.f899a[1], true);
                m897a(this.f899a[2], false);
                return;
            case R.id.btn_tab3:
                this.f899a[0].setBackgroundResource(R.drawable.img_tab1_off);
                this.f899a[1].setBackgroundResource(R.drawable.img_tab2_off);
                this.f899a[2].setBackgroundResource(R.drawable.img_tab3_on);
                m897a(this.f899a[0], false);
                m897a(this.f899a[1], false);
                m897a(this.f899a[2], true);
                return;
            default:
                return;
        }
    }

    public void setTabIndex(int i) {
        C0104d.m830a("setTabIndex:" + i);
        setTabImage(m895a(i));
        this.f900b = m895a(i);
    }

    public void setTitle(ArrayList arrayList) {
        int i = 0;
        while (i < arrayList.size() && i < this.f899a.length) {
            this.f899a[i].setText((CharSequence) arrayList.get(i));
            i++;
        }
    }

    public void setTitle(int[] iArr) {
        int i = 0;
        while (i < iArr.length && i < this.f899a.length) {
            this.f899a[i].setText(iArr[i]);
            i++;
        }
    }

    public void setTitle(String[] strArr) {
        int i = 0;
        while (i < strArr.length && i < this.f899a.length) {
            this.f899a[i].setText(strArr[i]);
            i++;
        }
    }
}
