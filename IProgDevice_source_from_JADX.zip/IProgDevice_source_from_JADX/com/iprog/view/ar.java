package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ToggleButton;
import com.iprog.device.R;

public class ar extends Dialog {
    Button[] f971a = null;
    Button[] f972b = null;
    Button f973c = null;
    int[] f974d = new int[]{R.id.btn_0, R.id.btn_1, R.id.btn_2, R.id.btn_3, R.id.btn_4, R.id.btn_5, R.id.btn_6, R.id.btn_7, R.id.btn_8, R.id.btn_9};
    int[] f975e = new int[]{R.id.btn_a, R.id.btn_b, R.id.btn_c, R.id.btn_d, R.id.btn_e, R.id.btn_f, R.id.btn_g, R.id.btn_h, R.id.btn_i, R.id.btn_j, R.id.btn_k, R.id.btn_l, R.id.btn_m, R.id.btn_n, R.id.btn_o, R.id.btn_p, R.id.btn_q, R.id.btn_r, R.id.btn_s, R.id.btn_t, R.id.btn_u, R.id.btn_v, R.id.btn_w, R.id.btn_x, R.id.btn_y, R.id.btn_z};
    TextView f976f = null;
    ToggleButton f977g = null;
    OnClickListener f978h = new as(this);
    OnClickListener f979i = new at(this);
    ax f980j = null;
    View f981k = null;

    public ar(Context context) {
        super(context);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setGravity(17);
    }

    public void m923a(ax axVar, View view) {
        this.f980j = axVar;
        this.f981k = view;
    }

    public void m924a(String str) {
        if (this.f976f != null) {
            this.f976f.setText(str);
        }
        if (!isShowing()) {
            super.show();
        }
    }

    public void hide() {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void onCreate(Bundle bundle) {
        int i = 0;
        super.onCreate(bundle);
        setContentView(R.layout.view_keyboard);
        this.f971a = new Button[this.f974d.length];
        this.f972b = new Button[this.f975e.length];
        this.f976f = (TextView) findViewById(R.id.tv_text);
        this.f977g = (ToggleButton) findViewById(R.id.tb_cap);
        this.f973c = (Button) findViewById(R.id.btn_back);
        for (int i2 = 0; i2 < this.f974d.length; i2++) {
            this.f971a[i2] = (Button) findViewById(this.f974d[i2]);
            this.f971a[i2].setOnClickListener(this.f978h);
        }
        while (i < this.f975e.length) {
            this.f972b[i] = (Button) findViewById(this.f975e[i]);
            this.f972b[i].setOnClickListener(this.f979i);
            i++;
        }
        this.f977g.setOnCheckedChangeListener(new au(this));
        ((Button) findViewById(R.id.btn_enter)).setOnClickListener(new av(this));
        this.f973c.setOnClickListener(new aw(this));
    }

    public void show() {
        if (this.f976f != null) {
            this.f976f.setText("");
        }
        if (!isShowing()) {
            super.show();
        }
    }
}
