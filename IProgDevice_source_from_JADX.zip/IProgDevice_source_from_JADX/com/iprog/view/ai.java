package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.iprog.device.R;

public class ai extends Dialog {
    Button f936a = null;
    Button f937b = null;
    Button f938c = null;
    ImageView f939d = null;
    ImageView f940e = null;
    int f941f = 1;
    ak f942g = null;
    OnClickListener f943h = new aj(this);
    private LinearLayout f944i = null;
    private int f945j = 0;
    private TextView f946k = null;
    private TextView f947l = null;
    private String f948m = "";
    private String f949n = "";

    public ai(Context context) {
        super(context);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setGravity(17);
    }

    private void m912a() {
        switch (this.f941f) {
            case 1:
                this.f936a.setText(R.string.dlg_btn_yes);
                m913a(this.f936a, true);
                m913a(this.f937b, true);
                m913a(this.f938c, false);
                m913a(this.f939d, true);
                m913a(this.f940e, false);
                return;
            case 2:
                this.f936a.setText(R.string.dlg_btn_confirm);
                m913a(this.f936a, true);
                m913a(this.f937b, false);
                m913a(this.f938c, false);
                m913a(this.f939d, false);
                m913a(this.f940e, false);
                return;
            case 3:
                m913a(this.f936a, false);
                m913a(this.f937b, false);
                m913a(this.f938c, true);
                m913a(this.f939d, false);
                m913a(this.f940e, false);
                return;
            default:
                return;
        }
    }

    private void m913a(View view, boolean z) {
        if (z) {
            view.setVisibility(0);
        } else {
            view.setVisibility(8);
        }
    }

    public void m914a(int i) {
        this.f949n = getContext().getString(i);
        if (this.f946k != null) {
            this.f946k.setText(this.f949n);
        }
    }

    public void m915a(ak akVar) {
        this.f942g = akVar;
    }

    public void m916a(String str) {
        this.f948m = str;
        if (this.f947l != null) {
            this.f947l.setText(this.f948m);
        }
    }

    public void m917b(int i) {
        this.f941f = i;
    }

    public void m918b(String str) {
        this.f949n = str;
        if (this.f946k != null) {
            this.f946k.setText(this.f949n);
        }
    }

    public void hide() {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dlg_confirm);
        this.f944i = (LinearLayout) findViewById(R.id.ll_content);
        this.f946k = (TextView) findViewById(R.id.tv_body);
        this.f947l = (TextView) findViewById(R.id.tv_title);
        this.f939d = (ImageView) findViewById(R.id.img_line1);
        this.f940e = (ImageView) findViewById(R.id.img_line2);
        this.f946k.setMovementMethod(ScrollingMovementMethod.getInstance());
        if (this.f945j != 0) {
            this.f944i.addView(((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(this.f945j, null), new LayoutParams(-1, -1));
        } else {
            this.f946k.setText(this.f949n);
        }
        this.f947l.setText(this.f948m);
        this.f936a = (Button) findViewById(R.id.btn_yes);
        this.f937b = (Button) findViewById(R.id.btn_no);
        this.f938c = (Button) findViewById(R.id.btn_cancel);
        this.f936a.setOnClickListener(this.f943h);
        this.f937b.setOnClickListener(this.f943h);
        this.f938c.setOnClickListener(this.f943h);
        m912a();
        setCanceledOnTouchOutside(false);
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 19 || i == 20 || i == 20) {
            return false;
        }
        if (i != 4 || this.f941f != 2) {
            return super.onKeyDown(i, keyEvent);
        }
        hide();
        return false;
    }

    public void show() {
        if (!isShowing()) {
            super.show();
        }
    }
}
