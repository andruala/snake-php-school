package com.iprog.view;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

class bv implements OnTouchListener {
    final /* synthetic */ TabView f1044a;

    bv(TabView tabView) {
        this.f1044a = tabView;
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f1044a.f903e = 0;
            this.f1044a.setTabImage(view.getId());
        } else if (motionEvent.getAction() == 1) {
            if (this.f1044a.f903e == 0) {
                this.f1044a.f903e = -1;
                this.f1044a.setTabImage(view.getId());
                this.f1044a.m899b(view.getId());
            }
            this.f1044a.f903e = -1;
        } else if (motionEvent.getAction() != 2) {
            if (this.f1044a.f903e != -1) {
                this.f1044a.setTabImage(this.f1044a.f900b);
            }
            this.f1044a.f903e = -1;
        }
        return true;
    }
}
