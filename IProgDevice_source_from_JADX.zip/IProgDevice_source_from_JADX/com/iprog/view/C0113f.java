package com.iprog.view;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.iprog.p003d.C0035k;

class C0113f implements OnItemClickListener {
    final /* synthetic */ ChipSearchView f1047a;

    C0113f(ChipSearchView chipSearchView) {
        this.f1047a = chipSearchView;
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        if (this.f1047a.f880b != null) {
            this.f1047a.f880b.mo30a((C0035k) this.f1047a.f879a.getAdapter().getItem(i));
        }
    }
}
