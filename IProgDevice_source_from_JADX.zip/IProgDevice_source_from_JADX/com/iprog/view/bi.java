package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.device.R;

class bi implements OnClickListener {
    final /* synthetic */ bg f1016a;

    bi(bg bgVar) {
        this.f1016a = bgVar;
    }

    public void onClick(View view) {
        int i = 0;
        if (view.getId() == R.id.btn_yes) {
            i = 1;
        }
        this.f1016a.hide();
        if (this.f1016a.f1010b != null) {
            this.f1016a.f1010b.m936a(i);
        }
    }
}
