package com.iprog.view;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import com.iprog.device.R;
import com.iprog.device.cv;

public class CalcView extends LinearLayout {
    Button[] f864a;
    int[] f865b;
    OnClickListener f866c;
    private C0048b f867d;

    public CalcView(Context context) {
        super(context);
        this.f864a = new Button[12];
        this.f865b = new int[]{R.id.btn_calc_0, R.id.btn_calc_1, R.id.btn_calc_2, R.id.btn_calc_3, R.id.btn_calc_4, R.id.btn_calc_5, R.id.btn_calc_6, R.id.btn_calc_7, R.id.btn_calc_8, R.id.btn_calc_9, R.id.btn_calc_back, R.id.btn_calc_clr};
        this.f867d = null;
        this.f866c = new C0110a(this);
        m874a(context, null);
    }

    public CalcView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f864a = new Button[12];
        this.f865b = new int[]{R.id.btn_calc_0, R.id.btn_calc_1, R.id.btn_calc_2, R.id.btn_calc_3, R.id.btn_calc_4, R.id.btn_calc_5, R.id.btn_calc_6, R.id.btn_calc_7, R.id.btn_calc_8, R.id.btn_calc_9, R.id.btn_calc_back, R.id.btn_calc_clr};
        this.f867d = null;
        this.f866c = new C0110a(this);
        m874a(context, attributeSet);
    }

    private void m874a(Context context, AttributeSet attributeSet) {
        int i = 0;
        ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(R.layout.view_calc, this, true);
        if (!isInEditMode()) {
            int resourceId = attributeSet != null ? context.obtainStyledAttributes(attributeSet, cv.CalcView).getResourceId(0, 0) : 0;
            while (i < this.f864a.length) {
                this.f864a[i] = (Button) findViewById(this.f865b[i]);
                this.f864a[i].setOnClickListener(this.f866c);
                if (resourceId != 0) {
                    this.f864a[i].setTextAppearance(context, resourceId);
                }
                i++;
            }
        }
    }

    protected void onDraw(Canvas canvas) {
        if (!isInEditMode()) {
            super.onDraw(canvas);
        }
    }

    public void setOnClickListener(C0048b c0048b) {
        this.f867d = c0048b;
    }
}
