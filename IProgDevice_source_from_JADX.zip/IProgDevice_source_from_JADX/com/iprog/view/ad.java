package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.IPowerManager;
import android.os.IPowerManager.Stub;
import android.os.ServiceManager;
import android.provider.Settings.System;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import com.iprog.device.R;
import com.iprog.p006g.C0104d;

public class ad extends Dialog {
    SeekBar f927a = null;
    ah f928b = null;
    OnClickListener f929c = new ae(this);
    OnClickListener f930d = new af(this);
    private LinearLayout f931e = null;
    private int f932f = 0;

    public ad(Context context) {
        super(context);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setGravity(17);
    }

    private int m906a(int i) {
        try {
            i = System.getInt(getContext().getContentResolver(), "screen_brightness_mode");
        } catch (Exception e) {
            C0104d.m829a(e, "getBrightnessMode");
        }
        return i;
    }

    private void m908b(int i) {
        System.putInt(getContext().getContentResolver(), "screen_brightness_mode", i);
    }

    private int m909c(int i) {
        try {
            i = System.getInt(getContext().getContentResolver(), "screen_brightness");
        } catch (Exception e) {
            C0104d.m829a(e, "getBrightness");
        }
        return i;
    }

    private void m910d(int i) {
        try {
            C0104d.m830a("#Power Start.");
            IPowerManager asInterface = Stub.asInterface(ServiceManager.getService("power"));
            if (asInterface != null) {
                asInterface.setBacklightBrightness(i);
            }
            C0104d.m830a("#Power End.");
        } catch (Exception e) {
            C0104d.m829a(e, "setBrightness");
        }
    }

    public void hide() {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dlg_brightness);
        this.f931e = (LinearLayout) findViewById(R.id.ll_content);
        Button button = (Button) findViewById(R.id.btn_down);
        ((Button) findViewById(R.id.btn_up)).setOnClickListener(this.f929c);
        button.setOnClickListener(this.f929c);
        this.f927a = (SeekBar) findViewById(R.id.sb_volumn);
        this.f927a.setOnSeekBarChangeListener(new ag(this));
        if (m906a(1) != 0) {
            m908b(0);
        }
        this.f927a.incrementProgressBy(25);
        this.f927a.setMax(255);
        this.f927a.setProgress(m909c(127));
    }

    public void show() {
        if (!isShowing()) {
            super.show();
        }
    }
}
