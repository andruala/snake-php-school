package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class am implements OnClickListener {
    final /* synthetic */ al f964a;

    am(al alVar) {
        this.f964a = alVar;
    }

    public void onClick(View view) {
        this.f964a.hide();
        if (this.f964a.f957g != null) {
            this.f964a.f957g.mo19a(1);
        }
    }
}
