package com.iprog.view;

import android.os.SystemClock;
import android.text.format.DateFormat;

class bm implements Runnable {
    final /* synthetic */ DigitalClock f1029a;

    bm(DigitalClock digitalClock) {
        this.f1029a = digitalClock;
    }

    public void run() {
        if (!this.f1029a.f890f) {
            this.f1029a.f885a.setTimeInMillis(System.currentTimeMillis());
            this.f1029a.setText(DateFormat.format(this.f1029a.f886b, this.f1029a.f885a));
            this.f1029a.invalidate();
            long uptimeMillis = SystemClock.uptimeMillis();
            this.f1029a.f889e.postAtTime(this.f1029a.f888d, uptimeMillis + (1000 - (uptimeMillis % 1000)));
        }
    }
}
