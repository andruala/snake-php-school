package com.iprog.view;

import android.view.View;

public interface ax {
    void mo16a(String str, View view);
}
