package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class C0114g implements OnClickListener {
    final /* synthetic */ ChipSearchView f1048a;

    C0114g(ChipSearchView chipSearchView) {
        this.f1048a = chipSearchView;
    }

    public void onClick(View view) {
        this.f1048a.m880a(0);
    }
}
