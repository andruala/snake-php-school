package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.p001b.C0013d;
import com.iprog.p006g.C0108h;

public class aa extends Dialog {
    Button f905a = null;
    Button f906b = null;
    Button f907c = null;
    ImageView f908d = null;
    ImageView f909e = null;
    TextView f910f = null;
    TextView f911g = null;
    TextView f912h = null;
    TextView f913i = null;
    int f914j = 1;
    Context f915k = null;
    ac f916l = null;
    String f917m = "";
    String f918n = "";
    int f919o = 0;
    OnClickListener f920p = new ab(this);
    private LinearLayout f921q = null;
    private int f922r = 0;
    private TextView f923s = null;
    private String f924t = "";
    private String f925u = "";

    public aa(Context context) {
        super(context);
        this.f915k = context;
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setGravity(17);
    }

    private void m900a() {
        switch (this.f914j) {
            case 1:
                this.f905a.setText(R.string.dlg_btn_yes);
                m901a(this.f905a, true);
                m901a(this.f906b, true);
                m901a(this.f907c, false);
                m901a(this.f908d, true);
                m901a(this.f909e, false);
                return;
            case 2:
                this.f905a.setText(R.string.dlg_btn_confirm);
                m901a(this.f905a, true);
                m901a(this.f906b, false);
                m901a(this.f907c, false);
                m901a(this.f908d, false);
                m901a(this.f909e, false);
                return;
            case 3:
                m901a(this.f905a, false);
                m901a(this.f906b, false);
                m901a(this.f907c, true);
                m901a(this.f908d, false);
                m901a(this.f909e, false);
                return;
            default:
                return;
        }
    }

    private void m901a(View view, boolean z) {
        if (z) {
            try {
                view.setVisibility(0);
                return;
            } catch (Exception e) {
                return;
            }
        }
        view.setVisibility(8);
    }

    public void m902a(int i) {
        this.f914j = i;
    }

    public void m903a(ac acVar) {
        this.f916l = acVar;
    }

    public void m904a(String str) {
        this.f924t = str;
        if (this.f923s != null) {
            this.f923s.setText(this.f924t);
        }
    }

    public void m905a(String str, String str2, int i) {
        this.f917m = str;
        this.f918n = str2;
        this.f919o = i;
        if (this.f910f != null) {
            if (i >= 110) {
                i -= 110;
            }
            if (i == 0) {
                this.f912h.setText(R.string.credit_type);
            } else {
                this.f912h.setText("Type " + i);
            }
            if (this.f910f != null) {
                this.f910f.setText(C0013d.m47o(C0108h.m844a(str)));
            }
            if (this.f911g != null) {
                this.f911g.setText(str2);
            }
        }
    }

    public void hide() {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.credit_confirm);
        this.f921q = (LinearLayout) findViewById(R.id.ll_content);
        this.f923s = (TextView) findViewById(R.id.tv_title);
        this.f913i = (TextView) findViewById(R.id.tv_msg);
        this.f908d = (ImageView) findViewById(R.id.img_line1);
        this.f909e = (ImageView) findViewById(R.id.img_line2);
        this.f910f = (TextView) findViewById(R.id.tv_credit);
        this.f911g = (TextView) findViewById(R.id.tv_buy_date);
        this.f912h = (TextView) findViewById(R.id.tv_credit_type);
        this.f923s.setText(this.f924t);
        this.f905a = (Button) findViewById(R.id.btn_yes);
        this.f906b = (Button) findViewById(R.id.btn_no);
        this.f907c = (Button) findViewById(R.id.btn_cancel);
        this.f905a.setOnClickListener(this.f920p);
        this.f906b.setOnClickListener(this.f920p);
        this.f907c.setOnClickListener(this.f920p);
        this.f910f.setText(C0013d.m47o(C0108h.m844a(this.f917m)));
        this.f911g.setText(this.f918n);
        m900a();
        m905a(this.f917m, this.f918n, this.f919o);
        setCanceledOnTouchOutside(false);
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return (i == 19 || i == 20 || i == 20 || i == 4) ? false : super.onKeyDown(i, keyEvent);
    }

    public void show() {
        if (!isShowing()) {
            super.show();
        }
    }
}
