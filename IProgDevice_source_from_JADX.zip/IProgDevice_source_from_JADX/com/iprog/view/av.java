package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class av implements OnClickListener {
    final /* synthetic */ ar f985a;

    av(ar arVar) {
        this.f985a = arVar;
    }

    public void onClick(View view) {
        if (this.f985a.f980j != null && this.f985a.f981k != null) {
            this.f985a.f980j.mo16a(this.f985a.f976f.getText().toString(), this.f985a.f981k);
            this.f985a.hide();
        }
    }
}
