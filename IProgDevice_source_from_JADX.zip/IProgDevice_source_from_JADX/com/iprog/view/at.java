package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

class at implements OnClickListener {
    final /* synthetic */ ar f983a;

    at(ar arVar) {
        this.f983a = arVar;
    }

    public void onClick(View view) {
        this.f983a.f976f.setText(this.f983a.f976f.getText() + ((Button) view).getText().toString());
    }
}
