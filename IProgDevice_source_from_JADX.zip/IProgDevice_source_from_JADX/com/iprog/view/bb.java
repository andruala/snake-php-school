package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import com.iprog.device.R;

public class bb extends Dialog {
    SeekBar f999a = null;
    AudioManager f1000b = null;
    bf f1001c = null;
    OnClickListener f1002d = new bc(this);
    OnClickListener f1003e = new bd(this);
    private LinearLayout f1004f = null;
    private int f1005g = 0;

    public bb(Context context) {
        super(context);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setGravity(17);
    }

    public void m935a(bf bfVar) {
        this.f1001c = bfVar;
    }

    public void hide() {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dlg_sound);
        this.f1004f = (LinearLayout) findViewById(R.id.ll_content);
        if (this.f1005g != 0) {
            this.f1004f.addView(((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(this.f1005g, null), new LayoutParams(-1, -1));
        }
        Button button = (Button) findViewById(R.id.btn_no);
        Button button2 = (Button) findViewById(R.id.btn_down);
        ((Button) findViewById(R.id.btn_up)).setOnClickListener(this.f1002d);
        button2.setOnClickListener(this.f1002d);
        this.f1000b = (AudioManager) getContext().getSystemService("audio");
        this.f999a = (SeekBar) findViewById(R.id.sb_volumn);
        this.f999a.setMax(this.f1000b.getStreamMaxVolume(3));
        this.f999a.setProgress(this.f1000b.getStreamVolume(3));
        this.f999a.incrementProgressBy(1);
        this.f999a.setOnSeekBarChangeListener(new be(this));
    }

    public void show() {
        if (!isShowing()) {
            super.show();
        }
    }
}
