package com.iprog.view;

class ap implements br {
    final /* synthetic */ ao f970a;

    ap(ao aoVar) {
        this.f970a = aoVar;
    }

    public void mo24a(int i, int i2) {
        this.f970a.hide();
        if (this.f970a.f966b != null) {
            this.f970a.f966b.mo25a(i);
        }
    }
}
