package com.iprog.view;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.p000a.C0005f;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0025a;
import com.iprog.p003d.C0028d;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class C0123r extends LinearLayout implements bo {
    private static Comparator f1081t = new C0126u();
    private static Comparator f1082u = new C0127v();
    ListView f1083a = null;
    Button f1084b = null;
    ArrayList f1085c = new ArrayList();
    bp f1086d = null;
    int f1087e = 0;
    Button f1088f = null;
    Button f1089g = null;
    ArrayList f1090h = new ArrayList();
    final int f1091i = 1;
    Handler f1092j = new C0124s(this);
    ListView f1093k = null;
    C0048b f1094l = new C0125t(this);
    final int f1095m = 0;
    final int f1096n = -10;
    private TextView f1097o = null;
    private CalcView f1098p = null;
    private SearchTextView f1099q = null;
    private C0005f f1100r = null;
    private C0013d f1101s = null;

    public C0123r(Context context) {
        super(context);
        m995a();
    }

    private ArrayList m991a(String str) {
        List arrayList = new ArrayList();
        int i;
        if (str.isEmpty()) {
            for (i = 0; i < this.f1090h.size(); i++) {
                arrayList.add(new C0028d((C0025a) this.f1090h.get(i), i, 0, 1));
            }
            Collections.sort(arrayList, f1081t);
        } else {
            for (i = 0; i < this.f1090h.size(); i++) {
                int indexOf = ((C0025a) this.f1090h.get(i)).f132f.indexOf(str);
                if (indexOf >= 0) {
                    arrayList.add(new C0028d((C0025a) this.f1090h.get(i), i, indexOf, 1));
                } else {
                    indexOf = ((C0025a) this.f1090h.get(i)).f133g.indexOf(str);
                    if (indexOf >= 0) {
                        arrayList.add(new C0028d((C0025a) this.f1090h.get(i), i, indexOf, 0));
                    }
                }
            }
            Collections.sort(arrayList, f1082u);
        }
        return arrayList;
    }

    private void m992a(int i) {
        this.f1093k.setSelectionFromTop(Math.max(this.f1093k.getLastVisiblePosition() + i, 0), 0);
    }

    private void setList(String str) {
        this.f1100r.m7a(m991a(str));
        this.f1093k.setAdapter(this.f1100r);
    }

    public void m995a() {
        ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(R.layout.dlg_search_model, this, true);
        this.f1098p = (CalcView) findViewById(R.id.s_calcview);
        this.f1099q = (SearchTextView) findViewById(R.id.ly_search_text);
        this.f1099q.setLayoutView(R.layout.view_search_text_black);
        this.f1100r = new C0005f(getContext(), R.layout.view_combox_search_item);
        this.f1101s = C0013d.m42d();
        this.f1088f = (Button) findViewById(R.id.btn_next);
        this.f1089g = (Button) findViewById(R.id.btn_prev);
        this.f1093k = (ListView) findViewById(R.id.lv_search_item);
        this.f1098p.setOnClickListener(this.f1094l);
        this.f1097o = (TextView) findViewById(R.id.tv_title);
        this.f1088f.setOnClickListener(new C0128w(this));
        this.f1089g.setOnClickListener(new C0129x(this));
        this.f1093k.setOnItemClickListener(new C0130y(this));
        this.f1084b = (Button) findViewById(R.id.btn_cancel);
        this.f1084b.setOnClickListener(new C0131z(this));
    }

    public void mo39a(ArrayList arrayList, int i) {
    }

    public void mo40b() {
        this.f1099q.m894b();
        setList("");
        this.f1092j.sendEmptyMessageDelayed(1, 70);
    }

    public void mo41b(ArrayList arrayList, int i) {
        this.f1090h.clear();
        this.f1090h.addAll(arrayList);
        this.f1099q.m894b();
        setList("");
        this.f1087e = i;
        this.f1092j.sendEmptyMessageDelayed(1, 70);
    }

    public void setData(ArrayList arrayList) {
    }

    public void setOnMessageListener(bp bpVar) {
        this.f1086d = bpVar;
    }

    public void setSelection(int i) {
        this.f1087e = i;
    }

    public void setTitle(int i) {
        this.f1097o.setText(getContext().getString(i));
    }

    public void setTitle(String str) {
        this.f1097o.setText(str);
    }
}
