package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import com.iprog.device.R;

public class bg extends Dialog {
    SeekBar f1009a = null;
    bj f1010b = null;
    OnClickListener f1011c = new bh(this);
    OnClickListener f1012d = new bi(this);
    private LinearLayout f1013e = null;
    private int f1014f = 0;

    public bg(Context context) {
        super(context);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setGravity(17);
    }

    public void hide() {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dlg_time);
        this.f1013e = (LinearLayout) findViewById(R.id.ll_content);
        if (this.f1014f != 0) {
            this.f1013e.addView(((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(this.f1014f, null), new LayoutParams(-1, -1));
        }
        Button button = (Button) findViewById(R.id.btn_no);
        ((Button) findViewById(R.id.btn_yes)).setOnClickListener(this.f1012d);
        button.setOnClickListener(this.f1012d);
    }

    public void show() {
        if (!isShowing()) {
            super.show();
        }
    }
}
