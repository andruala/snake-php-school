package com.iprog.view;

import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

class C0112d implements OnCheckedChangeListener {
    final /* synthetic */ CheckBoxEx f1046a;

    C0112d(CheckBoxEx checkBoxEx) {
        this.f1046a = checkBoxEx;
    }

    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        this.f1046a.m877a(z);
    }
}
