package com.iprog.view;

import com.iprog.p004f.C0099y;

public interface ba {
    void mo26a(C0099y c0099y);
}
