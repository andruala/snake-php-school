package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.device.R;
import com.iprog.p006g.C0107g;

class bh implements OnClickListener {
    final /* synthetic */ bg f1015a;

    bh(bg bgVar) {
        this.f1015a = bgVar;
    }

    public void onClick(View view) {
        if (view.getId() == R.id.btn_up) {
            this.f1015a.f1009a.setProgress(Math.min(this.f1015a.f1009a.getProgress() + 1, this.f1015a.f1009a.getMax()));
        } else {
            this.f1015a.f1009a.setProgress(Math.max(this.f1015a.f1009a.getProgress() - 1, 0));
        }
        C0107g.m839a().m840a(1);
    }
}
