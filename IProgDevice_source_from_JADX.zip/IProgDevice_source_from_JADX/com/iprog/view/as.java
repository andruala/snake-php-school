package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

class as implements OnClickListener {
    final /* synthetic */ ar f982a;

    as(ar arVar) {
        this.f982a = arVar;
    }

    public void onClick(View view) {
        this.f982a.f976f.setText(this.f982a.f976f.getText() + ((Button) view).getText().toString());
    }
}
