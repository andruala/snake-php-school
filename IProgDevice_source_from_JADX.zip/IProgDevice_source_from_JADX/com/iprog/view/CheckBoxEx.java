package com.iprog.view;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.iprog.device.R;

public class CheckBoxEx extends LinearLayout implements Checkable {
    int f868a = 0;
    ImageView f869b = null;
    CheckBox f870c = null;
    ProgressBar f871d = null;
    TextView f872e = null;
    String f873f = "";
    C0058e f874g = null;
    OnCheckedChangeListener f875h = null;
    OnClickListener f876i = new C0111c(this);

    public CheckBoxEx(Context context) {
        super(context);
        m875c();
    }

    public CheckBoxEx(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        for (int i = 0; i < attributeSet.getAttributeCount(); i++) {
            String attributeName = attributeSet.getAttributeName(i);
            if (attributeName != null) {
                if (attributeName.equalsIgnoreCase("checkbox_icon")) {
                    this.f868a = attributeSet.getAttributeResourceValue(i, 0);
                } else if (attributeName.equalsIgnoreCase("checkbox_text")) {
                    this.f873f = attributeSet.getAttributeValue(i);
                    if (this.f873f.indexOf("@") == 0) {
                        this.f873f = context.getResources().getString(attributeSet.getAttributeResourceValue(i, 0));
                    }
                }
            }
        }
        m875c();
    }

    private void m875c() {
        ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(R.layout.view_checkbox, this, true);
        try {
            this.f869b = (ImageView) findViewById(R.id.img_icon);
            this.f870c = (CheckBox) findViewById(R.id.cb_check);
            this.f871d = (ProgressBar) findViewById(R.id.pb_icon);
            this.f872e = (TextView) findViewById(R.id.tv_title);
            if (this.f868a != 0) {
                this.f869b.setImageResource(this.f868a);
            } else {
                this.f869b.setImageBitmap(null);
            }
            this.f872e.setText(this.f873f);
            this.f869b.setVisibility(0);
            this.f871d.setVisibility(4);
            this.f869b.setOnClickListener(this.f876i);
            this.f872e.setOnClickListener(this.f876i);
            this.f870c.setOnCheckedChangeListener(new C0112d(this));
        } catch (Exception e) {
        }
    }

    public void m876a() {
        this.f869b.setVisibility(4);
        this.f871d.setVisibility(0);
    }

    void m877a(boolean z) {
        if (this.f874g != null) {
            this.f874g.mo34a(getId(), z);
        }
    }

    public void m878b() {
        this.f869b.setVisibility(0);
        this.f871d.setVisibility(4);
    }

    public boolean isChecked() {
        try {
            if (this.f870c.isEnabled() && this.f870c.isChecked()) {
                return true;
            }
        } catch (Exception e) {
        }
        return false;
    }

    protected void onDraw(Canvas canvas) {
        if (!isInEditMode()) {
            super.onDraw(canvas);
        }
    }

    public void setChecked(boolean z) {
        try {
            if (this.f870c.isEnabled()) {
                this.f870c.setChecked(z);
            } else {
                this.f870c.setChecked(false);
            }
        } catch (Exception e) {
        }
    }

    public void setEnabled(boolean z) {
        this.f870c.setEnabled(z);
        this.f872e.setEnabled(z);
        if (z) {
            this.f872e.setTextAppearance(getContext(), R.style.style_checkboxex_title);
        } else {
            this.f870c.setChecked(false);
            this.f872e.setTextAppearance(getContext(), R.style.style_checkboxex_title_disable);
        }
        this.f869b.setEnabled(z);
        super.setEnabled(z);
    }

    public void setICon(int i) {
        this.f868a = i;
        if (this.f869b == null) {
            return;
        }
        if (i == 0) {
            this.f869b.setImageBitmap(null);
        } else {
            this.f869b.setImageResource(this.f868a);
        }
    }

    public void setOnClickListener(C0058e c0058e) {
        this.f874g = c0058e;
    }

    public void setText(int i) {
        if (this.f872e != null) {
            this.f872e.setText(i);
        }
    }

    public void setText(String str) {
        if (this.f872e != null) {
            this.f872e.setText(str);
        }
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
    }

    public void toggle() {
    }
}
