package com.iprog.view;

public interface C0058e {
    void mo34a(int i, boolean z);
}
