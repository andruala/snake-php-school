package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.widget.TextView;
import com.iprog.device.R;

public class ao extends Dialog {
    IProgItem[] f965a = new IProgItem[3];
    aq f966b = null;
    br f967c = new ap(this);
    private TextView f968d = null;
    private String f969e = "";

    public ao(Context context) {
        super(context);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setGravity(17);
    }

    public void m921a(aq aqVar) {
        this.f966b = aqVar;
    }

    public void hide() {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dlg_folder_etc);
        this.f965a[0] = (IProgItem) findViewById(R.id.menu_chip_check);
        this.f965a[1] = (IProgItem) findViewById(R.id.menu_job_log);
        this.f965a[2] = (IProgItem) findViewById(R.id.menu_chip_read_list);
        this.f965a[0].setOnClickListener(this.f967c);
        this.f965a[1].setOnClickListener(this.f967c);
        this.f965a[2].setOnClickListener(this.f967c);
    }

    public void show() {
        if (!isShowing()) {
            super.show();
        }
    }
}
