package com.iprog.view;

import com.iprog.p003d.C0028d;
import java.util.Comparator;

class C0126u implements Comparator {
    C0126u() {
    }

    public int m1000a(C0028d c0028d, C0028d c0028d2) {
        return c0028d.f159a.f132f.compareToIgnoreCase(c0028d2.f159a.f132f);
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m1000a((C0028d) obj, (C0028d) obj2);
    }
}
