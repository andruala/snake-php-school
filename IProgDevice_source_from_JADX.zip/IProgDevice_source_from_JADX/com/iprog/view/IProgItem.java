package com.iprog.view;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.iprog.device.R;

public class IProgItem extends LinearLayout {
    int f891a = 0;
    ImageView f892b = null;
    TextView f893c = null;
    String f894d = "";
    br f895e = null;

    public IProgItem(Context context) {
        super(context);
        m889a();
    }

    public IProgItem(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        for (int i = 0; i < attributeSet.getAttributeCount(); i++) {
            String attributeName = attributeSet.getAttributeName(i);
            if (attributeName != null) {
                if (attributeName.equalsIgnoreCase("item_image")) {
                    this.f891a = attributeSet.getAttributeResourceValue(i, 0);
                } else if (attributeName.equalsIgnoreCase("item_name")) {
                    this.f894d = attributeSet.getAttributeValue(i);
                    if (this.f894d.indexOf("@") == 0) {
                        this.f894d = context.getResources().getString(attributeSet.getAttributeResourceValue(i, 0));
                    }
                }
            }
        }
        m889a();
    }

    private void m889a() {
        ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(R.layout.view_iprogitem, this, true);
        try {
            this.f892b = (ImageView) findViewById(R.id.img_view);
            this.f893c = (TextView) findViewById(R.id.tv_name);
            this.f892b.setImageResource(this.f891a);
            this.f893c.setText(this.f894d);
            this.f892b.setOnClickListener(new bq(this));
        } catch (Exception e) {
        }
    }

    public int getId() {
        return super.getId();
    }

    protected void onDraw(Canvas canvas) {
        if (!isInEditMode()) {
            super.onDraw(canvas);
        }
    }

    public void setOnClickListener(br brVar) {
        this.f895e = brVar;
    }
}
