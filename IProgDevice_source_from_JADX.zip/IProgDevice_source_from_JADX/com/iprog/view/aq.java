package com.iprog.view;

public interface aq {
    void mo25a(int i);
}
