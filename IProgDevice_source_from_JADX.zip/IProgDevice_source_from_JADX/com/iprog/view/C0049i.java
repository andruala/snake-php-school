package com.iprog.view;

import com.iprog.p003d.C0035k;

public interface C0049i {
    void mo30a(C0035k c0035k);
}
