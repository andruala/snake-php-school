package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.device.R;

class bd implements OnClickListener {
    final /* synthetic */ bb f1007a;

    bd(bb bbVar) {
        this.f1007a = bbVar;
    }

    public void onClick(View view) {
        int i = 0;
        if (view.getId() == R.id.btn_yes) {
            i = 1;
        }
        this.f1007a.hide();
        if (this.f1007a.f1001c != null) {
            this.f1007a.f1001c.mo32a(i);
        }
    }
}
