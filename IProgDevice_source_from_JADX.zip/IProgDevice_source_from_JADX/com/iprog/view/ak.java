package com.iprog.view;

public interface ak {
    void mo15a(int i);
}
