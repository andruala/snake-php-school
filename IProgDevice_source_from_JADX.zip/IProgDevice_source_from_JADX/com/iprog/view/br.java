package com.iprog.view;

public interface br {
    void mo24a(int i, int i2);
}
