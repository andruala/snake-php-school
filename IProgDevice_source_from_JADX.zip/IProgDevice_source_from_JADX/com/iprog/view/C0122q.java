package com.iprog.view;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.iprog.p006g.C0104d;

class C0122q implements OnItemClickListener {
    final /* synthetic */ C0119n f1080a;

    C0122q(C0119n c0119n) {
        this.f1080a = c0119n;
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        if (i >= 0) {
            try {
                if (i < this.f1080a.f1070c.size()) {
                    this.f1080a.f1071d.m4a(i);
                }
            } catch (Exception e) {
                C0104d.m828a(e);
                this.f1080a.f1072e.mo38a(-1, "");
                return;
            }
        }
        this.f1080a.f1072e.mo38a(i, (String) this.f1080a.f1070c.get(i));
    }
}
