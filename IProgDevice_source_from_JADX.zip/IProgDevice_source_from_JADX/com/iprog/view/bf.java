package com.iprog.view;

public interface bf {
    void mo32a(int i);
}
