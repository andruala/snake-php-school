package com.iprog.view;

public interface bj {
    void m936a(int i);
}
