package com.iprog.view;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.iprog.p003d.C0028d;

class C0130y implements OnItemClickListener {
    final /* synthetic */ C0123r f1106a;

    C0130y(C0123r c0123r) {
        this.f1106a = c0123r;
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        if (this.f1106a.f1086d != null) {
            C0028d c0028d = (C0028d) this.f1106a.f1093k.getAdapter().getItem(i);
            this.f1106a.setSelection(c0028d.f160b);
            this.f1106a.f1086d.mo38a(c0028d.f160b, c0028d.f159a.f132f);
        }
    }
}
