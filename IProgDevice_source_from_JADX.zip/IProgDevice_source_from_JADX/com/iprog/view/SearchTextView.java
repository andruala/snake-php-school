package com.iprog.view;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.device.cv;
import com.iprog.p006g.C0104d;

public class SearchTextView extends LinearLayout {
    private TextView f896a;
    private char[] f897b;
    private int f898c;

    public SearchTextView(Context context) {
        super(context);
        this.f896a = null;
        this.f897b = new char[8];
        this.f898c = 0;
        m890a(context, null);
    }

    public SearchTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f896a = null;
        this.f897b = new char[8];
        this.f898c = 0;
        m890a(context, attributeSet);
    }

    private void m890a(Context context, AttributeSet attributeSet) {
        int i = 0;
        if (attributeSet != null) {
            i = context.obtainStyledAttributes(attributeSet, cv.SearchTextView).getResourceId(0, 0);
        }
        if (i == 0) {
            i = R.layout.view_search_text;
        }
        setLayoutView(i);
        this.f896a = (TextView) findViewById(R.id.tv_search);
    }

    public boolean m891a() {
        if (this.f898c <= 0) {
            return false;
        }
        this.f897b[this.f898c - 1] = '\u0000';
        this.f898c--;
        this.f896a.setText(String.valueOf(this.f897b));
        return true;
    }

    public boolean m892a(char c) {
        if (this.f898c >= this.f897b.length - 1) {
            return false;
        }
        this.f897b[this.f898c] = c;
        this.f898c++;
        this.f896a.setText(String.valueOf(this.f897b));
        return true;
    }

    public boolean m893a(String str) {
        return str.length() > 0 ? m892a(str.charAt(0)) : false;
    }

    public void m894b() {
        for (int i = 0; i < this.f897b.length; i++) {
            this.f897b[i] = '\u0000';
        }
        this.f898c = 0;
        this.f896a.setText("");
    }

    public String getData() {
        return String.valueOf(this.f897b).trim();
    }

    protected void onDraw(Canvas canvas) {
        if (!isInEditMode()) {
            super.onDraw(canvas);
        }
    }

    public void setLayoutView(int i) {
        try {
            ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(i, this, true);
        } catch (Exception e) {
            C0104d.m829a(e, "SearchTextView");
        }
    }
}
