package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.ListView;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.p000a.C0006g;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0030f;
import com.iprog.p003d.C0031g;
import com.iprog.p004f.C0099y;
import com.iprog.p006g.C0104d;
import java.util.ArrayList;

public class ay extends Dialog {
    ListView f987a = null;
    Context f988b = null;
    ba f989c = null;
    int f990d = 0;
    int f991e = 0;
    ArrayList f992f = new ArrayList();
    private TextView f993g = null;
    private TextView f994h = null;
    private String f995i = "";
    private String f996j = "";
    private C0006g f997k = null;

    public ay(Context context) {
        super(context);
        this.f988b = context;
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setGravity(17);
    }

    private void m925d() {
        if (this.f997k != null) {
            this.f997k.m8a(this.f992f);
        }
        if (this.f987a != null) {
            this.f987a.setAdapter(this.f997k);
        }
    }

    public void m926a() {
        this.f992f.clear();
    }

    public void m927a(int i) {
        m932b(this.f988b.getString(i));
    }

    public void m928a(C0099y c0099y) {
        C0104d.m830a("Add Multi Data:" + c0099y.f812c);
        C0013d d = C0013d.m42d();
        C0031g c0031g = new C0031g();
        try {
            C0030f k = d.m107k(c0099y.f812c);
            if (k != null) {
                c0031g.f176b = k.m169a(c0099y.f824o);
                if (c0031g.f176b != null) {
                    c0031g.f175a = c0099y;
                    c0031g.f177c = d.m94f(c0099y.f815f);
                    c0031g.f178d = d.m96g(c0099y.f816g);
                    c0031g.f179e = C0013d.m46n(c0099y.m809x());
                    this.f992f.add(c0031g);
                    return;
                }
            }
        } catch (Exception e) {
        }
        C0104d.m834b("Model Not Found:" + c0099y.f812c);
    }

    public void m929a(ba baVar) {
        this.f989c = baVar;
    }

    public void m930a(String str) {
        this.f995i = str;
        if (this.f993g != null) {
            this.f993g.setText(this.f995i);
        }
    }

    public C0099y m931b(int i) {
        return ((C0031g) this.f992f.get(i)).f175a;
    }

    public void m932b(String str) {
        this.f996j = str;
        if (this.f994h != null) {
            this.f994h.setText(this.f996j);
        }
    }

    public boolean m933b() {
        return this.f992f.isEmpty();
    }

    public int m934c() {
        return this.f992f.size();
    }

    public void hide() {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dlg_multi_model);
        this.f993g = (TextView) findViewById(R.id.tv_title);
        this.f994h = (TextView) findViewById(R.id.tv_msg);
        this.f987a = (ListView) findViewById(R.id.lv_model);
        this.f997k = new C0006g(getContext(), R.layout.view_multi_model_item);
        this.f987a.setOnItemClickListener(new az(this));
        m925d();
        m930a(this.f995i);
        m932b(this.f996j);
        setCanceledOnTouchOutside(false);
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return (i == 19 || i == 20 || i == 20 || i == 4) ? false : super.onKeyDown(i, keyEvent);
    }

    public void setTitle(int i) {
        m930a(this.f988b.getString(i));
    }

    public void show() {
        m925d();
        if (!isShowing()) {
            super.show();
        }
    }
}
