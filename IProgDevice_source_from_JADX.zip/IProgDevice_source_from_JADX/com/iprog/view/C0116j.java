package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.iprog.device.ComboBoxActivity;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.util.ArrayList;
import java.util.Collections;

public class C0116j {
    Context f1050a = null;
    Button f1051b = null;
    int f1052c = 0;
    ArrayList f1053d = new ArrayList();
    ArrayList f1054e = new ArrayList();
    ArrayList f1055f = new ArrayList();
    Dialog f1056g = null;
    Dialog f1057h = null;
    Dialog f1058i = null;
    C0119n f1059j = null;
    C0123r f1060k = null;
    bo f1061l = null;
    C0050m f1062m = null;
    int f1063n = 0;
    bp f1064o = new C0117k(this);
    OnClickListener f1065p = new C0118l(this);

    public C0116j(Context context, Button button, int i) {
        this.f1050a = context;
        this.f1051b = button;
        this.f1052c = i;
        if (this.f1051b != null) {
            this.f1051b.setOnClickListener(this.f1065p);
        }
        this.f1059j = new C0119n(context);
        this.f1060k = new C0123r(context);
        this.f1059j.setOnMessageListener(this.f1064o);
        this.f1060k.setOnMessageListener(this.f1064o);
        this.f1057h = m953a(this.f1059j);
        this.f1058i = m953a(this.f1060k);
        m975b(false);
    }

    private Dialog m953a(View view) {
        Dialog dialog = new Dialog(this.f1050a);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setContentView(view);
        dialog.getWindow().setGravity(17);
        return dialog;
    }

    private void m955e(int i) {
        this.f1055f.clear();
        for (int i2 = 0; i2 < i; i2++) {
            this.f1055f.add(String.valueOf(i2));
        }
    }

    private String m956f(int i) {
        return (String) this.f1054e.get(i);
    }

    public int m957a(int i, String str) {
        return m958a(String.valueOf(i), str);
    }

    public int m958a(String str, String str2) {
        if (m976c(str) < 0) {
            this.f1055f.add(str);
            this.f1054e.add(str2);
            this.f1061l.setData(this.f1054e);
        }
        m976c(str);
        return 1;
    }

    public void m959a() {
        this.f1054e.clear();
        this.f1055f.clear();
        this.f1051b.setText("");
    }

    public void m960a(int i) {
        this.f1059j.setTitle(i);
        this.f1060k.setTitle(i);
    }

    public void m961a(C0050m c0050m) {
        this.f1062m = c0050m;
    }

    public void m962a(String str) {
        this.f1054e.clear();
        this.f1054e.add(str);
        m955e(1);
        this.f1061l.setData(this.f1054e);
    }

    public void m963a(ArrayList arrayList) {
        this.f1054e = arrayList;
        m955e(arrayList.size());
        this.f1061l.setData(arrayList);
    }

    public void m964a(ArrayList arrayList, String str, ArrayList arrayList2) {
        this.f1054e = arrayList;
        m955e(arrayList.size());
        m972b(str);
        this.f1061l.mo39a(arrayList, this.f1063n);
        this.f1061l.mo41b(arrayList2, this.f1063n);
    }

    public void m965a(ArrayList arrayList, ArrayList arrayList2) {
        this.f1054e = arrayList;
        this.f1055f = arrayList2;
        this.f1061l.setData(this.f1054e);
    }

    public void m966a(ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3) {
        C0104d.m830a("setAdapter" + arrayList.size());
        this.f1054e = arrayList;
        this.f1055f = arrayList2;
        this.f1053d = arrayList3;
        this.f1061l.setData(this.f1053d);
    }

    public void m967a(boolean z) {
        this.f1051b.setEnabled(z);
    }

    public void m968a(String[] strArr) {
        this.f1054e.clear();
        Collections.addAll(this.f1054e, strArr);
        m955e(strArr.length);
        this.f1061l.setData(this.f1054e);
    }

    public void m969a(String[] strArr, int[] iArr) {
        this.f1054e.clear();
        Collections.addAll(this.f1054e, strArr);
        this.f1055f = C0108h.m852a(iArr);
        this.f1061l.setData(this.f1054e);
    }

    public void m970a(String[] strArr, String[] strArr2) {
        this.f1054e.clear();
        this.f1055f.clear();
        Collections.addAll(this.f1054e, strArr);
        Collections.addAll(this.f1055f, strArr2);
        this.f1061l.setData(this.f1054e);
    }

    public void m971a(String[] strArr, String[] strArr2, int i) {
        this.f1054e.clear();
        this.f1055f.clear();
        Collections.addAll(this.f1054e, strArr);
        Collections.addAll(this.f1055f, strArr2);
        this.f1061l.mo39a(this.f1054e, i);
    }

    public int m972b(String str) {
        int i = 0;
        while (i < this.f1054e.size()) {
            try {
                if (((String) this.f1054e.get(i)).equalsIgnoreCase(str.trim())) {
                    this.f1063n = i;
                    this.f1051b.setText(str);
                    this.f1061l.setSelection(i);
                    return i;
                }
                i++;
            } catch (Exception e) {
            }
        }
        C0104d.m832a("Warning ComboBoxCtrl.setSelection Not Found", str);
        return -1;
    }

    public String m973b() {
        try {
            if (this.f1051b.getVisibility() == 0) {
                return ((String) this.f1051b.getText()).trim();
            }
        } catch (Exception e) {
        }
        return "";
    }

    public void m974b(int i) {
        try {
            this.f1063n = i;
            this.f1051b.setText(m956f(i));
            this.f1061l.setSelection(this.f1063n);
        } catch (Exception e) {
        }
    }

    public void m975b(boolean z) {
        if (z) {
            this.f1061l = this.f1060k;
            this.f1056g = this.f1058i;
            return;
        }
        this.f1061l = this.f1059j;
        this.f1056g = this.f1057h;
    }

    public int m976c(String str) {
        int i = 0;
        while (i < this.f1055f.size()) {
            try {
                if (((String) this.f1055f.get(i)).equalsIgnoreCase(str)) {
                    this.f1063n = i;
                    this.f1051b.setText(m956f(this.f1063n));
                    this.f1061l.setSelection(i);
                    return i;
                }
                i++;
            } catch (Exception e) {
            }
        }
        C0104d.m832a("Warning ComboBoxCtrl.setValue Not Found", str);
        return -1;
    }

    public String m977c() {
        try {
            if (this.f1051b.getVisibility() == 0 && this.f1063n < this.f1055f.size()) {
                return (String) this.f1055f.get(this.f1063n);
            }
        } catch (Exception e) {
            C0104d.m829a(e, "getValue");
        }
        return "";
    }

    public String m978c(int i) {
        for (int i2 = 0; i2 < this.f1055f.size(); i2++) {
            if (((String) this.f1055f.get(i2)).equals(String.valueOf(i))) {
                return (String) this.f1054e.get(i2);
            }
        }
        return "";
    }

    public int m979d(String str) {
        return (this.f1055f == null || str.isEmpty()) ? -1 : this.f1055f.indexOf(str);
    }

    public String m980d(int i) {
        try {
            if (i < this.f1055f.size()) {
                return (String) this.f1055f.get(i);
            }
        } catch (Exception e) {
            C0104d.m829a(e, "getValue");
        }
        return "";
    }

    public void m981d() {
        new Intent(this.f1050a, ComboBoxActivity.class).addFlags(67108864);
        this.f1061l.mo40b();
        this.f1056g.show();
    }

    public int m982e(String str) {
        return (this.f1054e == null || str.isEmpty()) ? -1 : this.f1054e.indexOf(str);
    }

    public void m983e() {
        if (this.f1056g.isShowing()) {
            this.f1056g.dismiss();
        }
    }

    public boolean m984f() {
        return this.f1056g.isShowing();
    }
}
