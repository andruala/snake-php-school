package com.iprog.view;

public interface bw {
    void mo27a(int i);
}
