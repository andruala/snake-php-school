package com.iprog.view;

public interface ac {
    void mo17a(int i);
}
