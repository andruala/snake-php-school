package com.iprog.view;

import com.iprog.p003d.C0028d;
import java.util.Comparator;

class C0127v implements Comparator {
    C0127v() {
    }

    public int m1001a(C0028d c0028d, C0028d c0028d2) {
        return c0028d.f161c != c0028d2.f161c ? (c0028d.f161c - c0028d2.f161c) * -1 : c0028d.f162d - c0028d2.f162d;
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m1001a((C0028d) obj, (C0028d) obj2);
    }
}
