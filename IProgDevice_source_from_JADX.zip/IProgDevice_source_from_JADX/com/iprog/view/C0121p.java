package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;

class C0121p implements OnClickListener {
    final /* synthetic */ C0119n f1079a;

    C0121p(C0119n c0119n) {
        this.f1079a = c0119n;
    }

    public void onClick(View view) {
        this.f1079a.f1072e.mo38a(-1, "");
    }
}
