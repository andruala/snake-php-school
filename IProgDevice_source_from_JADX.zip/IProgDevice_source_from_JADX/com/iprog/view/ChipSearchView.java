package com.iprog.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.iprog.device.R;
import com.iprog.device.cv;
import com.iprog.p006g.C0104d;
import java.util.ArrayList;

public class ChipSearchView extends LinearLayout {
    ListView f879a = null;
    C0049i f880b = null;
    Button f881c = null;
    Button f882d = null;
    final int f883e = 0;
    final int f884f = -10;

    public ChipSearchView(Context context) {
        super(context);
        m879a();
    }

    public ChipSearchView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m879a();
        m881a(context, attributeSet);
    }

    private void m879a() {
        ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(R.layout.view_chip_search, this, true);
        this.f881c = (Button) findViewById(R.id.btn_next);
        this.f882d = (Button) findViewById(R.id.btn_prev);
        this.f879a = (ListView) findViewById(R.id.lv_search_item);
        if (!isInEditMode()) {
            this.f879a.setOnItemClickListener(new C0113f(this));
            this.f881c.setOnClickListener(new C0114g(this));
            this.f882d.setOnClickListener(new C0115h(this));
        }
    }

    private void m880a(int i) {
        int lastVisiblePosition = this.f879a.getLastVisiblePosition();
        C0104d.m831a("list pos", lastVisiblePosition);
        this.f879a.setSelectionFromTop(Math.max(lastVisiblePosition + i, 0), 0);
    }

    private void m881a(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, cv.ChipSearchView);
        String string = obtainStyledAttributes.getString(0);
        obtainStyledAttributes.getInt(1, 1);
        if (string == null) {
            string = "";
        }
        if (string.equals("bottom")) {
            ((LinearLayout) findViewById(R.id.ll_page_area_right)).setVisibility(8);
        } else {
            ((LinearLayout) findViewById(R.id.ll_page_area_bottom)).setVisibility(8);
        }
    }

    protected void onDraw(Canvas canvas) {
        if (!isInEditMode()) {
            super.onDraw(canvas);
        }
    }

    public void setAdapter(ListAdapter listAdapter) {
        this.f879a.setAdapter(listAdapter);
    }

    public void setData(ArrayList arrayList) {
    }

    public void setOnClickListener(C0049i c0049i) {
        this.f880b = c0049i;
    }
}
