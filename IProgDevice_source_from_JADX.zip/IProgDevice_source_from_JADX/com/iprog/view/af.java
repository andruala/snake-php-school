package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.device.R;

class af implements OnClickListener {
    final /* synthetic */ ad f934a;

    af(ad adVar) {
        this.f934a = adVar;
    }

    public void onClick(View view) {
        int i = 0;
        if (view.getId() == R.id.btn_yes) {
            i = 1;
        }
        this.f934a.hide();
        if (this.f934a.f928b != null) {
            this.f934a.f928b.m911a(i);
        }
    }
}
