package com.iprog.view;

public interface ah {
    void m911a(int i);
}
