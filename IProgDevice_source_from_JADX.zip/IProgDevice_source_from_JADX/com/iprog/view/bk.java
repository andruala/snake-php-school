package com.iprog.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.p006g.C0104d;

public class bk extends Dialog {
    int f1017a = 0;
    bl f1018b = null;
    int f1019c = 0;
    private LinearLayout f1020d = null;
    private int f1021e = 0;
    private TextView f1022f = null;
    private TextView f1023g = null;
    private TextView f1024h = null;
    private String f1025i = "";
    private String f1026j = "";
    private ProgressBar f1027k = null;
    private int f1028l = 0;

    public bk(Context context) {
        super(context);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setGravity(17);
    }

    public int m937a() {
        return this.f1019c;
    }

    public void m938a(int i) {
        this.f1019c = i;
        this.f1017a = 0;
        if (this.f1027k != null) {
            this.f1027k.setMax(this.f1019c);
        }
    }

    public void m939a(String str) {
        this.f1026j = str;
        if (this.f1024h != null) {
            this.f1024h.setText(this.f1026j);
        }
    }

    public int m940b() {
        return this.f1017a;
    }

    public void m941b(int i) {
        this.f1017a += i;
        try {
            if (this.f1027k != null) {
                this.f1027k.setProgress(this.f1017a);
                this.f1023g.setText(String.format("%d%%", new Object[]{Integer.valueOf(Math.min((this.f1017a * 100) / this.f1019c, 100))}));
            }
        } catch (Exception e) {
            C0104d.m829a(e, "update progress");
        }
    }

    public void m942b(String str) {
        this.f1025i = str;
        if (this.f1022f != null) {
            this.f1022f.setText(this.f1025i);
        }
    }

    public void hide() {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dlg_upgrade);
        this.f1020d = (LinearLayout) findViewById(R.id.ll_content);
        this.f1027k = (ProgressBar) findViewById(R.id.pb_status);
        this.f1022f = (TextView) findViewById(R.id.tv_body);
        this.f1024h = (TextView) findViewById(R.id.tv_title);
        this.f1023g = (TextView) findViewById(R.id.tv_status);
        this.f1027k.setMax(this.f1019c);
        this.f1027k.setProgress(this.f1017a);
        this.f1024h.setText(this.f1026j);
        this.f1022f.setText(this.f1025i);
        setCanceledOnTouchOutside(false);
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return (i == 19 || i == 20 || i == 20 || i == 4) ? false : super.onKeyDown(i, keyEvent);
    }

    public void show() {
        if (!isShowing()) {
            super.show();
        }
    }
}
