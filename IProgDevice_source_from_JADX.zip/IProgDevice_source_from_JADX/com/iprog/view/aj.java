package com.iprog.view;

import android.view.View;
import android.view.View.OnClickListener;
import com.iprog.device.R;

class aj implements OnClickListener {
    final /* synthetic */ ai f950a;

    aj(ai aiVar) {
        this.f950a = aiVar;
    }

    public void onClick(View view) {
        int i = 0;
        if (view.getId() == R.id.btn_yes) {
            i = 1;
        }
        this.f950a.hide();
        if (this.f950a.f942g != null) {
            this.f950a.f942g.mo15a(i);
        }
    }
}
