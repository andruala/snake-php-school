package com.iprog.view;

public interface an {
    void mo19a(int i);
}
