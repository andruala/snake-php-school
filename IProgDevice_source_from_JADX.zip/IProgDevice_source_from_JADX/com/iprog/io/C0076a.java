package com.iprog.io;

import com.iprog.p006g.C0104d;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.http.util.ByteArrayBuffer;

public class C0076a {
    protected InputStream f668a = null;
    protected OutputStream f669b = null;
    public boolean f670c = false;
    public boolean f671d = false;
    private Object f672e = new Object();
    private int f673f = 256;

    public void m646a(FileDescriptor fileDescriptor) {
        this.f668a = new FileInputStream(fileDescriptor);
        this.f669b = new FileOutputStream(fileDescriptor);
    }

    public void m647a(InputStream inputStream) {
        if (inputStream != null) {
            try {
                inputStream.close();
            } catch (Exception e) {
            }
        }
    }

    public void m648a(InputStream inputStream, OutputStream outputStream) {
        this.f668a = inputStream;
        this.f669b = outputStream;
    }

    public void m649a(OutputStream outputStream) {
        if (outputStream != null) {
            try {
                outputStream.flush();
            } catch (Exception e) {
            }
            try {
                outputStream.close();
            } catch (Exception e2) {
            }
        }
    }

    public void mo35a(byte[] bArr) {
        new Thread(new C0109b(this, bArr)).start();
    }

    public boolean m651a(byte[] bArr, int i, int i2) {
        synchronized (this.f672e) {
            try {
                if (this.f670c) {
                    C0104d.m830a(String.format("[SEND S][%d]", new Object[]{Integer.valueOf(i2)}));
                }
                int i3 = 0;
                while (i3 < i2) {
                    this.f669b.write(bArr, i3, Math.min(this.f673f, i2 - i3));
                    i3 += this.f673f;
                }
                if (this.f670c) {
                    C0104d.m830a(String.format("[SEND E][%d]", new Object[]{Integer.valueOf(i2)}));
                }
            } catch (Exception e) {
                try {
                    this.f669b.flush();
                } catch (Exception e2) {
                }
                C0104d.m829a(e, "Serial Port Send");
                return false;
            }
        }
        return true;
    }

    public byte[] m652a() {
        ByteArrayBuffer byteArrayBuffer = new ByteArrayBuffer(1024);
        int i = 3;
        while (i > 0) {
            try {
                if (this.f668a.available() > 0) {
                    byte[] bArr = new byte[1024];
                    byteArrayBuffer.append(bArr, 0, this.f668a.read(bArr));
                    i = 3;
                }
                Thread.sleep(20);
                i--;
            } catch (Exception e) {
                C0104d.m829a(e, "readAll");
            }
        }
        return byteArrayBuffer.toByteArray();
    }

    public byte[] m653a(int i) {
        int i2 = 0;
        byte[] bArr = new byte[i];
        while (i2 < i) {
            int read = this.f668a.read(bArr, i2, i - i2);
            if (read < 0) {
                break;
            }
            i2 += read;
        }
        if (i2 == i) {
            return bArr;
        }
        throw new Exception("******** Read length error.....********");
    }

    public byte[] m654a(int i, int i2) {
        Object obj = new byte[i];
        int i3 = 0;
        int i4 = 0;
        while (i4 < i) {
            if (this.f668a.available() > 0) {
                i3 = this.f668a.read(obj, i4, i - i4);
                if (i3 < 0) {
                    break;
                }
                i4 = i3 + i4;
                i3 = 0;
            } else {
                if (i3 >= 4) {
                    if (i3 != 4) {
                        C0104d.m830a("Read Wait Count Full... Stop");
                        break;
                    }
                    Thread.sleep((long) i2);
                } else {
                    Thread.sleep(20);
                }
                i3++;
            }
        }
        if (i4 == i) {
            return obj;
        }
        C0104d.m830a(String.format("Read Error Data:[REQ:%d,READ:%d]\n", new Object[]{Integer.valueOf(i), Integer.valueOf(i4)}));
        Object obj2 = new byte[i4];
        System.arraycopy(obj, 0, obj2, 0, i4);
        return obj2;
    }

    public void m655b() {
        m647a(this.f668a);
        m649a(this.f669b);
    }

    public boolean m656b(byte[] bArr) {
        return bArr != null ? m651a(bArr, 0, bArr.length) : false;
    }
}
