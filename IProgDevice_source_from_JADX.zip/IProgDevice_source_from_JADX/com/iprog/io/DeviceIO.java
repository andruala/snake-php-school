package com.iprog.io;

import com.iprog.p006g.C0104d;
import java.io.FileDescriptor;

public class DeviceIO {
    static int f861a;

    static {
        f861a = 1;
        try {
            System.loadLibrary("jni_iprogio");
        } catch (Exception e) {
            C0104d.m829a(e, "CryptCode Error");
            f861a = -1;
        }
    }

    public static native boolean getGPIOStatus(int i);

    public static native void serialClose(FileDescriptor fileDescriptor);

    public static native FileDescriptor serialOpen(String str, int i, int i2);

    public static native void setGPIOStatus(int i, boolean z);
}
