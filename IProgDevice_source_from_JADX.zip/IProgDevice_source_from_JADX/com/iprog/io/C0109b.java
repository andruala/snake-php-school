package com.iprog.io;

class C0109b implements Runnable {
    final /* synthetic */ C0076a f862a;
    private final /* synthetic */ byte[] f863b;

    C0109b(C0076a c0076a, byte[] bArr) {
        this.f862a = c0076a;
        this.f863b = bArr;
    }

    public void run() {
        this.f862a.m656b(this.f863b);
    }
}
