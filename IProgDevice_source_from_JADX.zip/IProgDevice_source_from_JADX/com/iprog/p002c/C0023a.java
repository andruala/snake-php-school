package com.iprog.p002c;

import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class C0023a {
    public static String m139a(byte[] bArr) {
        try {
            MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.update(bArr);
            byte[] digest = instance.digest();
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < digest.length; i++) {
                stringBuilder.append(String.format("%02x", new Object[]{Integer.valueOf(digest[i] & 255)}));
            }
            return stringBuilder.toString();
        } catch (Exception e) {
            C0104d.m829a(e, "md5String");
            return "";
        }
    }

    private static byte[] m140a(String str, String str2, int i, byte[] bArr, byte[] bArr2) {
        byte[] bArr3 = new byte[8];
        if (str.equals("AES")) {
            bArr3 = new byte[16];
        }
        Key secretKeySpec = new SecretKeySpec(bArr2, str);
        AlgorithmParameterSpec ivParameterSpec = new IvParameterSpec(bArr3);
        try {
            Cipher instance = Cipher.getInstance(str2);
            instance.init(i, secretKeySpec, ivParameterSpec);
            return instance.doFinal(bArr);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public static byte[] m141a(String str, byte[] bArr) {
        int ceil = ((int) Math.ceil((double) (((float) str.length()) / 16.0f))) * 16;
        return C0023a.m143a(C0108h.m860a(str, ceil), bArr, 0, ceil);
    }

    public static byte[] m142a(byte[] bArr, byte[] bArr2) {
        return C0023a.m140a("AES", "AES/CBC/NoPadding", 1, bArr, bArr2);
    }

    public static byte[] m143a(byte[] bArr, byte[] bArr2, int i, int i2) {
        byte[] bArr3 = new byte[i2];
        System.arraycopy(bArr, i, bArr3, 0, i2);
        return C0023a.m142a(bArr3, bArr2);
    }

    public static byte[] m144b(byte[] bArr, byte[] bArr2) {
        return C0023a.m140a("AES", "AES/CBC/NoPadding", 2, bArr, bArr2);
    }

    public static byte[] m145b(byte[] bArr, byte[] bArr2, int i, int i2) {
        Object obj = new byte[i2];
        System.arraycopy(bArr, i, obj, 0, i2);
        return C0023a.m144b(obj, bArr2);
    }
}
