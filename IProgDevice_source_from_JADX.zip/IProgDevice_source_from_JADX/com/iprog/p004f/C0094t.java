package com.iprog.p004f;

import com.iprog.p006g.C0104d;

class C0094t extends Thread {
    boolean f767a = false;
    boolean f768b = false;
    boolean f769c = false;
    boolean f770d = false;
    final /* synthetic */ C0093s f771e;

    C0094t(C0093s c0093s) {
        this.f771e = c0093s;
    }

    public void interrupt() {
        C0104d.m830a("ReadThread interrupt");
        C0104d.m830a("ReadThread _input.close");
        super.interrupt();
    }

    public boolean isInterrupted() {
        C0104d.m830a("ReadThread isInterrupted");
        return super.isInterrupted();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
        r13 = this;
        r11 = 3;
        r10 = 188; // 0xbc float:2.63E-43 double:9.3E-322;
        r1 = 0;
        r0 = "Manager Read Thread Start..";
        com.iprog.p006g.C0104d.m830a(r0);
        r2 = 10;
        com.iprog.p006g.C0108h.m853a(r2);
        r0 = r1;
    L_0x000f:
        r2 = r13.f767a;
        if (r2 == 0) goto L_0x001b;
    L_0x0013:
        r13.f770d = r1;
        r0 = "Manager Read Thread End..";
        com.iprog.p006g.C0104d.m830a(r0);
        return;
    L_0x001b:
        r3 = new com.iprog.f.ac;
        r3.<init>();
        r2 = r13.f770d;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        if (r2 != 0) goto L_0x0027;
    L_0x0024:
        r2 = 1;
        r13.f770d = r2;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
    L_0x0027:
        r2 = 0;
        r13.f768b = r2;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r2 = r13.f771e;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r4 = 1;
        r2 = r2.m653a(r4);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r4 = 0;
        r4 = r2[r4];	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r5 = -95;
        if (r4 != r5) goto L_0x000f;
    L_0x0038:
        r4 = r13.f771e;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r5 = 1;
        r4 = r4.m653a(r5);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r5 = 2;
        r5 = new byte[r5];	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r6 = 0;
        r7 = 0;
        r2 = r2[r7];	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r5[r6] = r2;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r2 = 1;
        r6 = 0;
        r6 = r4[r6];	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r5[r2] = r6;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r2 = r3.m695a(r5);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        if (r2 != 0) goto L_0x0097;
    L_0x0054:
        r2 = "HEADER ERROR :%02x,%02x";
        r3 = 2;
        r3 = new java.lang.Object[r3];	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r4 = 0;
        r6 = 0;
        r6 = r5[r6];	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r6 = java.lang.Byte.valueOf(r6);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r3[r4] = r6;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r4 = 1;
        r6 = 1;
        r5 = r5[r6];	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r5 = java.lang.Byte.valueOf(r5);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r3[r4] = r5;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r2 = java.lang.String.format(r2, r3);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        com.iprog.p006g.C0104d.m830a(r2);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r2 = r13.f771e;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r2.m678g();	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        if (r0 != r10) goto L_0x000f;
    L_0x007b:
        r2 = new com.iprog.f.ac;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r3 = 188; // 0xbc float:2.63E-43 double:9.3E-322;
        r4 = 0;
        r2.<init>(r3, r4);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r3 = r13.f771e;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r4 = 24003; // 0x5dc3 float:3.3635E-41 double:1.1859E-319;
        r2 = r2.m720c(r4);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r3.mo35a(r2);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        goto L_0x000f;
    L_0x008f:
        r0 = move-exception;
        r2 = "ManagerService ReadThread";
        com.iprog.p006g.C0104d.m829a(r0, r2);
        goto L_0x0013;
    L_0x0097:
        r2 = r13.f771e;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r6 = 8;
        r2 = r2.m653a(r6);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r6 = 10;
        r6 = new byte[r6];	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r7 = 0;
        r8 = 0;
        r9 = 2;
        java.lang.System.arraycopy(r5, r7, r6, r8, r9);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r5 = 0;
        r7 = 2;
        r8 = r2.length;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        java.lang.System.arraycopy(r2, r5, r6, r7, r8);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r2 = r13.f771e;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r2 = r2.f765m;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r2.m749a();	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r3.m699b(r6);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r2 = 0;
        r2 = r4[r2];	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        r2 = com.iprog.p006g.C0108h.m842a(r2);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x016b }
        if (r2 == r10) goto L_0x00f7;
    L_0x00c4:
        r0 = "READ HEAD[%02x,%d,%d]";
        r4 = 3;
        r4 = new java.lang.Object[r4];	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r5 = 0;
        r6 = r3.m698b();	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r6 = r6.f754b;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r6 = java.lang.Integer.valueOf(r6);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r4[r5] = r6;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r5 = 1;
        r6 = r3.m698b();	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r6 = r6.f755c;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r6 = java.lang.Integer.valueOf(r6);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r4[r5] = r6;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r5 = 2;
        r6 = r3.m698b();	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r6 = r6.f756d;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r6 = java.lang.Integer.valueOf(r6);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r4[r5] = r6;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r0 = java.lang.String.format(r0, r4);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        com.iprog.p006g.C0104d.m830a(r0);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
    L_0x00f7:
        r0 = r3.m698b();	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r0 = r0.f756d;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r4 = 10240000; // 0x9c4000 float:1.4349296E-38 double:5.059232E-317;
        if (r0 >= r4) goto L_0x014b;
    L_0x0102:
        r0 = r3.m698b();	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r0 = r0.f756d;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        if (r0 <= 0) goto L_0x014b;
    L_0x010a:
        r0 = 0;
        r0 = (byte[]) r0;	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r0 = r13.f771e;	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r4 = r3.m698b();	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r4 = r4.f756d;	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r5 = r13.f771e;	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r5 = r5.f763k;	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r0 = r0.m654a(r4, r5);	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r4 = r0.length;	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r5 = r3.m698b();	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r5 = r5.f756d;	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        if (r4 != r5) goto L_0x0131;
    L_0x0126:
        r3.m700c(r0);	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r0 = r13.f771e;	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r0.m677e(r3);	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r0 = r2;
        goto L_0x000f;
    L_0x0131:
        r0 = r13.f771e;	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r4 = 24002; // 0x5dc2 float:3.3634E-41 double:1.18586E-319;
        r0.m670a(r3, r4);	 Catch:{ Exception -> 0x013b, IOException -> 0x008f, InterruptedException -> 0x015a }
        r0 = r2;
        goto L_0x000f;
    L_0x013b:
        r0 = move-exception;
        r4 = "Manager Service Receive Body";
        com.iprog.p006g.C0104d.m829a(r0, r4);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r0 = r13.f771e;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r4 = 24003; // 0x5dc3 float:3.3635E-41 double:1.1859E-319;
        r0.m670a(r3, r4);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r0 = r2;
        goto L_0x000f;
    L_0x014b:
        r0 = r13.f771e;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r0.m678g();	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r0 = r13.f771e;	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r4 = 24004; // 0x5dc4 float:3.3637E-41 double:1.18596E-319;
        r0.m670a(r3, r4);	 Catch:{ IOException -> 0x008f, InterruptedException -> 0x015a, Exception -> 0x0173 }
        r0 = r2;
        goto L_0x000f;
    L_0x015a:
        r0 = move-exception;
        r2 = r13.f771e;
        r2 = r2.f760h;
        r3 = "";
        com.iprog.p006g.C0108h.m857a(r2, r11, r3);
        r2 = "ManagerService InterruptedException";
        com.iprog.p006g.C0104d.m829a(r0, r2);
        goto L_0x0013;
    L_0x016b:
        r2 = move-exception;
    L_0x016c:
        r3 = "ReadThread Warning..........";
        com.iprog.p006g.C0104d.m829a(r2, r3);
        goto L_0x000f;
    L_0x0173:
        r0 = move-exception;
        r12 = r0;
        r0 = r2;
        r2 = r12;
        goto L_0x016c;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.iprog.f.t.run():void");
    }
}
