package com.iprog.p004f;

import com.iprog.p006g.C0104d;

public class ab {
    public int f688a = 0;
    public boolean f689b = false;
    public boolean f690c = false;
    public boolean f691d = false;
    public boolean f692e = false;
    public int f693f = 0;
    public int f694g = 0;
    public int f695h = 0;
    public int f696i = 0;
    public int f697j = 0;
    public boolean f698k = false;
    public int f699l = 0;
    public boolean f700m = false;
    public String f701n = "";
    public int f702o = 0;
    public String f703p = "";
    public int f704q = 0;
    public byte[] f705r = null;
    public String f706s = "";
    public String f707t = "";
    public int f708u = 0;
    public int f709v = 0;
    public int f710w = 0;

    public int m692a() {
        int i = ((((0 + this.f693f) + (this.f694g * 2)) + (this.f695h * 2)) + (this.f696i * 2)) + (this.f699l * 2);
        C0104d.m830a("getProgress Size:" + i);
        return i;
    }
}
