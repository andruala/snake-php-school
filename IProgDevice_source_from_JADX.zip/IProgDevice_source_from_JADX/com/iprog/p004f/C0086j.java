package com.iprog.p004f;

class C0086j implements Runnable {
    final /* synthetic */ C0077h f747a;
    private final /* synthetic */ byte[] f748b;

    C0086j(C0077h c0077h, byte[] bArr) {
        this.f747a = c0077h;
        this.f748b = bArr;
    }

    public void run() {
        this.f747a.m656b(this.f748b);
    }
}
