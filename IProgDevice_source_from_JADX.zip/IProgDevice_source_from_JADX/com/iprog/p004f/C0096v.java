package com.iprog.p004f;

import android.os.Handler;
import com.iprog.p006g.C0104d;
import java.io.FileDescriptor;

public class C0096v extends C0093s {
    C0090o f778l = new C0097w(this);
    C0091p f779m = new C0098x(this);
    C0091p f780n = null;
    private int f781o = -1;

    public C0096v(FileDescriptor fileDescriptor, Handler handler) {
        super(fileDescriptor, handler);
        m745a(this.f778l);
        m746a(true);
    }

    public boolean mo36c() {
        C0104d.m830a("PCManager Start");
        return super.mo36c();
    }
}
