package com.iprog.p004f;

import com.iprog.p003d.C0029e;
import com.iprog.p003d.C0034j;
import com.iprog.p003d.C0036l;
import com.iprog.p003d.C0039o;
import com.iprog.p003d.C0040p;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.io.StringReader;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

public class ac extends C0079q {
    private static String f714h = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    private static String f715i = "IProg";
    private static String f716j = "Data";
    int f717c = 0;
    int f718d = 0;
    int f719e = 0;
    int f720f = 1;
    public int f721g = 0;
    private List f722k = new ArrayList();
    private List f723l = new ArrayList();

    public ac(int i, int i2) {
        this.f717c = i;
        super.m698b().f754b = i;
        super.m698b().f755c = i2;
    }

    public ac(ac acVar) {
        this.f717c = acVar.m698b().f754b;
        super.m698b().f754b = this.f717c;
        super.m698b().f755c = acVar.m698b().f755c;
    }

    private String m701a(XmlPullParser xmlPullParser, String str) {
        String attributeValue = xmlPullParser.getAttributeValue(null, str);
        return attributeValue == null ? "" : attributeValue;
    }

    private void m702a(XmlPullParser xmlPullParser, C0036l c0036l) {
        c0036l.f209a = C0108h.m844a(m701a(xmlPullParser, "msg_id"));
        c0036l.f210b = C0108h.m844a(m701a(xmlPullParser, "error_cd"));
        c0036l.f211c = m701a(xmlPullParser, "error_msg");
    }

    private ab m703f() {
        boolean z = true;
        ab abVar = new ab();
        ByteBuffer wrap = ByteBuffer.wrap(this.b);
        wrap.order(a);
        abVar.f689b = wrap.get() == (byte) 1;
        abVar.f690c = wrap.get() == (byte) 1;
        abVar.f691d = wrap.get() == (byte) 1;
        abVar.f692e = wrap.get() == (byte) 1;
        abVar.f693f = wrap.getInt();
        abVar.f694g = wrap.getInt();
        abVar.f695h = wrap.getInt();
        abVar.f696i = wrap.getInt();
        abVar.f697j = wrap.getInt();
        if (wrap.get() != (byte) 1) {
            z = false;
        }
        abVar.f698k = z;
        abVar.f699l = wrap.getShort();
        return abVar;
    }

    private ab m704g() {
        ab abVar = new ab();
        ByteBuffer wrap = ByteBuffer.wrap(this.b);
        wrap.order(a);
        abVar.f701n = new String(C0108h.m861a(wrap, 2));
        short s = wrap.getShort();
        abVar.f702o = ((s & 65280) >> 8) | ((s & 255) << 8);
        abVar.f703p = new String(C0108h.m861a(wrap, 64)).trim();
        abVar.f704q = wrap.getInt();
        abVar.f705r = new byte[abVar.f704q];
        return abVar;
    }

    private ab m705h() {
        ab abVar = new ab();
        ByteBuffer wrap = ByteBuffer.wrap(this.b);
        wrap.order(a);
        abVar.f708u = wrap.get();
        abVar.f709v = C0108h.m845a(wrap.getShort());
        abVar.f704q = C0108h.m845a(wrap.getShort());
        abVar.f705r = new byte[2048];
        wrap.get(abVar.f705r);
        abVar.f710w = C0108h.m845a(wrap.getShort());
        return abVar;
    }

    private ab m706i() {
        boolean z = true;
        ab abVar = new ab();
        ByteBuffer wrap = ByteBuffer.wrap(this.b);
        wrap.order(a);
        if (wrap.get() != (byte) 1) {
            z = false;
        }
        abVar.f700m = z;
        return abVar;
    }

    public void m707a(int i, int i2) {
        this.f718d = i;
        this.f719e = i2;
    }

    public void m708a(List list) {
        this.f722k.clear();
        Collections.addAll(this.f722k, (String[]) list.toArray(new String[list.size()]));
    }

    public void m709a(String[] strArr) {
        this.f723l.add(new ArrayList(Arrays.asList(strArr)));
    }

    public boolean m710a(C0034j c0034j) {
        try {
            String str = new String(this.b);
            XmlPullParserFactory newInstance = XmlPullParserFactory.newInstance();
            newInstance.setNamespaceAware(false);
            XmlPullParser newPullParser = newInstance.newPullParser();
            newPullParser.setInput(new StringReader(str));
            while (newPullParser.getEventType() != 1) {
                if (newPullParser.getEventType() == 2 && newPullParser.getName().equals("Data")) {
                    c0034j.f185a = C0108h.m844a(m701a(newPullParser, "offset"));
                    c0034j.f186b = C0108h.m844a(m701a(newPullParser, "cnt"));
                    c0034j.f187c = C0108h.m866c(m701a(newPullParser, "total_yn"));
                    c0034j.f188d = C0108h.m844a(m701a(newPullParser, "sum_type"));
                    c0034j.f189e = C0108h.m844a(m701a(newPullParser, "job_type"));
                    c0034j.f190f = C0108h.m844a(m701a(newPullParser, "type1"));
                    c0034j.f191g = m701a(newPullParser, "model");
                    c0034j.f192h = m701a(newPullParser, "date_st");
                    c0034j.f193i = m701a(newPullParser, "date_ed");
                    c0034j.f194j = C0108h.m844a(m701a(newPullParser, "uniq_id"));
                    c0034j.f195k = m701a(newPullParser, "date_ed");
                    c0034j.f196l = m701a(newPullParser, "pt_ver");
                    c0034j.f197m = m701a(newPullParser, "fw_ver");
                    c0034j.f198n = m701a(newPullParser, "sw_ver");
                    c0034j.f199o = C0108h.m844a(m701a(newPullParser, "cipher"));
                    c0034j.f200p = C0108h.m844a(m701a(newPullParser, "session"));
                    c0034j.f201q = m701a(newPullParser, "cat_no");
                    c0034j.f202r = m701a(newPullParser, "cp_name");
                    c0034j.f203s = m701a(newPullParser, "color_name");
                    c0034j.f204t = m701a(newPullParser, "tn_dr_name");
                    c0034j.f205u = m701a(newPullParser, "file_name");
                }
                newPullParser.next();
            }
            return true;
        } catch (Exception e) {
            C0104d.m828a(e);
            return false;
        }
    }

    public boolean m711a(String str, C0029e c0029e) {
        try {
            if (str.isEmpty()) {
                return false;
            }
            XmlPullParserFactory newInstance = XmlPullParserFactory.newInstance();
            newInstance.setNamespaceAware(false);
            XmlPullParser newPullParser = newInstance.newPullParser();
            newPullParser.setInput(new StringReader(str));
            String str2 = "";
            while (newPullParser.getEventType() != 1) {
                if (newPullParser.getEventType() == 2) {
                    if (newPullParser.getName().equals("Response")) {
                        m702a(newPullParser, c0029e.f163a);
                    } else if (newPullParser.getName().equals("Data")) {
                        c0029e.f164b = C0108h.m844a(m701a(newPullParser, "count"));
                        c0029e.f165c = m701a(newPullParser, "reg_dt");
                        c0029e.f165c = m701a(newPullParser, "reg_dt");
                        c0029e.f166d = C0108h.m844a(m701a(newPullParser, "credit_type"));
                    }
                }
                newPullParser.next();
            }
            return true;
        } catch (Exception e) {
            C0104d.m828a(e);
            return false;
        }
    }

    public boolean m712a(String str, C0036l c0036l) {
        try {
            if (str.isEmpty()) {
                return false;
            }
            XmlPullParserFactory newInstance = XmlPullParserFactory.newInstance();
            newInstance.setNamespaceAware(false);
            XmlPullParser newPullParser = newInstance.newPullParser();
            newPullParser.setInput(new StringReader(str));
            String str2 = "";
            while (newPullParser.getEventType() != 1) {
                if (newPullParser.getEventType() == 2) {
                    if (newPullParser.getName().equals("Response")) {
                        m702a(newPullParser, c0036l);
                    } else {
                        str2 = newPullParser.getName().equals("Data") ? newPullParser.getName() : "";
                    }
                } else if (newPullParser.getEventType() == 4 && r2.equals("Data")) {
                    c0036l.f212d = newPullParser.getText();
                    str2 = "";
                }
                newPullParser.next();
            }
            return true;
        } catch (Exception e) {
            C0104d.m828a(e);
            return false;
        }
    }

    public boolean m713a(String str, C0040p c0040p) {
        if (str.isEmpty()) {
            c0040p.f226a = -1;
            return false;
        }
        XmlPullParserFactory newInstance = XmlPullParserFactory.newInstance();
        newInstance.setNamespaceAware(false);
        XmlPullParser newPullParser = newInstance.newPullParser();
        newPullParser.setInput(new StringReader(str));
        String str2 = "";
        while (newPullParser.getEventType() != 1) {
            if (newPullParser.getEventType() == 2) {
                if (newPullParser.getName().equals("Version")) {
                    c0040p.f227b = C0108h.m844a(m701a(newPullParser, "code"));
                    c0040p.f228c = m701a(newPullParser, "name");
                    c0040p.f229d = m701a(newPullParser, "reg_dt");
                } else {
                    try {
                        if (newPullParser.getName().equals("Data")) {
                            C0039o c0039o = new C0039o();
                            c0039o.f218a = C0108h.m844a(m701a(newPullParser, "p_id"));
                            c0039o.f219b = C0108h.m844a(m701a(newPullParser, "ver_code"));
                            c0039o.f220c = m701a(newPullParser, "ver_type");
                            c0039o.f221d = m701a(newPullParser, "ver_name");
                            c0039o.f222e = m701a(newPullParser, "file_name");
                            c0039o.f223f = m701a(newPullParser, "hash");
                            c0039o.f224g = C0108h.m844a(m701a(newPullParser, "file_size"));
                            c0039o.f225h = m701a(newPullParser, "reg_dt");
                            if (c0039o.f220c.equals("FW")) {
                                c0040p.f231f = c0039o;
                            } else if (c0039o.f220c.equals("FD")) {
                                c0040p.f232g = c0039o;
                            } else if (c0039o.f220c.equals("XC")) {
                                c0040p.f233h = c0039o;
                            } else if (c0039o.f220c.equals("SW")) {
                                c0040p.f230e = c0039o;
                            }
                        }
                    } catch (Exception e) {
                        C0104d.m828a(e);
                        c0040p.f226a = -1;
                        return false;
                    }
                }
            }
            newPullParser.next();
        }
        c0040p.f226a = 1;
        return true;
    }

    public byte[] m714a(int i, int i2, int i3, int i4) {
        ByteBuffer allocate = ByteBuffer.allocate(16);
        allocate.order(a);
        allocate.putShort((short) i);
        allocate.put((byte) i2);
        allocate.putInt(i3);
        allocate.put(C0108h.m867c(1));
        return m716a(allocate.array(), 16, i4);
    }

    public byte[] m715a(byte[] bArr, int i) {
        return m716a(bArr, bArr.length, i);
    }

    public byte[] m716a(byte[] bArr, int i, int i2) {
        byte[] a = m697a(this.f717c, i2, i);
        ByteBuffer allocate = ByteBuffer.allocate(a.length + i);
        allocate.put(a);
        allocate.put(bArr, 0, i);
        return allocate.array();
    }

    public void m717b(String[] strArr) {
        this.f722k.clear();
        Collections.addAll(this.f722k, strArr);
    }

    public byte[] m718b(int i) {
        this.f720f = i;
        byte[] bytes = m719c().getBytes();
        C0104d.m832a("[SEND]", new String(bytes));
        byte[] a = m697a(this.f717c, i, bytes.length);
        ByteBuffer allocate = ByteBuffer.allocate(bytes.length + a.length);
        allocate.put(a);
        allocate.put(bytes);
        return allocate.array();
    }

    public String m719c() {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            stringBuilder.append(f714h).append("<").append(f715i).append(">");
            stringBuilder.append(String.format("<Info total=\"%s\"  count=\"%s\" error=\"%d\" />", new Object[]{Integer.valueOf(this.f718d), Integer.valueOf(this.f719e), Integer.valueOf(this.f720f)}));
            stringBuilder.append("<List>\n");
            for (int i = 0; i < this.f723l.size(); i++) {
                stringBuilder.append("<").append(f716j);
                for (int i2 = 0; i2 < this.f722k.size(); i2++) {
                    stringBuilder.append(" ").append((String) this.f722k.get(i2)).append("=\"").append((String) ((List) this.f723l.get(i)).get(i2)).append("\"");
                }
                stringBuilder.append("/>\n");
            }
            stringBuilder.append("</List>\n");
            stringBuilder.append("</").append(f715i).append(">");
            return new String(stringBuilder.toString().getBytes("utf-8"));
        } catch (Exception e) {
            C0104d.m829a(e, "XmlPacket getSendPacket");
            return "";
        }
    }

    public byte[] m720c(int i) {
        switch (this.f717c) {
            case 186:
            case 187:
            case 188:
            case 189:
                ByteBuffer allocate = ByteBuffer.allocate(2);
                allocate.order(a);
                allocate.putShort((short) i);
                return m716a(allocate.array(), 2, i);
            default:
                return null;
        }
    }

    public byte[] m721d() {
        return m718b(1);
    }

    public ab m722e() {
        ab abVar = new ab();
        switch (m698b().f754b) {
            case 186:
                abVar = m703f();
                break;
            case 187:
                abVar = m704g();
                break;
            case 188:
                abVar = m705h();
                break;
            case 189:
                abVar = m706i();
                break;
        }
        abVar.f688a = m698b().f754b;
        return abVar;
    }
}
