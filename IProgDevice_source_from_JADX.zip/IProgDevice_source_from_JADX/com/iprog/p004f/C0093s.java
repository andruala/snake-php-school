package com.iprog.p004f;

import android.os.Handler;
import com.iprog.p001b.C0013d;
import com.iprog.p006g.C0104d;
import java.io.FileDescriptor;

public abstract class C0093s extends C0077h {
    Handler f760h = null;
    C0094t f761i = null;
    FileDescriptor f762j = null;
    int f763k = 50;
    private boolean f764l = false;
    private C0095u f765m = new C0095u(this);
    private C0090o f766n = null;

    public C0093s(FileDescriptor fileDescriptor, Handler handler) {
        super(1);
        this.f762j = fileDescriptor;
        this.f760h = handler;
        this.f = C0013d.m42d().m77b();
        this.f761i = new C0094t(this);
        this.f765m = new C0095u(this);
        this.c = false;
    }

    private void m744e() {
    }

    public void m745a(C0090o c0090o) {
        this.f766n = c0090o;
    }

    public void m746a(boolean z) {
        this.f764l = z;
    }

    public boolean mo36c() {
        try {
            m646a(this.f762j);
            this.f761i.start();
            this.f765m.start();
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "MnagerService start");
            m655b();
            return false;
        }
    }

    public void m748d() {
        if (this.f761i != null) {
            try {
                this.f761i.interrupt();
            } catch (Exception e) {
            }
        }
        super.m655b();
    }
}
