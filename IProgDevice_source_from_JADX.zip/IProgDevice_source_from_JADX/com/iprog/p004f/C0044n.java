package com.iprog.p004f;

public interface C0044n {
    boolean mo18a(ac acVar);
}
