package com.iprog.p004f;

public interface C0045e {
    boolean mo20a(C0099y c0099y);
}
