package com.iprog.p004f;

import android.database.Cursor;
import com.iprog.device.R;
import com.iprog.io.C0076a;
import com.iprog.p001b.C0011b;
import com.iprog.p001b.C0013d;
import com.iprog.p002c.C0023a;
import com.iprog.p003d.C0034j;
import com.iprog.p005e.C0075a;
import com.iprog.p006g.C0101a;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.io.File;
import java.util.Arrays;
import java.util.Locale;

public abstract class C0077h extends C0076a {
    boolean f674e = false;
    public C0075a f675f = null;
    int f676g = 1;
    private C0044n f677h = null;
    private C0089m f678i = null;

    public C0077h(int i) {
        this.f676g = i;
        this.f675f = C0013d.m42d().m77b();
    }

    private int m657f(com.iprog.p004f.ac r11) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:46:? in {6, 9, 12, 15, 18, 27, 35, 36, 38, 39, 41, 42, 44, 45, 47, 48, 49} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.rerun(BlockProcessor.java:44)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.visit(BlockFinallyExtract.java:57)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r10 = this;
        r7 = 2;
        r0 = 1;
        r2 = 0;
        r6 = new com.iprog.d.j;
        r6.<init>();
        r11.m710a(r6);
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r1 = 0;
        r4 = r6.f189e;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        if (r4 == r0) goto L_0x0019;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x0015:
        r4 = r6.f189e;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        if (r4 != r7) goto L_0x00f7;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x0019:
        r4 = " AND job_type in (1,2) ";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r3.append(r4);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x001e:
        r4 = r6.f191g;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = r4.isEmpty();	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        if (r4 != 0) goto L_0x0037;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x0026:
        r4 = " AND mdl_name like '%%";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = r3.append(r4);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = r6.f191g;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = r4.append(r5);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = "'";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4.append(r5);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x0037:
        r4 = "";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = "";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = r6.f188d;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        if (r4 != r0) goto L_0x0114;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x003f:
        r4 = "SELECT job_type,reg_dt, mdl_name,color,nat_cd \n      ,yield,count(*) as cnt,1 \n  FROM rp_work_his \n WHERE reg_dt >= '%s' and reg_dt <= '%s' \n   %s \n GROUP BY job_type,reg_dt, mdl_name,color,nat_cd, yield \n ORDER BY reg_dt desc,_id desc \n limit %d offset %d \n";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = 5;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = new java.lang.Object[r5];	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 0;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f192h;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 1;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f193i;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 2;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r3.toString();	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f186b;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = java.lang.Integer.valueOf(r8);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 4;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f185a;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = java.lang.Integer.valueOf(r8);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = java.lang.String.format(r4, r5);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = "SELECT count(*) FROM  ( \nSELECT 1 \n  FROM rp_work_his \n\n WHERE reg_dt >= '%s' and reg_dt <= '%s' \n   %s  GROUP BY job_type,reg_dt, mdl_name,color,nat_cd, yield  ORDER BY reg_dt desc,_id desc  )";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = new java.lang.Object[r7];	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 0;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r6.f192h;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 1;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r6.f193i;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 2;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r3 = r3.toString();	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7[r8] = r3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r3 = java.lang.String.format(r5, r7);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = r4;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x0086:
        r4 = 10;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = new java.lang.String[r4];	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 0;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = "idx";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 1;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = "num";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 2;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = "jobtype";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = "date";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 4;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = "model";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 5;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = "color";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 6;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = "nat";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 7;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = "yield";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = "hap";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = "result";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = new com.iprog.f.ac;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7.<init>(r11);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7.m717b(r4);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = r6.f187c;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        if (r4 == 0) goto L_0x020f;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x00ca:
        r4 = r10.f675f;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r3 = r4.m637b(r3);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = r3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x00d1:
        r3 = r6.f187c;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        if (r3 == 0) goto L_0x00d7;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x00d5:
        if (r4 <= 0) goto L_0x00ed;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x00d7:
        r3 = r10.f675f;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r1 = r3.m631a(r5);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r3 = r1.getCount();	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = 500; // 0x1f4 float:7.0E-43 double:2.47E-321;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = java.lang.Math.min(r3, r5);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x00e7:
        if (r2 < r5) goto L_0x01aa;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x00e9:
        com.iprog.p005e.C0075a.m626a(r1);
        r2 = r3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x00ed:
        r7.m707a(r4, r2);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r10.m674b(r7);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        com.iprog.p005e.C0075a.m626a(r1);
    L_0x00f6:
        return r0;
    L_0x00f7:
        r4 = r6.f189e;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        if (r4 == 0) goto L_0x001e;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x00fb:
        r4 = " AND job_type=";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = r3.append(r4);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = r6.f189e;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4.append(r5);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        goto L_0x001e;
    L_0x0108:
        r0 = move-exception;
        r2 = "JobLog";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        com.iprog.p006g.C0104d.m829a(r0, r2);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r0 = 24006; // 0x5dc6 float:3.364E-41 double:1.18605E-319;
        com.iprog.p005e.C0075a.m626a(r1);
        goto L_0x00f6;
    L_0x0114:
        r4 = r6.f188d;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        if (r4 != r7) goto L_0x0161;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x0118:
        r4 = "SELECT job_type,substr(reg_dt,1,7), mdl_name \n      ,color,nat_cd, yield,count(*) as cnt,1 \n  FROM rp_work_his \n WHERE reg_dt >= '%s' and reg_dt <= '%s' \n   %s \n GROUP BY job_type,substr(reg_dt,1,7), mdl_name,color,nat_cd, yield \n ORDER BY reg_dt desc, cnt desc \n limit %d offset %d \n";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = 5;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = new java.lang.Object[r5];	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 0;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f192h;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 1;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f193i;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 2;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r3.toString();	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f186b;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = java.lang.Integer.valueOf(r8);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 4;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f185a;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = java.lang.Integer.valueOf(r8);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = java.lang.String.format(r4, r5);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = "SELECT count(*) FROM  ( SELECT 1   FROM rp_work_his  WHERE reg_dt >= '%s' and reg_dt <= '%s'    %s  GROUP BY job_type,substr(reg_dt,1,7), mdl_name,color,nat_cd, yield  )";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = new java.lang.Object[r7];	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 0;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r6.f192h;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 1;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r6.f193i;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 2;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r3 = r3.toString();	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7[r8] = r3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r3 = java.lang.String.format(r5, r7);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = r4;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        goto L_0x0086;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x0161:
        r4 = "SELECT job_type,reg_dt, mdl_name,color,nat_cd \n\t  ,yield,1,err_cd \n  FROM rp_work_his \n WHERE reg_dt >= '%s' and reg_dt <= '%s' \n   %s \n ORDER BY reg_dt desc,_id desc \n limit %d offset %d \n";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = 5;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = new java.lang.Object[r5];	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 0;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f192h;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 1;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f193i;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 2;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r3.toString();	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f186b;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = java.lang.Integer.valueOf(r8);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 4;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = r6.f185a;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = java.lang.Integer.valueOf(r8);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5[r7] = r8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r4 = java.lang.String.format(r4, r5);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = "SELECT count(*) \n  FROM rp_work_his \n WHERE reg_dt >= '%s' and reg_dt <= '%s' \n   %s \n ORDER BY reg_dt desc,_id desc \n";	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = 3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7 = new java.lang.Object[r7];	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 0;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r6.f192h;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 1;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r6.f193i;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 2;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r3 = r3.toString();	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7[r8] = r3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r3 = java.lang.String.format(r5, r7);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r5 = r4;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        goto L_0x0086;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
    L_0x01aa:
        r6 = 10;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r6 = new java.lang.String[r6];	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 0;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r5 - r2;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = java.lang.String.valueOf(r9);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r6[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 1;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = java.lang.String.valueOf(r2);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r6[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 2;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = 0;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r1.getString(r9);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r6[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = 1;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r1.getString(r9);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r6[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 4;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = 2;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r1.getString(r9);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r6[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 5;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = 3;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r1.getString(r9);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r6[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 6;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = 4;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r1.getString(r9);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r6[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 7;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = 5;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r1.getString(r9);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r6[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 8;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = 6;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r1.getString(r9);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r6[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r8 = 9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = 7;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r9 = r1.getString(r9);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r6[r8] = r9;	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r7.m709a(r6);	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r1.moveToNext();	 Catch:{ Exception -> 0x0108, all -> 0x020a }
        r2 = r2 + 1;
        goto L_0x00e7;
    L_0x020a:
        r0 = move-exception;
        com.iprog.p005e.C0075a.m626a(r1);
        throw r0;
    L_0x020f:
        r4 = r2;
        goto L_0x00d1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.iprog.f.h.f(com.iprog.f.ac):int");
    }

    private int m658g(ac acVar) {
        int i = 1;
        int i2 = 0;
        C0034j c0034j = new C0034j();
        acVar.m710a(c0034j);
        StringBuilder stringBuilder = new StringBuilder();
        Cursor cursor = null;
        try {
            String str = "";
            str = "";
            int i3 = c0034j.f190f;
            if (i3 == 1) {
                stringBuilder.append(" AND send_yn='Y' ");
            } else if (c0034j.f190f == 2) {
                stringBuilder.append(" AND send_yn='N' ");
            }
            String format = String.format("SELECT _id,send_yn,ifnull(send_time,''),ifnull(reg_time,'')\t  ,mdl_name,ifnull(color,''),ifnull(nat_cd,''),ifnull(yield,0)       ,ifnull(tn_dr_name,'') \n      ,ifnull(company,''),ifnull(cat_num,''),file_size \n      ,read_info \n  FROM rp_chip_read \n WHERE reg_dt >= '%s' and reg_dt <= '%s' \n   %s \n ORDER BY _id desc \n limit %d offset %d \n", new Object[]{c0034j.f192h, c0034j.f193i, stringBuilder.toString(), Integer.valueOf(c0034j.f186b), Integer.valueOf(c0034j.f185a)});
            String format2 = String.format("SELECT count(*)\t\t\n  FROM rp_chip_read \t\n WHERE reg_dt >= '%s' and reg_dt <= '%s' \n   %s \n", new Object[]{c0034j.f192h, c0034j.f193i, stringBuilder.toString()});
            String[] strArr = new String[]{"idx", "uniq_id", "send_yn", "send_dt", "date", "model", "color", "nat", "yield", "tn_dr_name", "company", "cat_no", "file_size", "read_info"};
            ac acVar2 = new ac(acVar);
            acVar2.m717b(strArr);
            i3 = c0034j.f187c ? this.f675f.m637b(format2) : 0;
            if (!c0034j.f187c || i3 > 0) {
                cursor = this.f675f.m631a(format);
                stringBuilder = cursor.getCount();
                int min = Math.min(stringBuilder, 500);
                while (i2 < min) {
                    acVar2.m709a(new String[]{String.valueOf(min - i2), cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getString(7), cursor.getString(8), cursor.getString(9), cursor.getString(10), cursor.getString(11), cursor.getString(12)});
                    cursor.moveToNext();
                    i2++;
                }
                i2 = stringBuilder;
            }
            acVar2.m707a(i3, i2);
            m674b(acVar2);
            C0075a.m626a(cursor);
            return i;
        } catch (Exception e) {
            i = 24005;
            return i;
        } finally {
            C0075a.m626a(cursor);
        }
    }

    private int m659h(com.iprog.p004f.ac r8) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:18:? in {5, 6, 8, 9, 10, 15, 17, 19, 21} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.rerun(BlockProcessor.java:44)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.visit(BlockFinallyExtract.java:57)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r7 = this;
        r1 = 1;
        r0 = new com.iprog.d.j;
        r0.<init>();
        r8.m710a(r0);
        r2 = 0;
        r3 = new com.iprog.f.ac;
        r3.<init>(r8);
        r4 = "SELECT file_name,file_size \n  FROM rp_chip_read \n WHERE _id = %d\n";	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r5 = 1;	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r5 = new java.lang.Object[r5];	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r6 = 0;	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r0 = r0.f194j;	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r0 = java.lang.Integer.valueOf(r0);	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r5[r6] = r0;	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r0 = java.lang.String.format(r4, r5);	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r4 = r7.f675f;	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r2 = r4.m631a(r0);	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r2.getCount();	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r0 = r2.getCount();	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        if (r0 <= 0) goto L_0x005a;	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
    L_0x0030:
        r0 = 0;	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r0 = r2.getString(r0);	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r0 = com.iprog.p006g.C0108h.m871f(r0);	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        com.iprog.p005e.C0075a.m626a(r2);	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r4 = 1;	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r0 = r3.m715a(r0, r4);	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r7.mo35a(r0);	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r0 = r1;
    L_0x0045:
        com.iprog.p005e.C0075a.m626a(r2);
    L_0x0048:
        if (r0 == r1) goto L_0x0059;
    L_0x004a:
        r2 = java.lang.Integer.toString(r0);
        r2 = r2.getBytes();
        r0 = r3.m715a(r2, r0);
        r7.mo35a(r0);
    L_0x0059:
        return r1;
    L_0x005a:
        r0 = 24007; // 0x5dc7 float:3.3641E-41 double:1.1861E-319;
        goto L_0x0045;
    L_0x005d:
        r0 = move-exception;
        r4 = "process CT data";	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        com.iprog.p006g.C0104d.m829a(r0, r4);	 Catch:{ Exception -> 0x005d, all -> 0x0069 }
        r0 = 24005; // 0x5dc5 float:3.3638E-41 double:1.186E-319;
        com.iprog.p005e.C0075a.m626a(r2);
        goto L_0x0048;
    L_0x0069:
        r0 = move-exception;
        com.iprog.p005e.C0075a.m626a(r2);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.iprog.f.h.h(com.iprog.f.ac):int");
    }

    private int m660i(ac acVar) {
        int i;
        C0034j c0034j = new C0034j();
        acVar.m710a(c0034j);
        ac acVar2 = new ac(acVar);
        try {
            this.f675f.m629a(c0034j.f194j, c0034j.f202r, c0034j.f201q, c0034j.f203s, c0034j.f204t, "Y");
            acVar2.m707a(0, 0);
            m674b(acVar2);
            i = 1;
        } catch (Exception e) {
            C0104d.m829a(e, "process CT data");
            i = 24005;
        }
        if (i != 1) {
            mo35a(acVar2.m715a(Integer.toString(i).getBytes(), i));
        }
        return 1;
    }

    private int m661j(ac acVar) {
        C0099y c0099y = new C0099y();
        c0099y.m781d(acVar.m698b().f754b);
        c0099y.m783d(acVar.m696a());
        C0104d.m830a("processCreditAdd : Send*****");
        new Thread(new C0087k(this, c0099y)).start();
        return 1;
    }

    private int m662k(ac acVar) {
        C0104d.m830a("processSetDeviceID : Send*****");
        C0099y c0099y = new C0099y();
        c0099y.m781d(acVar.m698b().f754b);
        c0099y.ab = acVar.m696a();
        new Thread(new C0088l(this, c0099y)).start();
        return 1;
    }

    private int m663l(ac acVar) {
        int i;
        ac acVar2 = new ac(acVar);
        Object trim = new String(acVar.m696a()).trim();
        C0104d.m830a("processSetBTName:" + trim);
        if (trim.trim().isEmpty()) {
            i = -1;
        } else {
            C0013d.m42d().m60a(19, trim);
            i = 1;
        }
        mo35a(acVar2.m715a(Integer.toString(i).getBytes(), i));
        return 1;
    }

    private int m664m(ac acVar) {
        int i = -1;
        ac acVar2 = new ac(acVar);
        try {
            if (new String(C0023a.m145b(acVar.m696a(), new byte[]{(byte) 50, (byte) 36, (byte) -84, (byte) -89, (byte) 17, (byte) 51, (byte) 102, (byte) -120, (byte) -90, (byte) -108, (byte) 20, (byte) -112, (byte) 118, (byte) -84, (byte) -85, (byte) -86}, 0, 16), 0, 6).equals("i-PROG")) {
                String[] strArr = new String[]{"DELETE FROM rp_chip_read", "DELETE FROM rp_resent_work", "DELETE FROM rp_work_his"};
                for (String d : strArr) {
                    this.f675f.m641d(d);
                }
                i = 1;
            }
        } catch (Exception e) {
        }
        mo35a(acVar2.m715a(Integer.toString(i).getBytes(), i));
        return 1;
    }

    private int m665n(ac acVar) {
        C0013d d = C0013d.m42d();
        C0011b e = d.m90e();
        String r = d.m119r();
        ac acVar2 = new ac(acVar);
        byte[] bArr = new byte[]{(byte) -45, (byte) -92, (byte) 28, (byte) 87, (byte) 113, (byte) 51, (byte) 86, (byte) -56, (byte) -90, (byte) -108, (byte) 20, (byte) -102, (byte) 118, (byte) 60, (byte) -93, (byte) 26};
        int i;
        try {
            byte[] b = C0023a.m145b(acVar.m696a(), bArr, 0, 32);
            if (b[0] == (byte) 1) {
                byte[] a = C0023a.m141a(e.m31i(), bArr);
                byte[] a2 = C0023a.m141a(e.m24b(), bArr);
                b = C0023a.m141a(C0011b.m15a(), bArr);
                byte[] a3 = C0023a.m141a(r, bArr);
                bArr = C0023a.m141a(Locale.getDefault().toString(), bArr);
                mo35a(acVar2.m715a(new StringBuilder(String.valueOf(new String(C0101a.m819a(a3, 0, a3.length)))).append("|").append(new String(C0101a.m819a(b, 0, b.length))).append("|").append(new String(C0101a.m819a(bArr, 0, bArr.length))).append("|").append(new String(C0101a.m819a(a, 0, a.length))).append("|").append(new String(C0101a.m819a(a2, 0, a2.length))).toString().getBytes(), 1));
                return 1;
            }
            if (b[0] != (byte) 2) {
                i = 24890;
            } else if (new String(b, 1, 16).trim().equals(r)) {
                e.m30h();
                e.m26d();
                d.ah = R.string.dlg_notice_device_reboot;
                i = 1;
            } else {
                i = 24012;
            }
            mo35a(acVar2.m715a(Integer.toString(i).getBytes(), i));
            return 1;
        } catch (Exception e2) {
            C0104d.m828a(e2);
            i = 24999;
        }
    }

    private int m666o(ac acVar) {
        acVar.m710a(new C0034j());
        C0013d d = C0013d.m42d();
        String[] strArr = new String[]{"pt_ver", "fw_ver", "fd_ver", "sw_ver", "xc_ver", "cipher", "session", "device_id", "credit_count", "credit_type", "credit_connect", "mac_addr", "os_ver", "hw_ver", "xe_ver", "hw_ver2", "xr_ver", "credit_ver"};
        ac acVar2 = new ac(acVar);
        acVar2.m717b(strArr);
        String valueOf = String.valueOf(d.f53B);
        if (C0013d.m42d().m110l()) {
            valueOf = String.valueOf(d.f53B + 16);
        }
        String[] strArr2 = new String[18];
        strArr2[0] = d.m131x(d.f90v);
        strArr2[1] = d.m131x(d.f91w);
        strArr2[2] = d.m131x(d.f92x);
        strArr2[3] = d.m131x(d.f93y);
        strArr2[4] = d.m131x(d.f94z);
        strArr2[5] = String.valueOf(d.f56E);
        strArr2[6] = String.valueOf(d.f57F);
        strArr2[7] = d.f55D;
        strArr2[8] = String.valueOf(d.f60I);
        strArr2[9] = String.valueOf(d.f58G);
        strArr2[10] = d.f61J ? "1" : "0";
        strArr2[11] = C0108h.m872g("eth0");
        strArr2[12] = C0013d.m48x();
        strArr2[13] = valueOf;
        strArr2[14] = String.valueOf(d.f53B);
        strArr2[15] = String.valueOf(d.f54C);
        strArr2[16] = d.m131x(d.f52A);
        strArr2[17] = String.valueOf(d.f59H);
        acVar2.m709a(strArr2);
        m674b(acVar2);
        return 1;
    }

    private int m667p(ac acVar) {
        int i = 0;
        acVar.m710a(new C0034j());
        String[] strArr = new String[]{"fnm"};
        try {
            ac acVar2 = new ac(acVar);
            acVar2.m708a(Arrays.asList(strArr));
            File[] listFiles = new File("/data/data/com.iprog.main/fileshid/").listFiles();
            C0104d.m830a("ChipData Size:" + listFiles.length);
            int min = Math.min(1000, listFiles.length);
            while (i < min) {
                acVar2.m709a(new String[]{listFiles[i].getName()});
                C0104d.m830a("chipDataRead:" + listFiles[i].getName());
                i++;
            }
            acVar2.m707a(listFiles.length, listFiles.length);
            m674b(acVar2);
            return 1;
        } catch (Exception e) {
            e.printStackTrace();
            return 24005;
        }
    }

    private int m668q(ac acVar) {
        int i;
        C0034j c0034j = new C0034j();
        acVar.m710a(c0034j);
        String[] strArr = new String[]{"file_name", "file_data"};
        ac acVar2 = new ac(acVar);
        try {
            acVar2.m708a(Arrays.asList(strArr));
            mo35a(acVar2.m715a(C0108h.m871f("/data/data/com.iprog.main/fileshid/" + c0034j.f205u), 1));
            i = 1;
        } catch (Exception e) {
            C0104d.m829a(e, "processChipData");
            i = 24005;
        }
        if (i != 1) {
            mo35a(acVar2.m715a(Integer.toString(i).getBytes(), i));
        }
        return i;
    }

    public void m669a(int i, int i2, int i3) {
        ac acVar = new ac(i, i2);
        if (this.f674e) {
            mo35a(acVar.m718b(i3));
        } else {
            mo35a(acVar.m718b(i3));
        }
    }

    public void m670a(ac acVar, int i) {
        m669a(acVar.m698b().f754b, acVar.m698b().f755c, i);
    }

    public void m671a(C0044n c0044n) {
        this.f677h = c0044n;
    }

    public void mo35a(byte[] bArr) {
        new Thread(new C0086j(this, bArr)).start();
    }

    public boolean m673a(ac acVar) {
        return this.f674e ? m656b(acVar.m721d()) : m656b(acVar.m721d());
    }

    public void m674b(ac acVar) {
        new Thread(new C0085i(this, acVar)).start();
    }

    protected int m675c(ac acVar) {
        if (this.f677h == null || acVar.m698b().f754b != 188) {
            C0013d.m42d().m78b(acVar, 4);
        } else {
            this.f677h.mo18a(acVar);
        }
        return 1;
    }

    public int m676d(ac acVar) {
        int i = 1;
        C0034j c0034j = new C0034j();
        acVar.m710a(c0034j);
        ac acVar2 = new ac(acVar);
        try {
            new File("/data/data/com.iprog.main/fileshid/" + c0034j.f205u).delete();
            C0104d.m830a("processChipDataDel:" + c0034j.f205u);
        } catch (Exception e) {
            Exception exception = e;
            i = 24005;
            C0104d.m829a(exception, "processChipDataDel");
        }
        mo35a(acVar2.m715a(Integer.toString(i).getBytes(), i));
        return i;
    }

    public int m677e(ac acVar) {
        int k;
        switch (acVar.m698b().f754b) {
            case 26:
                C0013d.m42d().m51A(this.f676g);
                k = m662k(acVar);
                break;
            case 96:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 225:
            case 226:
                C0013d.m42d().m51A(this.f676g);
                k = m661j(acVar);
                break;
            case 160:
                k = m667p(acVar);
                break;
            case 161:
                k = m668q(acVar);
                break;
            case 162:
                k = m676d(acVar);
                break;
            case 176:
                k = m666o(acVar);
                break;
            case 177:
                k = m658g(acVar);
                break;
            case 178:
                k = m659h(acVar);
                break;
            case 179:
                k = m660i(acVar);
                break;
            case 181:
                k = m657f(acVar);
                break;
            case 182:
                k = 1;
                break;
            case 183:
                k = m663l(acVar);
                break;
            case 184:
                k = m664m(acVar);
                break;
            case 185:
                k = m665n(acVar);
                break;
            case 186:
            case 187:
            case 188:
            case 189:
                C0013d.m42d().m51A(this.f676g);
                k = m675c(acVar);
                break;
            default:
                C0104d.m830a("XmlPacket msg_id not found.");
                k = 24998;
                break;
        }
        if (k != 1) {
            m669a(acVar.m698b().f754b, acVar.m698b().f755c, k);
        }
        return k;
    }

    public void m678g() {
        byte[] bArr = (byte[]) null;
        try {
            C0104d.m832a("[Dumy Packet:", C0108h.m850a(m652a()));
        } catch (Exception e) {
        }
    }
}
