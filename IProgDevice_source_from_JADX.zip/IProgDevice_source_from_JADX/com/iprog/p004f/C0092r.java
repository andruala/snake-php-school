package com.iprog.p004f;

public class C0092r {
    public int f753a;
    public int f754b;
    public int f755c;
    public int f756d;
    public int f757e;
    byte[] f758f = new byte[1];
    final /* synthetic */ C0079q f759g;

    public C0092r(C0079q c0079q) {
        this.f759g = c0079q;
    }
}
