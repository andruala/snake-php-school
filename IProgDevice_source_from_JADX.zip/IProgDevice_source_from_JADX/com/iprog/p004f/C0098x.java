package com.iprog.p004f;

class C0098x implements C0091p {
    final /* synthetic */ C0096v f783a;

    C0098x(C0096v c0096v) {
        this.f783a = c0096v;
    }
}
