package com.iprog.p004f;

import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;

class C0095u extends Thread {
    boolean f772a = false;
    boolean f773b = false;
    long f774c = 30000;
    long f775d = System.currentTimeMillis();
    final /* synthetic */ C0093s f776e;
    private Object f777f = new Object();

    C0095u(C0093s c0093s) {
        this.f776e = c0093s;
    }

    public void m749a() {
        synchronized (this.f777f) {
            this.f775d = System.currentTimeMillis();
        }
    }

    public void m750a(boolean z) {
        m749a();
        this.f773b = z;
    }

    public void run() {
        C0104d.m830a("Session Thread Start.");
        Object obj = null;
        while (!this.f772a) {
            try {
                C0095u.sleep(1500);
                if (this.f773b) {
                    long currentTimeMillis = System.currentTimeMillis();
                    if (currentTimeMillis - this.f775d > this.f774c) {
                        C0104d.m831a("Session time out", (int) (currentTimeMillis - this.f775d));
                        if (this.f776e.f766n != null) {
                            this.f776e.f766n.mo37a(true);
                            m750a(false);
                        }
                    } else if (currentTimeMillis - this.f775d <= this.f774c - 5000) {
                        obj = null;
                    } else if (obj == null) {
                        this.f776e.m744e();
                        obj = 1;
                    }
                } else {
                    continue;
                }
            } catch (Exception e) {
                C0108h.m857a(this.f776e.f760h, 3, "");
                C0104d.m829a(e, "SessionThread InterruptedException");
            } catch (Exception e2) {
                C0104d.m829a(e2, "SessionThread Exception ");
            }
        }
        C0104d.m830a("Session Thread End");
    }
}
