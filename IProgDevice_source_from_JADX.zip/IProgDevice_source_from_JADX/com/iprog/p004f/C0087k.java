package com.iprog.p004f;

import com.iprog.p006g.C0108h;

class C0087k implements Runnable {
    final /* synthetic */ C0077h f749a;
    private final /* synthetic */ C0099y f750b;

    C0087k(C0077h c0077h, C0099y c0099y) {
        this.f749a = c0077h;
        this.f750b = c0099y;
    }

    public void run() {
        C0082d.m729c().m732a(this.f750b);
        C0108h.m853a(80);
        C0082d.m729c().m734b(2);
    }
}
