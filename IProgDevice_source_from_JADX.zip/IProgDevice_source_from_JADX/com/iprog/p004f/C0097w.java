package com.iprog.p004f;

class C0097w implements C0090o {
    final /* synthetic */ C0096v f782a;

    C0097w(C0096v c0096v) {
        this.f782a = c0096v;
    }

    public boolean mo37a(boolean z) {
        return false;
    }
}
