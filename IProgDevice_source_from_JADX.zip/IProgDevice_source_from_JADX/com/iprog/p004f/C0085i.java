package com.iprog.p004f;

class C0085i implements Runnable {
    final /* synthetic */ C0077h f745a;
    private final /* synthetic */ ac f746b;

    C0085i(C0077h c0077h, ac acVar) {
        this.f745a = c0077h;
        this.f746b = acVar;
    }

    public void run() {
        this.f745a.m673a(this.f746b);
    }
}
