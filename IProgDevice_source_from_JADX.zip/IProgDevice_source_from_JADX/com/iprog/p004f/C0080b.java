package com.iprog.p004f;

import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.util.Log;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;

class C0080b extends Thread {
    final /* synthetic */ C0078a f724a;
    private final BluetoothServerSocket f725b;
    private String f726c;

    public C0080b(C0078a c0078a, boolean z) {
        BluetoothServerSocket listenUsingRfcommWithServiceRecord;
        this.f724a = c0078a;
        this.f726c = z ? "Secure" : "Insecure";
        if (z) {
            try {
                listenUsingRfcommWithServiceRecord = c0078a.f681j.listenUsingRfcommWithServiceRecord("IPROG", C0078a.f679h);
            } catch (Throwable e) {
                Log.e("BluetoothChatService", "Socket Type: " + this.f726c + "listen() failed", e);
                listenUsingRfcommWithServiceRecord = null;
            } catch (Exception e2) {
                C0104d.m829a(e2, "Bluetooth Error :");
                C0108h.m853a(3000);
                listenUsingRfcommWithServiceRecord = null;
            }
        } else {
            listenUsingRfcommWithServiceRecord = c0078a.f681j.listenUsingInsecureRfcommWithServiceRecord("BluetoothChatInsecure", C0078a.f680i);
        }
        this.f725b = listenUsingRfcommWithServiceRecord;
    }

    public void m723a() {
        try {
            this.f725b.close();
        } catch (Exception e) {
            C0104d.m829a(e, "Socket Type" + this.f726c + "close() of server failed");
        } catch (Exception e2) {
            C0104d.m829a(e2, "Bluetooth cancel");
        }
    }

    public void run() {
        setName("AcceptThread" + this.f726c);
        while (this.f724a.f685n != 3) {
            try {
                BluetoothSocket accept = this.f725b.accept();
                if (accept != null) {
                    synchronized (this.f724a) {
                        switch (this.f724a.f685n) {
                            case 0:
                            case 3:
                                try {
                                    accept.close();
                                    break;
                                } catch (Throwable e) {
                                    Log.e("BluetoothChatService", "Could not close unwanted socket", e);
                                    break;
                                }
                            case 1:
                            case 2:
                                this.f724a.m686a(accept, accept.getRemoteDevice(), this.f726c);
                                break;
                        }
                    }
                }
            } catch (Throwable e2) {
                Log.e("BluetoothChatService", "Socket Type: " + this.f726c + "accept() failed", e2);
                return;
            } catch (Exception e3) {
                C0104d.m829a(e3, "Bluetooth accept Error");
                C0108h.m853a(2000);
                return;
            }
        }
        return;
    }
}
