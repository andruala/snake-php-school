package com.iprog.p004f;

import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.nio.ByteBuffer;

public class C0100z {
    public int f836a = 0;
    public int f837b = 0;
    public byte f838c = (byte) 0;
    public byte f839d = (byte) 0;
    public int f840e = 1;
    public int f841f = 0;
    public int f842g = 0;
    public byte[] f843h = new byte[8];
    final /* synthetic */ C0099y f844i;

    public C0100z(C0099y c0099y) {
        this.f844i = c0099y;
    }

    public boolean m812a(byte[] bArr) {
        if (bArr.length < 8) {
            C0104d.m831a("Header Length Error", bArr.length);
            return false;
        }
        System.arraycopy(bArr, 0, this.f843h, 0, this.f843h.length);
        ByteBuffer wrap = ByteBuffer.wrap(bArr);
        try {
            wrap.order(C0099y.f784a);
            this.f836a = C0108h.m842a(wrap.get());
            this.f837b = C0108h.m842a(wrap.get());
            this.f838c = wrap.get();
            this.f839d = wrap.get();
            this.f841f = wrap.getShort();
            this.f842g = wrap.getShort();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public byte[] m813a() {
        ByteBuffer allocate = ByteBuffer.allocate(8);
        allocate.order(C0099y.f784a);
        allocate.put((byte) -95);
        allocate.put((byte) this.f837b);
        allocate.put(this.f838c);
        allocate.put(this.f839d);
        allocate.putShort((short) this.f844i.ah.length);
        allocate.putShort((short) this.f842g);
        this.f843h = allocate.array();
        return this.f843h;
    }
}
