package com.iprog.p004f;

import com.iprog.p001b.C0012c;
import com.iprog.p001b.C0013d;
import com.iprog.p006g.C0102b;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class C0099y {
    public static final ByteOrder f784a = ByteOrder.LITTLE_ENDIAN;
    public C0100z f785A = new C0100z(this);
    public int f786B = 0;
    public int f787C = 0;
    public int f788D = 0;
    public int f789E = 0;
    public int f790F = 0;
    public boolean f791G = true;
    public int f792H = 2;
    public int f793I = 0;
    public int f794J = 2;
    public int f795K = 0;
    public int f796L = 0;
    public int f797M = 0;
    public int f798N = 17;
    public int f799O = 0;
    public int f800P = 1;
    public int f801Q = 0;
    public byte[] f802R = new byte[16];
    public byte[] f803S = new byte[16];
    public int f804T = 258;
    public int f805U = 0;
    public int f806V = 1;
    public int f807W = 0;
    public int f808X = 0;
    public int f809Y = 0;
    public int f810Z = 0;
    public byte[] aa = new byte[512];
    byte[] ab = new byte[16];
    public byte[] ac = null;
    public int ad = 0;
    public boolean ae = false;
    private int af;
    private int ag;
    private byte[] ah = null;
    private byte[] ai = null;
    private int aj = 0;
    private byte[] ak = null;
    public int f811b = 0;
    public int f812c = 0;
    public int f813d = 0;
    int f814e = 0;
    public int f815f;
    public int f816g;
    public int f817h;
    public boolean f818i = false;
    public int f819j = 0;
    public String f820k;
    int f821l = 1;
    public int f822m = 0;
    public int f823n = 0;
    public boolean f824o = true;
    public int f825p = 0;
    public boolean f826q = false;
    public int f827r = 0;
    public boolean f828s = false;
    public boolean f829t = false;
    public boolean f830u = false;
    public boolean f831v = false;
    public int f832w = 0;
    public int f833x = 0;
    public int f834y = 0;
    public boolean f835z = false;

    private String m753a(ByteBuffer byteBuffer, int i) {
        byte[] bArr = new byte[i];
        byteBuffer.get(bArr);
        return bArr[0] == (byte) 0 ? "" : new String(bArr).trim();
    }

    public static boolean m754a(byte b) {
        return b == (byte) 2;
    }

    public static boolean m756b(int i) {
        return C0099y.m754a((byte) i);
    }

    private byte m757e(boolean z) {
        return z ? (byte) 2 : (byte) 1;
    }

    public static String m758j(int i) {
        return i < 1 ? " " : String.valueOf(i - 1);
    }

    public static String m759k(int i) {
        return i < 1 ? " " : new StringBuilder(String.valueOf(String.valueOf(i - 1))).append("%").toString();
    }

    public static String m760l(int i) {
        if (i < 1) {
            return " ";
        }
        return String.format("%.1f", new Object[]{Double.valueOf(((double) i) / 10.0d)});
    }

    public static String m761m(int i) {
        return i == 2 ? "ON" : i == 1 ? "OFF" : " ";
    }

    public static String m762n(int i) {
        return i == 2 ? "NON HP" : i == 1 ? "HP" : " ";
    }

    public int m763A() {
        return this.f785A.f842g;
    }

    public String m764B() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("진행상태:").append(this.f807W).append("\n");
        stringBuilder.append("현재상태:").append(this.f808X).append("\n");
        stringBuilder.append("전체상태:").append(this.f809Y).append("\n");
        stringBuilder.append("모델변경여부:").append(this.f818i).append("\n");
        stringBuilder.append("모델번호:").append(this.f812c).append("\n");
        stringBuilder.append("New 칩여부:").append(this.f822m).append("\n");
        stringBuilder.append("국가:").append(this.f815f).append("\n");
        stringBuilder.append("용량:").append(this.af).append("\n");
        stringBuilder.append("컬러:").append(this.f816g).append("\n");
        stringBuilder.append("잔량:").append(this.f817h).append("\n");
        stringBuilder.append("용량구분:").append(this.f821l).append("\n");
        stringBuilder.append("비표:").append(this.f819j).append("\n");
        stringBuilder.append("시리얼번호:").append(this.f820k).append("\n");
        stringBuilder.append("오토리젼:").append(this.f827r).append("\n");
        stringBuilder.append("인쇄매수:").append(this.f825p).append("\n");
        stringBuilder.append("칩버전:").append(this.f823n).append("\n");
        stringBuilder.append("OEM구분:").append(this.f824o).append("\n");
        stringBuilder.append("크래딧 용량_외부:").append(this.f786B).append("\n");
        stringBuilder.append("시리즈:").append(this.f813d).append("\n");
        stringBuilder.append("외부안테나:").append(this.f830u).append("\n");
        stringBuilder.append("최초용량:").append(this.ag).append("\n");
        return stringBuilder.toString();
    }

    public void m765a() {
        ByteBuffer allocate = ByteBuffer.allocate(16);
        byte[] bArr = new byte[7];
        allocate.order(f784a);
        allocate.put((byte) this.f811b);
        allocate.putInt(this.f812c);
        allocate.put((byte) this.f813d);
        allocate.put((byte) this.f814e);
        allocate.put(m757e(this.ae));
        allocate.put(m757e(this.f830u));
        allocate.put(bArr);
        this.ah = C0013d.m42d().m83b(allocate.array(), 0, 16);
    }

    public void m766a(String str) {
        this.f812c = C0012c.m32a(Integer.parseInt(str));
    }

    public void m767a(boolean z) {
        this.f826q = z;
    }

    public void m768a(boolean z, boolean z2) {
        if (z) {
            this.f827r = z2 ? 2 : 1;
        } else {
            this.f827r = 0;
        }
    }

    public boolean m769a(int i) {
        int[] iArr = new int[]{16, 32, 33, 48, 49, 50, 51, 64, 80, 81, 96, 97, 98, 99, 100, 101, 112, 113, 114, 115, 129, 130, 131, 133, 134, 135, 138, 139, 140, 194, 202, 26, 225, 226};
        for (int i2 : iArr) {
            if (i == i2) {
                return true;
            }
        }
        return false;
    }

    public boolean m770a(byte[] bArr) {
        if (C0108h.m842a(bArr[0]) == 161) {
            return m769a(C0108h.m842a(bArr[1]));
        }
        C0104d.m830a("Packet START BIT Error");
        return false;
    }

    public boolean m771a(byte[] bArr, int i, int i2) {
        this.ah = new byte[i2];
        System.arraycopy(bArr, i, this.ah, 0, i2);
        switch (this.f785A.f837b) {
            case 16:
                return m806u();
            case 26:
                m805t();
                return false;
            case 32:
            case 64:
                return m773b();
            case 33:
                return m800o();
            case 48:
            case 49:
            case 50:
            case 51:
                return m797l();
            case 80:
                return m798m();
            case 81:
                return m799n();
            case 113:
            case 129:
            case 133:
            case 138:
                m802q();
                return false;
            case 114:
            case 130:
            case 134:
            case 139:
                m803r();
                return false;
            case 115:
            case 131:
            case 135:
            case 140:
                m804s();
                return false;
            case 194:
                return m801p();
            default:
                return false;
        }
    }

    public void m772b(boolean z) {
        this.f828s = z;
    }

    public boolean m773b() {
        ByteBuffer wrap = ByteBuffer.wrap(C0013d.m42d().m74a(this.ah, 0, this.ah.length));
        try {
            wrap.order(f784a);
            this.f807W = C0108h.m842a(wrap.get());
            this.f808X = C0108h.m842a(wrap.get());
            this.f809Y = C0108h.m842a(wrap.get());
            this.f810Z = C0108h.m842a(wrap.get());
            this.f831v = C0099y.m754a(wrap.get());
            this.f813d = C0108h.m842a(wrap.get());
            this.f830u = C0099y.m754a(wrap.get());
            this.ag = wrap.getShort();
            this.f786B = wrap.getInt();
            this.f818i = C0099y.m754a(wrap.get());
            this.f812c = wrap.getInt();
            this.f822m = C0108h.m842a(wrap.get());
            this.f815f = C0108h.m845a(wrap.getShort());
            this.af = wrap.getShort();
            this.f816g = C0108h.m842a(wrap.get());
            this.f817h = C0108h.m842a(wrap.get());
            this.f821l = C0108h.m842a(wrap.get());
            this.f819j = C0108h.m842a(wrap.get());
            this.f820k = m753a(wrap, 16);
            this.f827r = C0108h.m842a(wrap.get());
            this.f825p = wrap.getShort();
            this.f823n = C0108h.m842a(wrap.get());
            this.f824o = wrap.get() != (byte) 2;
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "parseSearchData");
            return false;
        }
    }

    public boolean m774b(byte[] bArr) {
        return m775b(bArr, 0, bArr.length);
    }

    public boolean m775b(byte[] bArr, int i, int i2) {
        if (C0102b.m821a(bArr, 0, i2 - 2) == ((bArr[i2 - 2] & 255) * 256) + (bArr[i2 - 1] & 255)) {
            return true;
        }
        this.f785A.f842g = 23204;
        C0104d.m832a("*******CRC Error*****", String.format("%x,%x", new Object[]{Integer.valueOf(r2), Integer.valueOf(r3)}));
        return false;
    }

    public void m776c() {
        ByteBuffer allocate = ByteBuffer.allocate(16);
        allocate.order(f784a);
        allocate.put((byte) this.f811b);
        allocate.put((byte) this.f813d);
        allocate.putInt(this.f812c);
        allocate.putShort((short) this.f815f);
        allocate.putShort((short) this.af);
        allocate.put((byte) this.f816g);
        allocate.put(m757e(this.f826q));
        allocate.put(m757e(this.f830u));
        allocate.put((byte) this.f827r);
        allocate.put(m757e(this.f828s));
        allocate.put(m757e(this.f831v));
        byte[] array = allocate.array();
        C0104d.m830a("[MAKE:" + array.length + "]\n" + C0108h.m850a(array));
        this.ah = C0013d.m42d().m83b(allocate.array(), 0, 16);
    }

    public void m777c(int i) {
        this.f811b = i;
    }

    public void m778c(boolean z) {
        this.f830u = z;
    }

    public boolean m779c(byte[] bArr) {
        return this.f785A.m812a(bArr);
    }

    public void m780d() {
        ByteBuffer allocate = ByteBuffer.allocate(this.ak.length);
        allocate.order(f784a);
        allocate.put(this.ak);
        this.ah = allocate.array();
    }

    public void m781d(int i) {
        this.f785A.f837b = i;
    }

    public void m782d(boolean z) {
        this.f831v = z;
    }

    public void m783d(byte[] bArr) {
        this.ak = new byte[bArr.length];
        System.arraycopy(bArr, 0, this.ak, 0, bArr.length);
    }

    public void m784e() {
        byte[] bArr = new byte[12];
        ByteBuffer allocate = ByteBuffer.allocate(32);
        allocate.order(f784a);
        allocate.put((byte) 3);
        allocate.putShort((short) this.f789E);
        allocate.put((byte) this.f801Q);
        allocate.put(this.f803S);
        allocate.put(bArr);
        this.ah = allocate.array();
    }

    public void m785e(int i) {
        this.f813d = i;
    }

    public void m786e(byte[] bArr) {
        System.arraycopy(bArr, 0, this.f803S, 0, Math.min(bArr.length, this.f803S.length));
    }

    public void m787f() {
        ByteBuffer allocate = ByteBuffer.allocate(16);
        allocate.order(f784a);
        allocate.put((byte) 1);
        allocate.putInt(0);
        allocate.putInt(0);
        allocate.put((byte) 0);
        this.ah = allocate.array();
    }

    public void m788f(int i) {
        this.f815f = i;
    }

    public void m789g() {
        ByteBuffer allocate = ByteBuffer.allocate(16);
        short s = (short) this.f804T;
        allocate.order(f784a);
        allocate.put((byte) (((65280 & s) >> 8) & 255));
        allocate.put((byte) ((s & 255) & 255));
        allocate.putInt(this.f805U);
        allocate.put(C0108h.m860a("", 10));
        this.ah = allocate.array();
    }

    public void m790g(int i) {
        this.af = i / 100;
    }

    public void m791h() {
        ByteBuffer allocate = ByteBuffer.allocate(514);
        allocate.order(f784a);
        allocate.putShort((short) this.f806V);
        allocate.put(this.aa);
        this.ah = allocate.array();
    }

    public void m792h(int i) {
        this.f816g = i;
    }

    public void m793i() {
        ByteBuffer allocate = ByteBuffer.allocate(74);
        allocate.order(f784a);
        allocate.putShort((short) this.f806V);
        allocate.put(this.aa, 0, 72);
        this.ah = allocate.array();
        C0104d.m830a(C0108h.m850a(this.ah));
    }

    public void m794i(int i) {
        this.f785A.f842g = i;
    }

    public void m795j() {
        C0104d.m830a("****************makeFwUpEnd****************");
    }

    public void m796k() {
        ByteBuffer allocate = ByteBuffer.allocate(16);
        allocate.order(f784a);
        allocate.put(this.ab, 0, 16);
        this.ah = allocate.array();
    }

    public boolean m797l() {
        ByteBuffer wrap = ByteBuffer.wrap(C0013d.m42d().m74a(this.ah, 0, this.ah.length));
        wrap.order(f784a);
        try {
            this.f807W = wrap.get();
            this.f808X = C0108h.m842a(wrap.get());
            this.f809Y = C0108h.m842a(wrap.get());
            this.f810Z = C0108h.m842a(wrap.get());
            this.f831v = C0099y.m754a(wrap.get());
            this.f813d = C0108h.m842a(wrap.get());
            this.f830u = C0099y.m754a(wrap.get());
            this.ag = wrap.getShort();
            this.f786B = wrap.getInt();
            this.f818i = C0099y.m754a(wrap.get());
            this.f812c = wrap.getInt();
            this.f822m = wrap.get();
            this.f815f = C0108h.m845a(wrap.getShort());
            this.af = wrap.getShort();
            this.f816g = wrap.get();
            this.f817h = wrap.get();
            this.f821l = wrap.get();
            this.f819j = C0108h.m842a(wrap.get());
            this.f820k = m753a(wrap, 16);
            this.f827r = C0108h.m842a(wrap.get());
            this.f825p = wrap.getShort();
            this.f823n = C0108h.m842a(wrap.get());
            this.f824o = wrap.get() != (byte) 2;
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "parseProcessData");
            return false;
        }
    }

    public boolean m798m() {
        ByteBuffer wrap = ByteBuffer.wrap(this.ah);
        wrap.order(f784a);
        try {
            this.f807W = wrap.get();
            if (this.f807W == 1 || this.f807W == 2) {
                this.ad = wrap.getShort();
                int i = this.f785A.f841f - 3;
                C0104d.m830a("chip read data len:" + this.ad);
                C0104d.m830a("chip data_len:" + i);
                if (i <= 0) {
                    return true;
                }
                this.ac = new byte[i];
                wrap.get(this.ac);
                return true;
            }
            this.f808X = C0108h.m842a(wrap.get());
            this.f809Y = C0108h.m842a(wrap.get());
            wrap.get();
            this.f831v = C0099y.m754a(wrap.get());
            this.f813d = C0108h.m842a(wrap.get());
            this.f830u = C0099y.m754a(wrap.get());
            this.ag = wrap.getShort();
            this.f786B = wrap.getInt();
            this.f818i = C0099y.m754a(wrap.get());
            this.f812c = wrap.getInt();
            this.f822m = C0108h.m842a(wrap.get());
            this.f815f = C0108h.m845a(wrap.getShort());
            this.af = wrap.getShort();
            this.f816g = C0108h.m842a(wrap.get());
            this.f817h = C0108h.m842a(wrap.get());
            this.f821l = C0108h.m842a(wrap.get());
            this.f819j = C0108h.m842a(wrap.get());
            this.f820k = m753a(wrap, 16);
            this.f827r = C0108h.m842a(wrap.get());
            this.f825p = wrap.getShort();
            this.f823n = C0108h.m842a(wrap.get());
            this.f824o = wrap.get() != (byte) 2;
            this.f818i = this.f812c != 0;
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "parserChipRead");
            return false;
        }
    }

    public boolean m799n() {
        ByteBuffer wrap = ByteBuffer.wrap(this.ah);
        wrap.order(f784a);
        try {
            this.f807W = wrap.get();
            if (this.f807W == 1 || this.f807W == 2) {
                this.ad = wrap.getShort();
                int i = this.f785A.f841f - 3;
                C0104d.m830a("chip read data len:" + this.ad);
                C0104d.m830a("chip data_len:" + i);
                if (i <= 0) {
                    return true;
                }
                this.ac = new byte[i];
                wrap.get(this.ac);
                return true;
            }
            this.f813d = C0108h.m842a(wrap.get());
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "parserChipReadHid");
            return false;
        }
    }

    public boolean m800o() {
        ByteBuffer wrap = ByteBuffer.wrap(C0013d.m42d().m74a(this.ah, 0, this.ah.length));
        wrap.order(f784a);
        try {
            this.f829t = C0099y.m754a(wrap.get());
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "parserChipExist");
            return false;
        }
    }

    public boolean m801p() {
        try {
            ByteBuffer wrap = ByteBuffer.wrap(this.ah);
            wrap.order(f784a);
            this.f832w = C0108h.m842a(wrap.get());
            this.f833x = C0108h.m842a(wrap.get());
            this.f834y = wrap.getInt();
            this.f835z = C0099y.m754a(wrap.get());
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "parserChipExist");
            return false;
        }
    }

    public boolean m802q() {
        ByteBuffer.wrap(this.ah).order(f784a);
        return true;
    }

    public boolean m803r() {
        ByteBuffer wrap = ByteBuffer.wrap(this.ah);
        wrap.order(f784a);
        try {
            this.f806V = C0108h.m845a(wrap.getShort());
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "parserFwUpStart");
            return false;
        }
    }

    public boolean m804s() {
        ByteBuffer wrap = ByteBuffer.wrap(this.ah);
        wrap.order(f784a);
        try {
            this.f806V = C0108h.m845a(wrap.getShort());
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "parserFwUpEnd");
            return false;
        }
    }

    public boolean m805t() {
        ByteBuffer wrap = ByteBuffer.wrap(this.ah);
        wrap.order(f784a);
        try {
            byte[] bArr = new byte[4];
            wrap.get(bArr);
            this.f799O = C0108h.m864b(bArr);
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "parserDeviceChange");
            return false;
        }
    }

    public boolean m806u() {
        ByteBuffer wrap = ByteBuffer.wrap(this.ah);
        wrap.order(f784a);
        try {
            this.f787C = C0108h.m842a(wrap.get());
            short s = wrap.getShort();
            this.f788D = ((s & 65280) >> 8) | ((s & 255) << 8);
            s = wrap.getShort();
            this.f790F = ((s & 65280) >> 8) | ((s & 255) << 8);
            byte b = wrap.get();
            this.f800P = b;
            if (b == (byte) 2 || b == (byte) 1 || b == (byte) 0) {
                this.f791G = C0099y.m754a(b);
            } else {
                this.f791G = true;
            }
            this.f794J = C0108h.m842a(wrap.get());
            s = wrap.getShort();
            this.f795K = ((s & 65280) >> 8) | ((s & 255) << 8);
            wrap.get(new byte[13]);
            this.f792H = C0108h.m842a(wrap.get());
            s = wrap.getShort();
            this.f793I = ((s & 65280) >> 8) | ((s & 255) << 8);
            byte[] bArr = new byte[4];
            wrap.get(bArr);
            this.f799O = C0108h.m864b(bArr);
            this.f796L = C0108h.m842a(wrap.get());
            this.f797M = C0108h.m842a(wrap.get());
            this.f798N = C0108h.m842a(wrap.get());
            if (this.f798N >= 18) {
                return true;
            }
            this.f794J = 2;
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "parserMessageInit");
            return false;
        }
    }

    public byte[] m807v() {
        switch (this.f785A.f837b) {
            case 16:
                m784e();
                break;
            case 26:
                m796k();
                break;
            case 32:
            case 33:
            case 64:
            case 80:
                m765a();
                break;
            case 48:
            case 49:
            case 50:
            case 51:
                m776c();
                break;
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 225:
            case 226:
                m780d();
                break;
            case 112:
                m787f();
                break;
            case 113:
            case 129:
            case 133:
            case 138:
                m789g();
                break;
            case 114:
            case 130:
                m791h();
                break;
            case 115:
            case 131:
            case 135:
            case 140:
                m795j();
                break;
            case 134:
            case 139:
                m793i();
                break;
            default:
                C0104d.m830a("***********ERROR unknow msg id***************");
                C0104d.m830a("MSG_ID:" + this.f785A.f837b);
                return null;
        }
        if (this.ah == null) {
            return null;
        }
        this.f785A.f841f = this.ah.length;
        Object a = this.f785A.m813a();
        this.ai = new byte[((a.length + this.ah.length) + 2)];
        System.arraycopy(a, 0, this.ai, 0, a.length);
        System.arraycopy(this.ah, 0, this.ai, a.length, this.ah.length);
        System.arraycopy(C0102b.m822b(this.ai, 0, a.length + this.ah.length), 0, this.ai, a.length + this.ah.length, 2);
        int i = this.f785A.f837b;
        return this.ai;
    }

    public int m808w() {
        return this.f785A.f837b;
    }

    public int m809x() {
        return this.af * 100;
    }

    public int m810y() {
        return this.ag * 100;
    }

    public byte[] m811z() {
        return this.ah;
    }
}
