package com.iprog.p004f;

import android.bluetooth.BluetoothSocket;
import android.util.Log;
import com.iprog.p006g.C0104d;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

class C0081c extends Thread {
    final /* synthetic */ C0078a f727a;
    private final BluetoothSocket f728b;
    private final InputStream f729c;
    private final OutputStream f730d;

    public C0081c(C0078a c0078a, BluetoothSocket bluetoothSocket, String str) {
        InputStream inputStream;
        Throwable e;
        OutputStream outputStream = null;
        this.f727a = c0078a;
        Log.d("BluetoothChatService", "create ConnectedThread: " + str);
        this.f728b = bluetoothSocket;
        try {
            inputStream = bluetoothSocket.getInputStream();
            try {
                outputStream = bluetoothSocket.getOutputStream();
            } catch (IOException e2) {
                e = e2;
                Log.e("BluetoothChatService", "temp sockets not created", e);
                this.f729c = inputStream;
                this.f730d = outputStream;
                c0078a.m648a(this.f729c, this.f730d);
            }
        } catch (Throwable e3) {
            e = e3;
            inputStream = outputStream;
            Log.e("BluetoothChatService", "temp sockets not created", e);
            this.f729c = inputStream;
            this.f730d = outputStream;
            c0078a.m648a(this.f729c, this.f730d);
        }
        this.f729c = inputStream;
        this.f730d = outputStream;
        c0078a.m648a(this.f729c, this.f730d);
    }

    public void m724a() {
        try {
            this.f728b.close();
        } catch (Throwable e) {
            Log.e("BluetoothChatService", "close() of connect socket failed", e);
        }
    }

    public void run() {
        C0104d.m830a("BEGIN mConnectedThread");
        while (true) {
            ac acVar = new ac();
            try {
                C0104d.m830a("###Bluetooth Read Wait##");
                if (this.f727a.m653a(1)[0] == (byte) -95) {
                    byte[] bArr;
                    byte[] a = this.f727a.m653a(1);
                    Object obj = new byte[]{bArr[0], a[0]};
                    if (acVar.m695a((byte[]) obj)) {
                        Object a2 = this.f727a.m653a(8);
                        Object obj2 = new byte[10];
                        System.arraycopy(obj, 0, obj2, 0, 2);
                        System.arraycopy(a2, 0, obj2, 2, a2.length);
                        acVar.m699b(obj2);
                        C0104d.m830a(String.format("READ HEAD[%02x,%d,%d]", new Object[]{Integer.valueOf(acVar.m698b().f754b), Integer.valueOf(acVar.m698b().f755c), Integer.valueOf(acVar.m698b().f756d)}));
                        if (acVar.m698b().f756d < 10240000) {
                            try {
                                bArr = (byte[]) null;
                                bArr = this.f727a.m654a(acVar.m698b().f756d, 50);
                                C0104d.m830a("READ BODY[" + bArr.length + "]");
                                if (bArr.length == acVar.m698b().f756d) {
                                    acVar.m700c(bArr);
                                    this.f727a.m677e(acVar);
                                } else {
                                    this.f727a.m670a(acVar, 24002);
                                }
                            } catch (Exception e) {
                                C0104d.m829a(e, "Manager Service Receive Body");
                                this.f727a.m670a(acVar, 24003);
                            } catch (IOException e2) {
                                C0104d.m830a("Bluetooth ConnectedThread  disconnected");
                                this.f727a.m685h();
                                this.f727a.m687c();
                                return;
                            }
                        }
                        this.f727a.m670a(acVar, 24004);
                    } else {
                        C0104d.m830a(String.format("HEADER ERROR :%02x,%02x", new Object[]{Byte.valueOf(obj[0]), Byte.valueOf(obj[1])}));
                    }
                } else {
                    continue;
                }
            } catch (IOException e22) {
                C0104d.m830a("Bluetooth ConnectedThread  disconnected");
                this.f727a.m685h();
                this.f727a.m687c();
                return;
            } catch (Exception e3) {
                C0104d.m829a(e3, "ReadThread Warning..........");
            }
        }
    }
}
