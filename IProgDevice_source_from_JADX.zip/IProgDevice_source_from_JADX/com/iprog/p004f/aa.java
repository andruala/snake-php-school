package com.iprog.p004f;

import java.util.ArrayList;
import java.util.List;
import org.apache.http.message.BasicNameValuePair;

public class aa {
    List f687a = new ArrayList();

    public List m689a() {
        return this.f687a;
    }

    public void m690a(String str, int i) {
        m691a(str, String.valueOf(i));
    }

    public void m691a(String str, String str2) {
        this.f687a.add(new BasicNameValuePair(str, str2));
    }
}
