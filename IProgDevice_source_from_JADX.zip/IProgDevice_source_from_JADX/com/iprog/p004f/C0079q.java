package com.iprog.p004f;

import com.iprog.p006g.C0108h;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class C0079q {
    public static ByteOrder f711a = ByteOrder.LITTLE_ENDIAN;
    public byte[] f712b = null;
    private C0092r f713c = new C0092r(this);

    public static int m693a(byte b) {
        return C0108h.m842a(b);
    }

    public boolean m694a(int i) {
        int[] iArr = new int[]{176, 177, 178, 179, 180, 181, 182, 186, 187, 96, 97, 98, 99, 100, 101, 186, 187, 188, 189, 26, 183, 184, 185, 225, 226, 160, 161, 162};
        for (int i2 : iArr) {
            if (i == i2) {
                return true;
            }
        }
        return false;
    }

    public boolean m695a(byte[] bArr) {
        return C0108h.m842a(bArr[0]) == 161 ? m694a(C0108h.m842a(bArr[1])) : false;
    }

    public byte[] m696a() {
        return this.f712b;
    }

    public byte[] m697a(int i, int i2, int i3) {
        ByteBuffer allocate = ByteBuffer.allocate(10);
        allocate.order(f711a);
        allocate.put((byte) -95);
        allocate.put((byte) i);
        allocate.put((byte) this.f713c.f755c);
        allocate.putInt(i3);
        allocate.putShort((short) i2);
        return allocate.array();
    }

    public C0092r m698b() {
        return this.f713c;
    }

    public boolean m699b(byte[] bArr) {
        try {
            ByteBuffer wrap = ByteBuffer.wrap(bArr);
            wrap.order(f711a);
            this.f713c.f753a = C0079q.m693a(wrap.get());
            this.f713c.f754b = C0079q.m693a(wrap.get());
            this.f713c.f755c = C0079q.m693a(wrap.get());
            this.f713c.f756d = wrap.getInt();
            this.f713c.f757e = C0108h.m845a(wrap.getShort());
            wrap.get(this.f713c.f758f);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void m700c(byte[] bArr) {
        this.f712b = bArr;
    }
}
