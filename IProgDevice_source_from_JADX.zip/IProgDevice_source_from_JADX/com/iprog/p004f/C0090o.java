package com.iprog.p004f;

public interface C0090o {
    boolean mo37a(boolean z);
}
