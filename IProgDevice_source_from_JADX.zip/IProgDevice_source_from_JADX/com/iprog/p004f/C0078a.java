package com.iprog.p004f;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import com.iprog.p001b.C0013d;
import java.util.UUID;

public class C0078a extends C0077h {
    private static final UUID f679h = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");
    private static final UUID f680i = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");
    private final BluetoothAdapter f681j = BluetoothAdapter.getDefaultAdapter();
    private final Handler f682k;
    private C0080b f683l;
    private C0081c f684m;
    private int f685n = 0;
    private Handler f686o;

    public C0078a(Context context, Handler handler) {
        super(2);
        this.f682k = handler;
        this.f686o = handler;
    }

    private synchronized void m681b(int i) {
        this.f685n = i;
    }

    private void m685h() {
        C0013d.m42d().m70a(this.f686o, 11, (Object) "");
        m687c();
    }

    public synchronized void m686a(BluetoothSocket bluetoothSocket, BluetoothDevice bluetoothDevice, String str) {
        if (this.f684m != null) {
            this.f684m.m724a();
            this.f684m = null;
        }
        if (this.f683l != null) {
            this.f683l.m723a();
            this.f683l = null;
        }
        this.f684m = new C0081c(this, bluetoothSocket, str);
        this.f684m.start();
        Object bundle = new Bundle();
        bundle.putString("name", bluetoothDevice.getName());
        bundle.putString("address", bluetoothDevice.getAddress());
        C0013d.m42d().m82b(this.f686o, 10, bundle);
        m681b(3);
    }

    public synchronized void m687c() {
        if (this.f684m != null) {
            this.f684m.m724a();
            this.f684m = null;
        }
        m681b(1);
        if (this.f683l == null) {
            this.f683l = new C0080b(this, true);
            this.f683l.start();
        }
    }

    public synchronized void m688d() {
        if (this.f684m != null) {
            this.f684m.m724a();
            this.f684m = null;
        }
        if (this.f683l != null) {
            this.f683l.m723a();
            this.f683l = null;
        }
        m681b(0);
    }
}
