package com.iprog.p004f;

import com.iprog.io.C0076a;
import com.iprog.p001b.C0013d;
import com.iprog.p006g.C0101a;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.io.FileDescriptor;
import org.apache.http.util.ByteArrayBuffer;

public class C0082d extends C0076a {
    static byte f731e = (byte) 0;
    static C0082d f732h = new C0082d();
    C0084g f733f = null;
    C0083f f734g = null;
    Object f735i = new Object();
    C0045e f736j = null;

    private C0082d() {
    }

    private void m727a(C0099y c0099y, int i) {
        switch (c0099y.m808w()) {
            case 114:
            case 130:
                if (this.f736j != null) {
                    this.f736j.mo20a(c0099y);
                    return;
                }
                break;
        }
        C0013d.m42d().m79b(c0099y, 3);
    }

    public static C0082d m729c() {
        return f732h;
    }

    private void m730e() {
        byte[] bArr = (byte[]) null;
        try {
            bArr = m652a();
            if (C0013d.f50d) {
                C0104d.m830a(String.format("[Dumy Packet:%d]\n%s", new Object[]{Integer.valueOf(bArr.length), C0108h.m850a(bArr)}));
            }
        } catch (Exception e) {
        }
    }

    public void m731a(C0045e c0045e) {
        this.f736j = c0045e;
    }

    public boolean m732a(C0099y c0099y) {
        return m733a(c0099y, true);
    }

    public boolean m733a(C0099y c0099y, boolean z) {
        boolean z2 = false;
        try {
            C0100z c0100z = c0099y.f785A;
            byte b = (byte) (f731e + 1);
            f731e = b;
            c0100z.f838c = b;
            ByteArrayBuffer byteArrayBuffer = new ByteArrayBuffer(1024);
            char[] a = C0101a.m817a(c0099y.m807v());
            byteArrayBuffer.append(a, 0, a.length);
            byteArrayBuffer.append(10);
            byte[] v = c0099y.m807v();
            C0104d.m830a("[SEND B:" + v.length + "]\n" + C0108h.m850a(v));
            if (z) {
                this.f733f.m739a(1);
            }
            z2 = m656b(byteArrayBuffer.toByteArray());
        } catch (Exception e) {
            C0104d.m829a(e, "FBSocket");
        }
        return z2;
    }

    public void m734b(int i) {
        this.f733f.m739a(i);
    }

    public boolean m735b(FileDescriptor fileDescriptor) {
        try {
            m646a(fileDescriptor);
            this.f733f = new C0084g();
            this.f733f.start();
            this.f734g = new C0083f();
            this.f734g.start();
            return true;
        } catch (Exception e) {
            C0104d.m829a(e, "FbSocket start");
            m655b();
            return false;
        }
    }

    public void m736d() {
        C0104d.m830a("FbSocket Stop..");
        try {
            if (this.f733f != null) {
                this.f733f.m738a();
            }
        } catch (Exception e) {
        }
        try {
            if (this.f734g != null) {
                this.f734g.m737a();
            }
        } catch (Exception e2) {
        }
        this.f733f = null;
        this.f734g = null;
        super.m655b();
    }
}
