package com.iprog.p004f;

import com.iprog.p001b.C0013d;
import com.iprog.p006g.C0104d;

class C0084g extends Thread {
    long f740a;
    long f741b;
    boolean f742c;
    boolean f743d;
    final /* synthetic */ C0082d f744e;

    private C0084g(C0082d c0082d) {
        this.f744e = c0082d;
        this.f740a = System.currentTimeMillis();
        this.f741b = System.currentTimeMillis();
        this.f742c = false;
        this.f743d = false;
    }

    public void m738a() {
        this.f742c = true;
        interrupt();
    }

    public void m739a(int i) {
        if (C0013d.f50d) {
            C0104d.m830a("setUpdateSessionTime:" + (i == 1 ? "TRUE" : "FALSE"));
        }
        this.f740a = System.currentTimeMillis();
        this.f741b = System.currentTimeMillis();
        if (i == 1) {
            this.f743d = true;
        } else {
            this.f743d = false;
        }
    }

    public void run() {
        C0104d.m830a("TimeOutThread Start");
        while (!this.f742c) {
            try {
                C0084g.sleep(2000);
                if (this.f743d) {
                    this.f741b = System.currentTimeMillis();
                    if (20000 < this.f741b - this.f740a) {
                        C0104d.m830a("FBSocket Timeout :20000");
                        C0099y c0099y = new C0099y();
                        c0099y.m781d(241);
                        c0099y.m794i(23205);
                        C0013d.m42d().m79b(c0099y, 3);
                        this.f743d = false;
                    }
                }
            } catch (InterruptedException e) {
                this.f742c = true;
            } catch (Exception e2) {
                C0104d.m829a(e2, "TimeOutThread");
            }
        }
        C0104d.m830a("TimeOutThread Stop");
    }
}
