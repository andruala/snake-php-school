package com.iprog.p004f;

import com.iprog.p001b.C0013d;
import com.iprog.p006g.C0104d;
import com.iprog.p006g.C0108h;
import java.io.IOException;

class C0083f extends Thread {
    int f737a;
    boolean f738b;
    final /* synthetic */ C0082d f739c;

    private C0083f(C0082d c0082d) {
        this.f739c = c0082d;
        this.f737a = 500;
        this.f738b = false;
    }

    public void m737a() {
        this.f738b = true;
        this.f739c.m647a(this.f739c.a);
        interrupt();
    }

    public void run() {
        C0104d.m830a("RecvDataThread Start");
        C0013d.m42d();
        while (!this.f738b && !isInterrupted()) {
            try {
                C0083f.sleep(10);
                C0099y c0099y = new C0099y();
                if (this.f739c.m653a(1)[0] == (byte) -95) {
                    byte[] a = this.f739c.m653a(1);
                    byte[] bArr = new byte[]{r1[0], a[0]};
                    if (c0099y.m770a(bArr)) {
                        this.f739c.f733f.m739a(2);
                        Object a2 = this.f739c.m654a(6, this.f737a);
                        if (a2.length == 6) {
                            a = new byte[8];
                            System.arraycopy(bArr, 0, a, 0, 2);
                            System.arraycopy(a2, 0, a, 2, a2.length);
                            if (C0013d.f50d) {
                                C0104d.m830a(String.format("[READ H:%d] %s", new Object[]{Integer.valueOf(a.length), C0108h.m850a(a)}));
                            }
                            c0099y.m779c(a);
                            int i = c0099y.f785A.f841f + 2;
                            if (3072000 > i) {
                                bArr = this.f739c.m654a(i, 500);
                                if (C0013d.f50d) {
                                    C0104d.m830a(String.format("[READ B:%d]\n%s", new Object[]{Integer.valueOf(bArr.length), C0108h.m850a(bArr)}));
                                }
                                if (bArr.length == i) {
                                    c0099y.m774b(C0108h.m862a(a, bArr));
                                    c0099y.m771a(bArr, 0, bArr.length - 2);
                                } else {
                                    c0099y.m794i(23202);
                                }
                            } else {
                                c0099y.m794i(23203);
                                this.f739c.m730e();
                            }
                        } else {
                            c0099y.m781d(C0108h.m842a(bArr[1]));
                            c0099y.m794i(23201);
                        }
                        if (c0099y.f785A.f837b != 202) {
                            this.f739c.m727a(c0099y, 3);
                        }
                    } else {
                        if (C0013d.f50d) {
                            C0104d.m830a(String.format("[READ]:%02x,%02x:Header Error:*****", new Object[]{Byte.valueOf(bArr[0]), Byte.valueOf(bArr[1])}));
                        }
                        this.f739c.m730e();
                    }
                } else {
                    continue;
                }
            } catch (InterruptedException e) {
                this.f738b = true;
            } catch (IOException e2) {
                C0104d.m830a("*****FBSocket IOException*****");
            } catch (Exception e3) {
                C0104d.m829a(e3, "FBSocket RecvDataThread");
            }
        }
        this.f738b = true;
        C0104d.m830a("FBSocket  RecvDataThread End");
    }
}
