package com.iprog.p000a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.p006g.C0104d;
import java.util.ArrayList;

public class C0000a extends BaseAdapter {
    ArrayList f0a = null;
    Context f1b;
    int f2c;
    int[] f3d = null;
    C0002c f4e = null;

    public C0000a(Context context, int i) {
        this.f1b = context;
        this.f2c = i;
    }

    public void m0a(C0002c c0002c) {
        this.f4e = c0002c;
    }

    public void m1a(ArrayList arrayList) {
        this.f0a = arrayList;
    }

    public void m2a(int[] iArr) {
        this.f3d = iArr;
    }

    public int getCount() {
        return this.f0a.size();
    }

    public Object getItem(int i) {
        return this.f0a.get(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            try {
                View inflate = ((LayoutInflater) this.f1b.getSystemService("layout_inflater")).inflate(this.f2c, viewGroup, false);
            } catch (Exception e) {
                return view;
            }
        }
        inflate = view;
        try {
            String[] split = ((String) this.f0a.get(i)).split("\\|");
            for (int i2 = 0; i2 < this.f3d.length; i2++) {
                TextView textView = (TextView) inflate.findViewById(this.f3d[i2]);
                try {
                    textView.setText(split[i2]);
                } catch (Exception e2) {
                    C0104d.m828a(e2);
                    textView.setText("");
                }
            }
            ((Button) inflate.findViewById(R.id.btn_send)).setOnClickListener(new C0001b(this, i));
            return inflate;
        } catch (Exception e3) {
            return inflate;
        }
    }
}
