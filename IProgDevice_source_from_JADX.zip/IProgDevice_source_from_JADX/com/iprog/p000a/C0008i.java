package com.iprog.p000a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.iprog.device.R;

public class C0008i extends BaseAdapter {
    String[] f26a = null;
    int[] f27b = null;
    Context f28c;
    int f29d;
    int[] f30e = null;
    private OnClickListener f31f = null;

    public C0008i(Context context, int i) {
        this.f28c = context;
        this.f29d = i;
    }

    public void m10a(int[] iArr, int[] iArr2) {
        this.f26a = new String[iArr2.length];
        this.f27b = iArr;
        for (int i = 0; i < this.f26a.length; i++) {
            this.f26a[i] = this.f28c.getString(iArr2[i]);
        }
    }

    public int getCount() {
        return this.f26a.length;
    }

    public Object getItem(int i) {
        return this.f26a[i];
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            try {
                View inflate = ((LayoutInflater) this.f28c.getSystemService("layout_inflater")).inflate(this.f29d, viewGroup, false);
            } catch (Exception e) {
                return view;
            }
        }
        inflate = view;
        try {
            TextView textView = (TextView) inflate.findViewById(R.id.tv_title);
            ImageView imageView = (ImageView) inflate.findViewById(R.id.img_ico);
            try {
                textView.setText(this.f26a[i]);
                imageView.setImageResource(this.f27b[i]);
                return inflate;
            } catch (Exception e2) {
                textView.setText("");
                return inflate;
            }
        } catch (Exception e3) {
            return inflate;
        }
    }
}
