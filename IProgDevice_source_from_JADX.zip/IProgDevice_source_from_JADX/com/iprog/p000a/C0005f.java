package com.iprog.p000a;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0028d;
import java.util.ArrayList;

public class C0005f extends BaseAdapter {
    ArrayList f14a = null;
    Context f15b;
    int f16c;
    C0013d f17d = C0013d.m42d();

    public C0005f(Context context, int i) {
        this.f15b = context;
        this.f16c = i;
    }

    public void m7a(ArrayList arrayList) {
        this.f14a = arrayList;
    }

    public int getCount() {
        return this.f14a.size();
    }

    public Object getItem(int i) {
        return this.f14a.get(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        View inflate;
        if (view == null) {
            try {
                inflate = ((LayoutInflater) this.f15b.getSystemService("layout_inflater")).inflate(this.f16c, viewGroup, false);
            } catch (Exception e) {
                return view;
            }
            try {
                inflate.setTag(R.id.tv_chip_item, inflate.findViewById(R.id.tv_chip_item));
                inflate.setTag(R.id.img_chip_pic, inflate.findViewById(R.id.img_chip_pic));
            } catch (Exception e2) {
                return inflate;
            }
        }
        inflate = view;
        TextView textView = (TextView) inflate.getTag(R.id.tv_chip_item);
        ImageView imageView = (ImageView) inflate.getTag(R.id.img_chip_pic);
        if (((C0028d) this.f14a.get(i)).f161c == 2) {
            textView.setText(new StringBuilder(String.valueOf(((C0028d) this.f14a.get(i)).f159a.f142p)).append(" Series").toString());
        } else {
            textView.setText(((C0028d) this.f14a.get(i)).f159a.f132f);
            if (((C0028d) this.f14a.get(i)).f161c == 0) {
                textView.setTextColor(Color.rgb(0, 255, 255));
            } else {
                textView.setTextColor(-1);
            }
        }
        try {
            imageView.setImageBitmap(((C0028d) this.f14a.get(i)).f159a.f121H);
            return inflate;
        } catch (Exception e3) {
            imageView.setImageBitmap(null);
            return inflate;
        }
    }
}
