package com.iprog.p000a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RadioButton;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.p006g.C0104d;
import java.util.ArrayList;

public class C0003d extends BaseAdapter {
    ArrayList f7a = null;
    int f8b = 0;
    Context f9c;
    int f10d;

    public C0003d(Context context, int i) {
        this.f9c = context;
        this.f10d = i;
    }

    public void m4a(int i) {
        this.f8b = i;
    }

    public void m5a(ArrayList arrayList) {
        m6a(arrayList, 0);
    }

    public void m6a(ArrayList arrayList, int i) {
        this.f7a = arrayList;
        this.f8b = Math.max(0, i);
    }

    public int getCount() {
        return this.f7a.size();
    }

    public Object getItem(int i) {
        return this.f7a.get(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            try {
                View inflate = ((LayoutInflater) this.f9c.getSystemService("layout_inflater")).inflate(this.f10d, viewGroup, false);
            } catch (Exception e) {
                Exception exception = e;
                View view2 = view;
                C0104d.m829a(exception, "ComboBoxViewAdapter");
                return view2;
            }
        }
        inflate = view;
        try {
            RadioButton radioButton = (RadioButton) inflate.findViewById(R.id.ck_select);
            ((TextView) inflate.findViewById(R.id.tv_data)).setText((CharSequence) this.f7a.get(i));
            if (i == this.f8b) {
                radioButton.setChecked(true);
            }
            radioButton.setOnCheckedChangeListener(new C0004e(this, i, radioButton));
            return inflate;
        } catch (Exception e2) {
            exception = e2;
            view2 = inflate;
            C0104d.m829a(exception, "ComboBoxViewAdapter");
            return view2;
        }
    }
}
