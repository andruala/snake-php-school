package com.iprog.p000a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.iprog.p006g.C0104d;
import java.util.ArrayList;

public class C0009j extends BaseAdapter {
    ArrayList f32a = null;
    Context f33b;
    int f34c;
    int[] f35d = null;

    public C0009j(Context context, int i) {
        this.f33b = context;
        this.f34c = i;
    }

    public void m11a(ArrayList arrayList) {
        this.f32a = arrayList;
    }

    public void m12a(int[] iArr) {
        this.f35d = iArr;
    }

    public int getCount() {
        return this.f32a.size();
    }

    public Object getItem(int i) {
        return this.f32a.get(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            try {
                View inflate = ((LayoutInflater) this.f33b.getSystemService("layout_inflater")).inflate(this.f34c, viewGroup, false);
            } catch (Exception e) {
                return view;
            }
        }
        inflate = view;
        try {
            String[] split = ((String) this.f32a.get(i)).split("\\|");
            for (int i2 = 0; i2 < this.f35d.length; i2++) {
                TextView textView = (TextView) inflate.findViewById(this.f35d[i2]);
                try {
                    textView.setText(split[i2]);
                } catch (Exception e2) {
                    C0104d.m828a(e2);
                    textView.setText("");
                }
            }
            return inflate;
        } catch (Exception e3) {
            return inflate;
        }
    }
}
