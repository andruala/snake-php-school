package com.iprog.p000a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0035k;
import java.util.ArrayList;

public class C0007h extends BaseAdapter {
    ArrayList f22a = null;
    Context f23b;
    int f24c;
    C0013d f25d = C0013d.m42d();

    public C0007h(Context context, int i) {
        this.f23b = context;
        this.f24c = i;
    }

    public void m9a(ArrayList arrayList) {
        this.f22a = arrayList;
    }

    public int getCount() {
        return this.f22a.size();
    }

    public Object getItem(int i) {
        return this.f22a.get(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        View inflate;
        if (view == null) {
            try {
                inflate = ((LayoutInflater) this.f23b.getSystemService("layout_inflater")).inflate(this.f24c, viewGroup, false);
            } catch (Exception e) {
                return view;
            }
            try {
                inflate.setTag(R.id.tv_chip_item, inflate.findViewById(R.id.tv_chip_item));
                inflate.setTag(R.id.img_chip_pic, inflate.findViewById(R.id.img_chip_pic));
            } catch (Exception e2) {
                return inflate;
            }
        }
        inflate = view;
        TextView textView = (TextView) inflate.getTag(R.id.tv_chip_item);
        ImageView imageView = (ImageView) inflate.getTag(R.id.img_chip_pic);
        if (((C0035k) this.f22a.get(i)).f207b == 2) {
            textView.setText(new StringBuilder(String.valueOf(((C0035k) this.f22a.get(i)).f206a.f173g.f142p)).append(" Series").toString());
        } else {
            textView.setText(((C0035k) this.f22a.get(i)).f206a.f171e);
            if (((C0035k) this.f22a.get(i)).f207b == 0) {
                textView.setTextColor(-16776961);
            } else {
                textView.setTextColor(-16777216);
            }
        }
        try {
            imageView.setImageBitmap(((C0035k) this.f22a.get(i)).f206a.m181h());
            return inflate;
        } catch (Exception e3) {
            imageView.setImageBitmap(null);
            return inflate;
        }
    }
}
