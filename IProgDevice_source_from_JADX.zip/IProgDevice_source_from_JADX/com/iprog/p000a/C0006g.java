package com.iprog.p000a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.iprog.device.R;
import com.iprog.p001b.C0013d;
import com.iprog.p003d.C0031g;
import java.util.ArrayList;

public class C0006g extends BaseAdapter {
    ArrayList f18a = null;
    Context f19b;
    int f20c;
    C0013d f21d = C0013d.m42d();

    public C0006g(Context context, int i) {
        this.f19b = context;
        this.f20c = i;
    }

    public void m8a(ArrayList arrayList) {
        this.f18a = arrayList;
    }

    public int getCount() {
        return this.f18a.size();
    }

    public Object getItem(int i) {
        return this.f18a.get(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        View inflate;
        if (view == null) {
            try {
                inflate = ((LayoutInflater) this.f19b.getSystemService("layout_inflater")).inflate(this.f20c, viewGroup, false);
            } catch (Exception e) {
                return view;
            }
            try {
                inflate.setTag(R.id.img_chip_pic, inflate.findViewById(R.id.img_chip_pic));
                inflate.setTag(R.id.tv_model, inflate.findViewById(R.id.tv_model));
                inflate.setTag(R.id.tv_nat_cd, inflate.findViewById(R.id.tv_nat_cd));
                inflate.setTag(R.id.tv_color, inflate.findViewById(R.id.tv_color));
                inflate.setTag(R.id.tv_yield, inflate.findViewById(R.id.tv_yield));
            } catch (Exception e2) {
                return inflate;
            }
        }
        inflate = view;
        ImageView imageView = (ImageView) inflate.getTag(R.id.img_chip_pic);
        TextView textView = (TextView) inflate.getTag(R.id.tv_nat_cd);
        TextView textView2 = (TextView) inflate.getTag(R.id.tv_color);
        TextView textView3 = (TextView) inflate.getTag(R.id.tv_yield);
        ((TextView) inflate.getTag(R.id.tv_model)).setText(((C0031g) this.f18a.get(i)).f176b.f132f);
        textView.setText(((C0031g) this.f18a.get(i)).f177c);
        textView2.setText(((C0031g) this.f18a.get(i)).f178d);
        textView3.setText(((C0031g) this.f18a.get(i)).f179e);
        try {
            imageView.setImageBitmap(((C0031g) this.f18a.get(i)).f176b.f121H);
            return inflate;
        } catch (Exception e3) {
            imageView.setImageBitmap(null);
            return inflate;
        }
    }
}
