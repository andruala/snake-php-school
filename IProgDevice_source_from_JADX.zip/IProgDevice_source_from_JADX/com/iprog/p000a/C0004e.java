package com.iprog.p000a;

import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RadioButton;

class C0004e implements OnCheckedChangeListener {
    final /* synthetic */ C0003d f11a;
    private final /* synthetic */ int f12b;
    private final /* synthetic */ RadioButton f13c;

    C0004e(C0003d c0003d, int i, RadioButton radioButton) {
        this.f11a = c0003d;
        this.f12b = i;
        this.f13c = radioButton;
    }

    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        if (this.f12b == this.f11a.f8b) {
            this.f13c.setChecked(true);
        } else {
            this.f13c.setChecked(false);
        }
    }
}
