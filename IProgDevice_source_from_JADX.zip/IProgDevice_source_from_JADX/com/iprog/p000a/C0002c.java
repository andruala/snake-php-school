package com.iprog.p000a;

public interface C0002c {
    void mo14a(int i);
}
