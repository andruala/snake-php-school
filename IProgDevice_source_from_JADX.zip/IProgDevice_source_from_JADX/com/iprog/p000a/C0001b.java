package com.iprog.p000a;

import android.view.View;
import android.view.View.OnClickListener;

class C0001b implements OnClickListener {
    final /* synthetic */ C0000a f5a;
    private final /* synthetic */ int f6b;

    C0001b(C0000a c0000a, int i) {
        this.f5a = c0000a;
        this.f6b = i;
    }

    public void onClick(View view) {
        if (this.f5a.f4e != null) {
            this.f5a.f4e.mo14a(this.f6b);
        }
    }
}
