#include <stdlib.h>
#include <stdio.h>

void main(int argc, char ** argv)
{
	int p1, tab[2];
	char c;
	char * nume_fis;
	
	if (argc != 2)
	{
		printf("Lipseste argumentul!\n\n");
		exit(0);
	}
	
	nume_fis = argv[1];	
	
	pipe(tab);
	
	p1 = fork();
	if (p1 == 0)
	{
		close(tab[0]);
		
		for (int k = 0; k < 500; k ++)
			write(tab[1], "A", 1);
		
		exit(1);
	}
	
	close(tab[1]);

	while ((read(tab[0], &c, 1)) == 1)
	{
		write(1, &c, 1);
	}
	
	write(1, "\n");
}
