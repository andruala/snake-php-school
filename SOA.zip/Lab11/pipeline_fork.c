#include <stdlib.h>
#include <stdio.h>

void main()
{
	int p1, p2, tab[2];
	char c;
	
	pipe(tab);
	
	p1 = fork();
	if (p1 == 0)
	{
		close(tab[0]);
		
		for (int k = 0; k < 500; k ++)
			write(tab[1], "A", 1);
		
		exit(1);
	}
	
	p2 = fork();
	if (p2 == 0)
	{
		close(tab[0]);
		
		for (int k = 0; k < 500; k ++)
			write(tab[1], "B", 1);
		
		exit(2);
	}
	
	close(tab[1]);

	while ((read(tab[0], &c, 1)) == 1)
	{
		write(1, &c, 1);
	}
	
	write(1, "\n");
}
