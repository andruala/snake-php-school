#include <stdio.h>

void main()
{
	char a = 'X';
	char * b = "Montagne";
	char c[20] = "Nature";
	char * d[4] = { "Randonnee", "Escalade", "Canyoning", "Speleologie" };
	
	printf("%p | %s | %d \n", d, *d, **d);
	printf("%p \n", *(d + 2));
	printf("%c \n", *(*(d + 2) + 3));
	
	d[2] = & a;
	printf("%s \n", d[2]);
}
