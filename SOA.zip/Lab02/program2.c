#include <stdio.h>

int a[] = { 12, 23, 34, 45, 56, 67, 78, 89, 90 };
int counter = 0;
int * p;

void main()
{	
	p = a;
	
	printf("%d", *(p + *(p + 8) - a[7]));
}
