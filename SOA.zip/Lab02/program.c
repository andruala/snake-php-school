#include <stdio.h>

int a = 1, b = 2, c = 3, counter = 0;
int * p1 = NULL, * p2 = NULL;

void main()
{
	print();
	
	p1 = & a;
	print();
	
	p2 = & c;
	print();
	
	*p1 = (*p2) ++;
	print();
	
	p1 = p2;
	print();
	
	p2 = & b;
	print();
	
	*p1 -= *p2;
	print();
	
	++ *p2;
	print();
	
	*p1 *= * p2;
	print();
	
	a = ++ *p2 * *p1;
	print();
	
	p1 = & a;
	print();
	
	*p2 = *p1 /= *p2;
	print();
}

void print()
{
	counter ++;
	printf("%d) a = %d | b = %d | c = %d | p1 = %p | p2 = %p \n", counter, a, b, c, p1, p2);
}
