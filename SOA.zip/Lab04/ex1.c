#include <stdio.h>

void bizzare(unsigned char *);

void main()
{
	unsigned char t[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	
	bizzare(t);
	
	for (int i = 0; i < 10; i ++)
	{
		printf("%d ", t[i]);
	}
	
	printf("\n");
}

void bizzare(unsigned char * t)
{
	t ++;
	t = (&(t[4]));
	*t = t[0];
	t = t + *t - 7;	
	t[0] = 0;
}
