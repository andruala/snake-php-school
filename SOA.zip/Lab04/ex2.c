#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void main(int argc, char ** argv)
{
	char * s;

	if ((s = (char *) malloc(strlen(argv[0]) + 1)) == NULL)
	{
		printf("Eroare alocare zona de memorie.\n");
		exit(1);
	}
	
	strcpy(s, argv[0] + 1);

	printf("%s %s \n", argv[0], s);
}
