#include <stdio.h>
#include <stdlib.h>

void main()
{
	char * s = "Examen final";
	char * t;
	int i, n = strlen(s);
	
	t = (char *) malloc(n * sizeof(char));
	if (! t)
	{
		printf("Eroare alocare zona de memorie.\n");
		exit(1);
	}
	
	for (i = 0; i < n; i ++)
	{
		t[i] = s[i];
	}
	
	t[i] = '\0';
	
	printf("%s %s \n", s, t);
}
