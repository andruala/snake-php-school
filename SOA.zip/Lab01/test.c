#include <stdio.h>
#include <stdlib.h>

void main()
{
	int a = 20, b = 5, c = -10, d = 2, x = 12, y = 15;

	printf("%d\n", ((a && b) || !0) && (c && (!d)));
}
