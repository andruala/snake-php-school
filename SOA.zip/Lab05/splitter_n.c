#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

void eroare(char * mesaj)
{
	if (errno)
		perror(mesaj);
	else
		fprintf(stderr, "%s \n", mesaj);
	
	exit(1);
}

void main(int argc, char ** argv)
{
	int file_des, split_file;
	int i, num_splits;
	char* nume_fis;
	char* p_buf;
	
	nume_fis = (char*) malloc(100);
	
	if (argc < 3)
	{
		printf("\nUtilizare comanda: %s %s %s ", argv[0], "<nume fisier>", "<numar fisiere noi>\n\n");
		return;
	}
	else
	{
		nume_fis = argv[1];
		num_splits = atoi(argv[2]);
	}
	
	file_des = open(nume_fis, O_RDONLY);
	if (file_des == -1)
		eroare("Eroare deschidere fisier!");
	
	i = lseek(file_des, 0, SEEK_END);
	if (i == -1)
		eroare("Eroare lseek - 1");
	
	if (lseek(file_des, 0, SEEK_SET) == - 1)
		eroare("Eroare lseek - 2");
	
	p_buf = (char*) malloc(i);
	
	if (read(file_des, p_buf, i) != i)
		eroare("Eroare de citire fisier");
	
	int orig_file_length = strlen(nume_fis) + 4;

	for (int j = 0; j < num_splits; j ++)
	{
		char * nume_fis_nou = (char*) malloc(orig_file_length);
		
		strcpy(nume_fis_nou, nume_fis);
		
		nume_fis_nou[orig_file_length - 4] = '.';
		
		if (j < 10)
			nume_fis_nou[orig_file_length - 3] = '0';
		else
			nume_fis_nou[orig_file_length - 3] = (j / 10) + '0';
		
		nume_fis_nou[orig_file_length - 2] = (j % 10) + '0';
		
		split_file = open(nume_fis_nou, O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR);
		
		write(split_file, p_buf, i / num_splits);
		
		p_buf += i / num_splits;
		
		close(split_file);
	}
	
	close(file_des);
}
