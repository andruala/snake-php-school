#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>

void eroare(char * mesaj)
{
	if (errno)
		perror(mesaj);
	else
		fprintf(stderr, "%s \n", mesaj);
	
	exit(1);
}

main()
{
	int file_des;
	int i;
	char* nume_fis;
	char* p_buf;
	
	nume_fis = (char*) malloc(100);
		
	printf("Tastati numele unui fisier text: ");
	scanf("%s", nume_fis);
	
	file_des = open(nume_fis, O_RDONLY);
	if (file_des == -1)
		eroare("Eroare deschidere fisier!");
	printf("%d\n\n", lseek(file_des, 0, SEEK_SET));
	i = lseek(file_des, 0, SEEK_END);
	if (i == -1)
		eroare("Eroare lseek - 1");
	
	if (lseek(file_des, 0, SEEK_SET) == - 1)
		eroare("Eroare lseek - 2");
	
	p_buf = (char*) malloc(i);
	
	if (read(file_des, p_buf, i) != i)
		eroare("Eroare de citire fisier");
	
	if (write(1, p_buf, i) != i)
		eroare("Eroare de scriere fisier");
	
	printf("\n\n");
	
	int k = 0;
	while (p_buf[k])
		printf("%c", toupper(p_buf[k++]));
}
