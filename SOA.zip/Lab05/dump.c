#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>

void eroare(char * mesaj)
{
	if (errno)
		perror(mesaj);
	else
		fprintf(stderr, "%s \n", mesaj);
	
	exit(1);
}

main()
{
	int file_des;
	int i;
	char* nume_fis;
	char* p_buf;
	
	nume_fis = (char*) malloc(100);
		
	printf("Tastati numele unui fisier text: ");
	scanf("%s", nume_fis);
	
	printf("\n");

	file_des = open(nume_fis, O_RDONLY);
	if (file_des == -1)
		eroare("Eroare deschidere fisier!");
	
	i = lseek(file_des, 0, SEEK_END);
	if (i == -1)
		eroare("Eroare lseek - 1");
	
	if (lseek(file_des, 0, SEEK_SET) == - 1)
		eroare("Eroare lseek - 2");
	
	p_buf = (char*) malloc(i);
	
	if (read(file_des, p_buf, i) != i)
		eroare("Eroare de citire fisier");
	
	int k = 0;
	while (k < i)
	{
		if (k % 16 == 0)
			printf("\n%07x ", p_buf[k]);
		
		printf("%02x ", p_buf[k++]);
	}
	
	printf("\n%07x \n", p_buf[k - 1]);
}
