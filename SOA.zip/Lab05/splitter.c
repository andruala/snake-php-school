#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>

void eroare(char * mesaj)
{
	if (errno)
		perror(mesaj);
	else
		fprintf(stderr, "%s \n", mesaj);
	
	exit(1);
}

main(int argc, char ** argv)
{
	int file_des, split_file1, split_file2;
	int i;
	char* nume_fis;
	char* p_buf;
	
	nume_fis = (char*) malloc(100);
	
	if (argc < 2)
	{
		printf("Tastati numele unui fisier text: ");
		scanf("%s", nume_fis);
	}
	else
	{
		nume_fis = argv[1];
	}
	
	file_des = open(nume_fis, O_RDONLY);
	if (file_des == -1)
		eroare("Eroare deschidere fisier!");
	
	i = lseek(file_des, 0, SEEK_END);
	if (i == -1)
		eroare("Eroare lseek - 1");
	
	if (lseek(file_des, 0, SEEK_SET) == - 1)
		eroare("Eroare lseek - 2");
	
	p_buf = (char*) malloc(i);
	
	if (read(file_des, p_buf, i) != i)
		eroare("Eroare de citire fisier");
	
	int orig_file_length = strlen(nume_fis) + 4;
	char * nume_fis01 = (char*) malloc(orig_file_length);
	char * nume_fis02 = (char*) malloc(orig_file_length);
	
	strcpy(nume_fis01, nume_fis);
	strcpy(nume_fis02, nume_fis);
	
	nume_fis02[orig_file_length - 4] = nume_fis01[orig_file_length - 4] = '.';
	nume_fis02[orig_file_length - 3] = nume_fis01[orig_file_length - 3] = '0';
	nume_fis01[orig_file_length - 2] = '1';
	nume_fis02[orig_file_length - 2] = '2';
	
	split_file1 = open(nume_fis01, O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR);
	split_file2 = open(nume_fis02, O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR);
	
	write(split_file1, p_buf, i / 2);
	
	p_buf += i / 2;
	
	write(split_file2, p_buf, i / 2);
	
	close(file_des);
	close(split_file1);
	close(split_file2);
}
