#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>

main()
{
	int fis_des, i;
	char* p_buf, * nume_fis;
	
	printf("Introduceti numele fisierului: ");
	
}
