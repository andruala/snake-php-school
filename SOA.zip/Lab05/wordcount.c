#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

void eroare(char * mesaj)
{
	if (errno)
		perror(mesaj);
	else
		fprintf(stderr, "%s \n", mesaj);
	
	exit(1);
}

main(int argc, char** argv)
{
	int file_des;
	int i;
	char* nume_fis;
	char* p_buf;
	
	nume_fis = (char*) malloc(100);
	
	if (argc < 2)
	{
		printf("Tastati numele unui fisier text: ");
		scanf("%s", nume_fis);
	}
	else
	{
		nume_fis = argv[1];
	}
	
	printf("\n");

	file_des = open(nume_fis, O_RDONLY);
	if (file_des == -1)
		eroare("Eroare deschidere fisier!");
	
	i = lseek(file_des, 0, SEEK_END);
	if (i == -1)
		eroare("Eroare lseek - 1");
	
	if (lseek(file_des, 0, SEEK_SET) == - 1)
		eroare("Eroare lseek - 2");
	
	p_buf = (char*) malloc(i);
	
	if (read(file_des, p_buf, i) != i)
		eroare("Eroare de citire fisier");
	
	int wordCount = 0;
	char * wp = strtok(p_buf, " ,.-!?");
	while (wp)
	{
		wordCount += 1;
		wp = strtok(NULL, " ,.-!?");
	}
	
	int lineCount = 0, k = 0;
	while (k < i)
	{
		if (p_buf[k++] == '\n')
			lineCount += 1;
	}
	
	printf("Caractere: %d \n", i);
	printf("Cuvinte:   %d \n", wordCount);
	printf("Linii:     %d \n", lineCount);
	
	printf("\n");
}
