#include <stdio.h>

void main()
{
	int p;
	
	p = fork();
	if (p == 0)
	{
		printf("Salut id TATA=%d id pers=%d\n", getppid(), getpid());
		execlp("ls", "ls", "/", 0);
	}
	else
	{
		printf("Buna ziua id TATA=%d id pers=%d\n", getppid(), getpid());
		while(1);
	}
}
