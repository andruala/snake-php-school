#include <stdlib.h>
#include <stdio.h>

void main()
{
	int p1, p2, p_nepot1;
	
	p1 = fork();
	
	if (p1 == 0)
	{
		// FIU 1
		
		p_nepot1 = fork();
		
		if (p_nepot1 == 0)
		{
			// Nepot
			printf("Proces NEPOT fiu 1 cu id: %d | PARINTE cu id: %d\n", getpid(), getppid());
		}
		else
		{
			printf("Proces FIU 1 cu id: %d | PARINTE cu id: %d\n", getpid(), getppid());
			
			while(1) {}
		}
	}
	else
	{
		// TATA
		
		p2 = fork();
		
		if (p2 == 0)
		{
			// FIU 2
			printf("Proces FIU 2 cu id: %d | PARINTE cu id: %d\n", getpid(), getppid());
		}
		else
		{
			printf("Proces TATA cu id: %d | PARINTE cu id: %d\n", getpid(), getppid());
		}
	}
}
