#include <stdlib.h>
#include <stdio.h>

void main()
{
	int p1, p2;
	
	p1 = fork();
	
	if (p1 == 0)
	{
		// FIU 1
		printf("Proces FIU 1 cu id: %d | PARINTE cu id: %d\n", getpid(), getppid());
	}
	else
	{
		// TATA
		
		p2 = fork();
		
		if (p2 == 0)
		{
			// FIU 2
			printf("Proces FIU 2 cu id: %d | PARINTE cu id: %d\n", getpid(), getppid());
		}
		else
		{
			printf("Proces TATA cu id: %d | PARINTE cu id: %d\n", getpid(), getppid());
			
			while (1) {}
		}
	}
}
